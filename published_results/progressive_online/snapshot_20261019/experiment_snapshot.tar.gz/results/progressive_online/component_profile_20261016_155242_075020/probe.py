import torch
x=torch.ones(1024,device="cuda")
y=x+1
torch.cuda.synchronize()
