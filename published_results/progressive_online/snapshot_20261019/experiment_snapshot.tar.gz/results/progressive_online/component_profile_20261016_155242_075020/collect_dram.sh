#!/usr/bin/env bash
set -euo pipefail
cd /home/wanglin/kvbench-3090-cu126
BATCH=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
# Run only with GPU counter access; all per-case directories must be new.
# Cache is explicitly flushed by ncu for repeatable cold-cache hardware traffic.
for variant in parent layout_full control_full adaptive_s1 adaptive_s4 metadata; do
  if [[ -e "$BATCH/ncu_$variant" || -e "$BATCH/ncu_${variant}.csv" ]]; then
    echo "Refusing to overwrite existing profiling output: $variant" >&2
    exit 2
  fi
  /usr/local/cuda-12.6/bin/ncu --target-processes all --profile-from-start off --cache-control all \
    --metrics dram__bytes_read.sum,dram__bytes_write.sum,gpu__time_duration.sum --csv --page raw \
    --log-file "$BATCH/ncu_${variant}.csv" \
    /home/wanglin/miniconda3/envs/kvarn-serve/bin/python -m kvbench_progressive_online.profile_components \
    --out "$BATCH/ncu_$variant" --traces results/residual_diag/run_20261012_161428_3993496/traces \
    --gate results/progressive_online/reuse_accuracy_20261016_154258_188087/gpu_gate_extended \
    --trace-limit 1 --ncu-case "$variant"
done
