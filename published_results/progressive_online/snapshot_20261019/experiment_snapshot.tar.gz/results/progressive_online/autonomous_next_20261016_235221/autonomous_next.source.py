"""Durable sequential performance, attribution and gated quality experiments."""
import argparse, os, json, sys, subprocess, traceback, statistics, time
from pathlib import Path
from datetime import datetime
from kvbench_longcontext.common import atomic_json

BASE=Path('results/progressive_online/staged_optimization_20261016_174407_183860').resolve()
TRACES=Path(os.environ.get('KVBENCH_NEXT_TRACES','results/residual_diag/run_20261012_161428_3993496/traces')).resolve()

def operator(out):
 import numpy as np
 import torch
 from dataclasses import replace
 from .validate_reuse import Replay,load_module
 from .run_ablation import load_file
 from .budget_probe import source_with_plan,selector
 from .profile_components import measure
 from kvbench_residual_diag.common import load_trace,trace_paths
 out.mkdir()
 # Deterministic acquisition-order selection: distinct requests; calibration excluded.
 paths=trace_paths(TRACES)
 cal,cm=load_trace(paths[0]); cr=Replay(cal,64)
 weights=cr.metadata[:,:,0].square().mean(0).contiguous();del cr
 chosen=[];seen={cm['request']['case_id']}
 for p in paths[1:]:
  m=json.loads(p.read_text()); identity=m['request']['case_id']
  if identity not in seen and m['window']==0:
   chosen.append(p);seen.add(identity)
  if len(chosen)==24:break
 if len(chosen)<24:raise ValueError('Need 24 distinct real requests excluding calibration')
 atomic_json(out/'inputs.json',{'calibration':str(paths[0]),'evaluation':[str(p) for p in chosen], 'scope':'Reconstructed heterogeneous B8 from disjoint C1 captures; not simultaneous online capture; layer identity unverified'})
 native=load_module(BASE/'runtime_native','auto_native')
 modules={'native':native}
 for name in ['fixed_k4v4','fixed_k2v2']:
  modules[name]=load_file(BASE/'variants'/f'{name}.py','auto_'+name)
 p=out/'budget_reader.py';p.write_text(source_with_plan((BASE/'variants/fixed_k2v2.py').read_text()))
 budget=load_file(p,'auto_budget');rows=[]
 for group in range(3):
  loaded=[load_trace(p)[0] for p in chosen[group*8:(group+1)*8]]
  d={};pages=slots=0;tables=[];mapping=[];width=max(x['block_table'].shape[1] for x in loaded)
  for x in loaded:
   bt=x['block_table'].copy();bt[bt>=0]+=pages;tables.append(np.pad(bt,((0,0),(0,width-bt.shape[1])),constant_values=-1))
   mp=x['block_to_slot'].copy();mp[mp>=0]+=slots;mapping.append(mp)
   pages+=len(x['cache']);slots+=len(x['pool_k'])
  for key in ['query','cache','seq_lens','pool_k','pool_v','reference_gpu_rot']:d[key]=np.concatenate([x[key] for x in loaded])
  d.update(block_table=np.concatenate(tables),block_to_slot=np.concatenate(mapping),req_rows=np.arange(8,dtype=np.int32),scale=loaded[0]['scale'])
  assert all(x['case'].layout==loaded[0]['case'].layout and x['scale']==d['scale'] for x in loaded)
  d['case']=replace(loaded[0]['case'],seq_lens=tuple(map(int,d['seq_lens'])))
  replay=Replay(d,64);g=replay.gpu;g.splits=32
  g.mid_o=torch.zeros((256,32,128),device='cuda');g.mid_lse=torch.full((256,32),-float('inf'),device='cuda')
  # Compare merged mapping to eight independent launches before any performance claim.
  reference=replay.launch(native,'split').clone().reshape(8,32,128)
  for i,x in enumerate(loaded):
   one=Replay(x,64);one.gpu.splits=32
   one.gpu.mid_o=torch.zeros((32,32,128),device='cuda');one.gpu.mid_lse=torch.full((32,32),-float('inf'),device='cuda')
   torch.testing.assert_close(reference[i],one.launch(native,'split').reshape(32,128),rtol=.002,atol=.002)
   del one
  plan=torch.empty((8,8),device='cuda',dtype=torch.int32)
  static=torch.full_like(plan,2);static[:,torch.argsort(weights,descending=True,stable=True)[:2]]=4
  def dynamic():
   selector(g.t['query'],weights,plan)
   return replay.launch(budget,'split',extra={'PG_PLAN_PTR':plan})
  ops={name:(lambda m=m:replay.launch(m,'split')) for name,m in modules.items()}
  ops.update(static_same_budget=lambda:replay.launch(budget,'split',extra={'PG_PLAN_PTR':static}),query_adaptive_including_selector=dynamic)
  for bn in (16,32,64):
   g.block_n=bn;g.num_warps=4;g.num_stages=1;graphs={};outputs={}
   for name,fn in ops.items():
    fn();torch.cuda.synchronize();graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):fn()
    graph.replay();torch.cuda.synchronize();outputs[name]=g.out.clone();graphs[name]=graph
   torch.testing.assert_close(outputs['fixed_k4v4'],outputs['native'],rtol=.002,atol=.002)
   timing={name:[] for name in ops};names=list(ops)
   for rnd in range(5):
    for name in names[rnd:]+names[:rnd]:timing[name].append(measure(graphs[name].replay,30,5)['median_us'])
   for name in ops:
    diff=(outputs[name]-outputs['native']).float()
    rows.append(dict(group=group,batch=8,block_n=bn,variant=name,round_medians_us=timing[name],median_us=statistics.median(timing[name]),relative_l2=float(diff.norm()/outputs['native'].float().norm().clamp_min(1e-12))))
   atomic_json(out/'timings.json',rows)
  del replay,g,graphs,outputs;torch.cuda.empty_cache()
 decision={}
 for name in ops:
  speed=[]
  for group in range(3):
   best=lambda v:min(r['median_us'] for r in rows if r['group']==group and r['variant']==v)
   speed.append(best('native')/best(name))
  decision[name]={'speedups_vs_best_native':speed,'passes_10pct':all(x>=1.10 for x in speed)}
 atomic_json(out/'decision.json',decision);atomic_json(out/'status.json',{'status':'completed','limits':['Reconstructed B8; not live C8','No DRAM counters','Three independent groups; no task quality claim','Native and candidate search same BLOCK_N grid; warps4 stages1 splits32']})

def quality(out,fixed=False):
 from . import run,runtime
 from .ablation import generate
 from .fused_runtime import install
 if fixed:
  original=runtime.transform_dequant
  runtime.transform_dequant=lambda source,arm,thresholds: generate(original(source,arm,thresholds),'fixed_k2v2') if arm=='p211_adaptive' else original(source,arm,thresholds)
 original_build=run.build
 def build(*args,**kwargs):
  result=original_build(*args,**kwargs)
  if args[1]=='p211_adaptive':install(args[0],args[1])
  return result
 run.build=build
 run.main(['--out',str(out),'--arms','parent','p211_full','p211_adaptive','--task','all','--count','20','--port','18189'])

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--worker',choices=['operator','quality_fixed','quality_adaptive']);a=p.parse_args()
 if a.worker:
  if a.worker=='operator':operator(a.out)
  else:quality(a.out,a.worker=='quality_fixed')
  return
 root=a.out.resolve();root.mkdir(parents=True,exist_ok=False)
 state={'status':'running','pid':os.getpid(),'started':datetime.now().isoformat(),'stages':{}}
 def save():atomic_json(root/'status.json',state)
 save();atomic_json(root/'plan.json',{'sequence':['heterogeneous B8 reconstruction and matched graph performance','independent online writer comparison and profiler','quality if fixed reader passes >=1.10x on every group'], 'quality_variant':'fixed_k2v2 with fused writer; fresh parent/full controls; original quality protocol','dynamic_quality':'deferred until dynamic proves advantage over static; no online adapter yet','failure_policy':'Record failure; continue independent diagnostics; no quality on failed performance gate','source':str(Path(__file__).resolve()),'scope':'Finite sequential batch, no indefinite busy loop'})
 env=dict(os.environ,KVBENCH_NEXT_TRACES=str(root/'capture/traces'),PYTHONUNBUFFERED='1',PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',NO_PROXY='localhost,127.0.0.1,::1',no_proxy='localhost,127.0.0.1,::1')
 def stage(name,command,timeout):
  state['phase']=name;state['stages'][name]={'status':'running','started':datetime.now().isoformat()};save()
  try:
   with (root/(name+'.log')).open('x') as log:r=subprocess.run([sys.executable,'-u','-m',*map(str,command)],stdout=log,stderr=subprocess.STDOUT,env=env,timeout=timeout)
   state['stages'][name].update(status='completed' if r.returncode==0 else 'failed',returncode=r.returncode)
  except Exception as e:state['stages'][name].update(status='failed',error=repr(e))
  save();return state['stages'][name]['status']=='completed'
 captured=stage('capture',['kvbench_residual_diag.run','--out',root/'capture','--tasks','qasper','hotpotqa','passage_retrieval_en','--per-task','9','--layer-ordinals','0','--decode-calls','0','--diagnostic-max-tokens','8','--max-traces','40','--max-gib','4','--capture-only','--port','18190'],14400)
 ok=captured and stage('operator',['kvbench_progressive_online.autonomous_next','--worker','operator','--out',root/'operator'],7200)
 stage('attribution',['kvbench_progressive_online.staged_online','--operator-run',BASE,'--out',root/'attribution'],14400)
 if ok and json.loads((root/'operator/decision.json').read_text())['fixed_k2v2']['passes_10pct']:
  stage('quality_fixed',['kvbench_progressive_online.autonomous_next','--worker','quality_fixed','--out',root/'quality_fixed'],86400)
 else:
  state['stages']['quality_fixed']={'status':'skipped','reason':'Heterogeneous operator gate failed or did not reach 10pct in all groups'}
 state.update(status='completed_with_failures' if any(x['status']=='failed' for x in state['stages'].values()) else 'completed',phase='finished',finished=datetime.now().isoformat());save()
 atomic_json(root/'final_analysis.json',{'stages':state['stages'],'operator':json.loads((root/'operator/decision.json').read_text()) if (root/'operator/decision.json').exists() else None,'quality_label':'p211_adaptive denotes fixed_k2v2 fused-writer candidate in quality_fixed only','limits':['Operator gate alone does not prove online speed','No physical DRAM counters','Do not compare truncated diagnostic output to quality scores']})

if __name__=='__main__':main()
