#!/usr/bin/env bash
set -euo pipefail
cd /home/wanglin/kvbench-3090-cu126
BATCH=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
trap 'rc=$?; printf "%s\n" "$rc" > "$BATCH/online_exit_code.txt"' EXIT
set +u
source /home/wanglin/miniconda3/etc/profile.d/conda.sh
conda activate kvarn-serve
source /home/wanglin/kv_evalscope_3090_cu126_v2/env.sh
set -u
export PYTHONNOUSERSITE=1 HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
/home/wanglin/miniconda3/envs/kvarn-serve/bin/python -m kvbench_progressive_online.online_reader_probe --batch "$BATCH"
