#!/usr/bin/env bash
set -euo pipefail
cd /home/wanglin/kvbench-3090-cu126
BATCH=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
trap 'rc=$?; printf "%s\n" "$rc" > "$BATCH/exit_code.txt"' EXIT
export KVARN_FAST_FLUSH=1
bash kvbench_progressive_online/run_qasper20.sh --task all --count 20 --concurrency 8 --gpu 0 --arms parent p211_full p211_adaptive --reuse-stride 1 --out "$BATCH/baseline"
for stride in 2 4 8 16; do
    bash kvbench_progressive_online/run_qasper20.sh --task all --count 20 --concurrency 8 --gpu 0 --arms p211_adaptive --reuse-stride "$stride" --out "$BATCH/stride$stride"
done
/home/wanglin/miniconda3/envs/kvarn-serve/bin/python -m kvbench_progressive_online.compare_reuse --batch "$BATCH"
