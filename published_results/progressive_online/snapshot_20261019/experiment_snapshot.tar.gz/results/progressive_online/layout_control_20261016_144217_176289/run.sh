#!/usr/bin/env bash
set -euo pipefail
cd /home/wanglin/kvbench-3090-cu126
BATCH=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
trap 'rc=$?; echo "$rc" > "$BATCH/exit_code.txt"' EXIT
bash kvbench_progressive_online/run_qasper20.sh --task all --count 20 --concurrency 8 --gpu 0 --arms parent p211_full --out "$BATCH/layout"
bash kvbench_progressive_online/run_qasper20.sh --task all --count 20 --concurrency 8 --gpu 0 --arms p211_adaptive --control-full-read --out "$BATCH/control_full"
