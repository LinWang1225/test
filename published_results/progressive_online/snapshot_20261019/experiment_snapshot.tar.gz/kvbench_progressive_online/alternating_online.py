"""Three-arm Latin-square online comparison with independent writer attribution."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
from types import SimpleNamespace
import traceback

import numpy as np
from kvbench_longcontext.common import atomic_json,checked_data,read_jsonl,write_jsonl,sha_file,describe
from .online_reader_probe import freeze_probe,analyze_point
from .run import DEFAULT_UPSTREAM,_client_python,_run_logged,_start_server,_stop_server,_gpu_idle
from .runtime import build,verify
from .fused_runtime import install


def summarize(root,results):
    comparisons=[];agreement=[]
    for dataset in ('qasper','hotpotqa'):
        for label in ('planar','fused'):
            changes=[]
            for round_index in (1,2,3):
                native=next(r for r in results if r['dataset']==dataset and r['arm']=='native' and r['round']==round_index)
                candidate=next(r for r in results if r['dataset']==dataset and r['arm']==label and r['round']==round_index)
                changes.append({'round':round_index,'tpot_change_pct':100*(candidate['tpot_s']['mean']/native['tpot_s']['mean']-1),
                    'ttft_change_pct':100*(candidate['ttft_s']['mean']/native['ttft_s']['mean']-1),
                    'throughput_change_pct':100*(candidate['output_tokens_per_s']/native['output_tokens_per_s']-1)})
                point=f'r01_{dataset}_C8'
                def records(arm):
                    return {r['case_id']:r for r in read_jsonl(root/'runs'/f'round{round_index}_{arm}'/point/'requests.jsonl')}
                base=records('native');other=records(label)
                for case_id,x in base.items():
                    y=other[case_id]
                    agreement.append({'dataset':dataset,'round':round_index,'arm':label,'case_id':case_id,
                        'raw_content_equal':x['raw_content']==y['raw_content'],
                        'reasoning_equal':x['reasoning_content']==y['reasoning_content'],
                        'completion_tokens_equal':x['completion_tokens']==y['completion_tokens'],
                        'tpot_change_pct':100*(y['tpot_s']/x['tpot_s']-1)})
            comparisons.append({'dataset':dataset,'arm':label,'round_changes':changes,
                'median_tpot_change_pct':statistics.median(r['tpot_change_pct'] for r in changes),
                'all_rounds_tpot_improve':all(r['tpot_change_pct']<0 for r in changes)})
    atomic_json(root/'comparison.json',comparisons);atomic_json(root/'generation_agreement.json',agreement)
    atomic_json(root/'readout.json',{'comparisons':comparisons,'measured_requests':144,
        'agreement_records':len(agreement),
        'raw_and_reasoning_equal':sum(r['raw_content_equal'] and r['reasoning_equal'] for r in agreement),
        'limits':['Only 8 frozen prompts per dataset and three sessions per arm',
                  '64-token capped greedy output; text agreement is not token-logit equivalence or task-quality validation',
                  'Native deployment defaults retained; not an exhaustive best-native tuning search',
                  'Runtime restart and round-level pairing reduce, but do not eliminate time drift',
                  'Physical DRAM bytes unavailable']})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();root=a.out.resolve();root.mkdir(parents=True,exist_ok=False)
    state={'status':'running','phase':'preflight','pid':os.getpid()}
    atomic_json(root/'status.json',state)
    try:
        _gpu_idle('0')
        cfg=json.loads(Path(DEFAULT_UPSTREAM).read_text())['settings']
        if Path(sys.prefix).name!=cfg['server_env']:raise ValueError('Wrong environment')
        freeze_probe(Path(cfg['data']),root/'data')
        manifest=json.loads((root/'data/manifest.json').read_text());manifest['settings']['max_new_tokens']=64
        for info in manifest['datasets'].values():
            rows=read_jsonl(root/'data'/info['file'])
            for row in rows:row.update(max_tokens=64,generation_budget_tokens=64)
            write_jsonl(root/'data'/info['file'],rows)
            info.update(sha256=sha_file(root/'data'/info['file']),max_tokens=64,generation_budget_tokens=describe([64]*len(rows)))
        atomic_json(root/'data/manifest.json',manifest);checked_data(root/'data')
        order=[['native','planar','fused'],['planar','fused','native'],['fused','native','planar']]
        atomic_json(root/'plan.json',{'started':datetime.now().isoformat(),'round_order':order,
            'purpose':'Contemporaneous three-arm deployment comparison and write-path attribution',
            'full_read':'K4V4 all arms; native packed layout versus planes211; default reader configs',
            'requests':144,'datasets':['qasper','hotpotqa'],'requests_each':8,'concurrency':8,
            'measured_output_cap':64,'warmup':'All eight actual long prompts before each point, output cap32',
            'generation':'greedy; no task-quality claim from truncated output',
            'profiling':'Actual backend fixture in separate subprocess before online timing; no online profiler',
            'no_overwrite':True,'dram_bytes':None})
        env=os.environ.copy();env.pop('PYTHONHOME',None);env.pop('PYTHONPATH',None);env.pop('KVBENCH_PROFILE_DIR',None)
        env.update(PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',KVARN_FAST_FLUSH='1')
        runtimes={}
        for label in ('native','planar','fused'):
            arm='parent' if label=='native' else 'p211_full'
            runtime=root/'runtimes'/label;build(runtime,arm)
            if label=='fused':install(runtime,arm)
            verify(runtime,arm);runtimes[label]=runtime
            state.update(phase='flush_profile_'+label);atomic_json(root/'status.json',state)
            worker_env=dict(env,PYTHONPATH=str(runtime)+os.pathsep+str(Path.cwd()))
            command=['-m','kvbench_progressive_online.flush_breakdown','--out',root/'flush'/label,'--arm',label]
            if _run_logged(sys.executable,command,root/'logs'/(label+'.flush.log'),worker_env,Path.cwd()):
                raise RuntimeError('Writer breakdown failed: '+label)
        baseline=np.load(root/'flush/native/native_layout_records.npy',allow_pickle=False)
        for label in ('planar','fused'):
            np.testing.assert_array_equal(baseline,np.load(root/'flush'/label/'native_layout_records.npy',allow_pickle=False))
        atomic_json(root/'writer_byte_gate.json',{'passed':True,'check':'Full actual cache record, packed planes converted to native layout; same deterministic K/V input',
            'scope':'Two physical pages x8 heads including scales, zero points and padding'})
        args=SimpleNamespace(model=Path(cfg['model']),max_model_len=cfg['max_model_len'],max_seqs=cfg['max_seqs'],
            batch_tokens=cfg['batch_tokens'],server_seed=cfg['server_seed'],port=18187,gpu='0',gpu_util=.85,
            startup_timeout=1800,eager=False,repo=Path(__file__).resolve().parents[1])
        results=[]
        for round_index,labels in enumerate(order,1):
            for label in labels:
                session=f'round{round_index}_{label}';state.update(phase=session);atomic_json(root/'status.json',state)
                arm='parent' if label=='native' else 'p211_full';proc=log=None
                try:
                    proc,log,launch=_start_server(args,arm,runtimes[label],root/'servers'/session,root/'logs'/(session+'.server.log'),env)
                    record=json.loads(launch.read_text());record['config']['method']=label
                    launch=root/'servers'/session/'comparison.launch.json';atomic_json(launch,record)
                    command=['-m','kvbench_longcontext.run','--data-dir',root/'data','--out',root/'runs'/session,
                        '--server-manifest',launch,'--concurrency','8','--repeats','1',
                        '--temperature','0','--top-p','1','--top-k','-1','--min-p','0','--seed',str(cfg['request_seed']),
                        '--request-timeout','300','--warmup','1','--warmup-per-point','8','--gpu','0',
                        '--sample-interval','1','--save-metrics-samples']
                    if _run_logged(_client_python(cfg),command,root/'logs'/(session+'.client.log'),env,args.repo):
                        raise RuntimeError('Measurement failed: '+session)
                    for summary in sorted((root/'runs'/session).glob('r*/performance.summary.json')):
                        result=analyze_point(summary.parent)
                        if not result['measurement_complete'] or result['valid_responses']!=8:raise ValueError('Incomplete point')
                        results.append(dict(arm=label,round=round_index,session=session,**result))
                    atomic_json(root/'measurements.json',results)
                finally:
                    try:_stop_server(proc)
                    finally:
                        if log is not None:log.close()
        summarize(root,results)
        state.update(status='completed',phase='completed',finished=datetime.now().isoformat());atomic_json(root/'status.json',state)
    except BaseException as exc:
        state.update(status='failed',error=repr(exc),traceback=traceback.format_exc());atomic_json(root/'status.json',state);raise


if __name__=='__main__':main()
