"""Small real-backend flush attribution; separate from online performance."""
import argparse
import functools
import json
import os
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import torch
from kvbench_longcontext.common import atomic_json
from .codec import unpack_numpy
from .profile_components import measure


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--arm',choices=['native','planar','fused'],required=True)
    a=p.parse_args();out=a.out;out.mkdir(parents=True,exist_ok=False)
    import vllm
    from vllm.v1.attention.backends import kvarn_attn as backend
    from vllm.v1.attention.ops import kvarn_store as writer
    from vllm.model_executor.layers.quantization.kvarn.config import KVarNConfig
    cfg=KVarNConfig();heads=8;bids=[6,2];slots=[1,3];group=('flush_breakdown',os.getpid())
    generator=torch.Generator(device='cuda').manual_seed(9107)
    pool_k=torch.randn((4,128,heads,128),device='cuda',generator=generator,dtype=torch.float16)
    pool_v=torch.randn((4,128,heads,128),device='cuda',generator=generator,dtype=torch.float16)
    cache=torch.zeros((9,heads,cfg.tile_bytes_aligned),device='cuda',dtype=torch.uint8)
    impl=SimpleNamespace(kvarn_config=cfg,num_kv_heads=heads,_group_key=group,_tails={},
        _tail_K_pool=pool_k,_tail_V_pool=pool_v)
    backend.KVarNAttentionImpl._block_to_slot_dict[group]=dict(zip(bids,slots))
    def flush():
        impl._tails={bid:None for bid in bids}
        backend.KVarNAttentionImpl._batched_flush([(impl,bid,cache) for bid in bids])
    os.environ['KVARN_FAST_FLUSH']='1'
    # Warm compile before measurement or profiling.
    for _ in range(3):flush()
    torch.cuda.synchronize()
    timing=measure(flush,10,5)
    saved=cache[bids].cpu().numpy().copy()
    if a.arm!='native':
        for start,size in ((0,cfg.k_packed_bytes),(cfg.v_packed_offset,cfg.v_packed_bytes)):
            part=saved[:,:,start:start+size].reshape(-1,128,64)
            codes=unpack_numpy(part,128)
            saved[:,:,start:start+size]=(codes[...,::2] | (codes[...,1::2]<<4)).reshape(2,heads,size)
    np.save(out/'native_layout_records.npy',saved)
    def annotate(module,name,label):
        original=getattr(module,name)
        @functools.wraps(original)
        def wrapped(*args,**kwargs):
            with torch.profiler.record_function(label):return original(*args,**kwargs)
        setattr(module,name,wrapped)
    for name,label in (('_sinkhorn_pack_kv','sinkhorn_quant_pack'),('kvarn_sinkhorn_triton','sinkhorn'),
        ('kvarn_store_tile_k_batch_from_sinkhorn','K_quant_pack'),
        ('kvarn_store_tile_v_batch_from_sinkhorn','V_quant_pack')):
        annotate(backend,name,label)
    annotate(writer,'_pack_lowbit','bit_packing')
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                           torch.profiler.ProfilerActivity.CUDA]) as prof:
        for _ in range(3):
            with torch.profiler.record_function('actual_fast_flush'):flush()
            torch.cuda.synchronize()
    trace=out/'flush.trace.json';prof.export_chrome_trace(str(trace))
    events=json.loads(trace.read_text())['traceEvents']
    phases=[]
    labels={'actual_fast_flush','sinkhorn_quant_pack','sinkhorn','K_quant_pack','V_quant_pack','bit_packing'}
    for span in events:
        if span.get('name') not in labels or span.get('cat')!='user_annotation' or span.get('pid')==0:continue
        children=[e for e in events if e.get('pid')==span['pid'] and e.get('tid')==span['tid']
            and e.get('ph')=='X' and e.get('ts',0)>=span['ts']
            and e.get('ts',0)+e.get('dur',0)<=span['ts']+span['dur']]
        correlations={e.get('args',{}).get('correlation') for e in children
            if e.get('cat') in ('cuda_runtime','cuda_driver')};correlations.discard(None)
        kernels=[e for e in events if e.get('cat')=='kernel'
            and e.get('args',{}).get('correlation') in correlations]
        phases.append({'phase':span['name'],'cpu_span_us':span['dur'],'gpu_kernel_count':len(kernels),
            'gpu_sum_us':sum(e.get('dur',0) for e in kernels)})
    # Explicit record assembly/scatter operators outside the pack stage.
    extra=[]
    packspans=[e for e in events if e.get('name')=='sinkhorn_quant_pack'
               and e.get('cat')=='user_annotation' and e.get('pid')!=0]
    for e in events:
        if e.get('cat')!='cpu_op' or e.get('name') not in ('aten::cat','aten::index_put_','aten::index_select'):continue
        if any(e.get('tid')==s['tid'] and s['ts']<=e['ts']<s['ts']+s['dur'] for s in packspans):continue
        extra.append({'operation':e['name'],'cpu_span_us':e['dur']})
    atomic_json(out/'result.json',{'arm':a.arm,'vllm_origin':vllm.__file__,'timing':timing,
        'phases':phases,'assembly_scatter_gather_cpu_ops':extra,
        'limits':['Two pages x eight heads, not full serving workload',
                  'Phase timings overlap by nesting; never add inclusive durations',
                  'CUDA event eager interval includes host launch gaps',
                  'No physical DRAM counters; profiler adds overhead']})


if __name__=='__main__':main()
