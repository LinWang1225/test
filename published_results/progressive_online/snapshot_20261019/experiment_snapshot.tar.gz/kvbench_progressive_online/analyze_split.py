"""Read-only component and online attribution, updated as a split batch completes."""
import argparse,json,statistics,time
from pathlib import Path
from kvbench_longcontext.common import atomic_json
from .split_probe import LABELS

def analyze(root):
 components={};readers={}
 for label in LABELS:
  p=root/'components'/label/'result.json'
  if p.exists():components[label]=json.loads(p.read_text())
  p=root/'components'/label/'reader.json'
  if p.exists():readers[label]=json.loads(p.read_text())
 pairs=[]
 for base,candidate in [('native','tile_full'),('native','tile_k2'),('native','split_full'),('native','split_k2'),('tile_full','split_full'),('tile_k2','split_k2'),('split_full','split_k2')]:
  r={'baseline':base,'candidate':candidate}
  if base in components and candidate in components:
   b=components[base];c=components[candidate]
   r['flush_event_change_pct']=100*(c['flush_cuda_event']['median_us']/b['flush_cuda_event']['median_us']-1)
   r['flush_wall_change_pct']=100*(c['flush_synchronized_wall_us']/b['flush_synchronized_wall_us']-1)
  if base in readers and candidate in readers:
   by={(x['trace'],x['block_n']):x for x in readers[base]};matched=[]
   for x in readers[candidate]:
    b=by.get((x['trace'],x['block_n']))
    if b:matched.append(dict(trace=x['trace'],block_n=x['block_n'],baseline_us=b['median_us'],candidate_us=x['median_us'],change_pct=100*(x['median_us']/b['median_us']-1)))
   r['reader_matched']=matched
   if matched:r['reader_matched_median_change_pct']=statistics.median(x['change_pct'] for x in matched)
  pairs.append(r)
 online=json.loads((root/'comparison.json').read_text()) if (root/'comparison.json').exists() else None
 atomic_json(root/'attribution.json',{'component_pairs':pairs,'online':online,'limits':['Negative change is faster','Reader comparison fixes input and launch geometry; online uses each arm default autotune','Backend flush uses only two physical pages; not an additive estimate of full serving time','Global layout changes reader addressing and writer scatter; same-precision online pairs measure their combined effect','No DRAM, occupancy or spill attribution without counters','No adaptive controller in these five arms']})
 return pairs

def main():
 p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--watch',action='store_true');a=p.parse_args()
 while True:
  analyze(a.root)
  state=json.loads((a.root/'status.json').read_text())
  if not a.watch or state['status'] in ('completed','failed'):break
  time.sleep(20)

if __name__=='__main__':main()
