"""Exploratory per-head query-adaptive read budget, not a ReadKV reproduction.

K2/V2 is the base. Exactly two of eight KV heads get K4 for the current query.
Selection is one GPU kernel, using calibration from a disjoint trace. No claim
of an error certificate, task-quality preservation, or token-adaptive V policy.
"""
import argparse
import json
from pathlib import Path
import traceback

import numpy as np
import torch
import triton
import triton.language as tl

from kvbench_longcontext.common import atomic_json
from kvbench_residual_diag.common import load_trace,trace_paths
from .profile_components import measure
from .run_ablation import load_file,prepare,fixed_oracle
from .validate_reuse import load_module


@triton.jit
def _select(Q,C,P):
    b=tl.program_id(0)
    h=tl.arange(0,8)
    j=tl.arange(0,512)
    q=tl.load(Q+b*4096+h[:,None]*512+j[None,:]).to(tl.float32)
    c=tl.load(C+h)
    score=tl.sum(q*q,1)*c
    # Stable tie-break: smaller head index wins. Exactly two refinements.
    rank=tl.sum(((score[None,:]>score[:,None]) |
                 ((score[None,:]==score[:,None]) & (h[None,:]<h[:,None]))).to(tl.int32),1)
    tl.store(P+b*8+h,tl.where(rank<2,4,2))


def selector(q,calibration,plan):
    _select[(q.shape[0],)](q,calibration,plan,num_warps=4)


def source_with_plan(source):
    old='    PG_DIAG_PTR=None,\n'
    if source.count(old)!=2:raise ValueError('Expected both fused attention kernels')
    source=source.replace(old,'    PG_PLAN_PTR=None,\n'+old)
    old='                ar_k_depth_2: tl.constexpr = True'
    if source.count(old)!=2:raise ValueError('Unexpected K2 baseline')
    return source.replace(old,'                ar_k_depth_2 = tl.load(PG_PLAN_PTR + b * 8 + hk) == 2')


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--operator-run',type=Path,required=True)
    p.add_argument('--traces',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    atomic_json(out/'status.json',{'status':'running'})
    try:
        decision=json.loads((a.operator_run/'reader_decision.json').read_text())
        if 'fixed_k2v2' not in decision['qualifying_variants']:
            atomic_json(out/'status.json',{'status':'skipped','reason':'Fixed reader did not pass headroom gate'});return
        from .run import _gpu_idle
        _gpu_idle('0')
        paths=trace_paths(a.traces,3)
        calibration_data,calmeta=load_trace(paths[0]);calreplay=prepare(calibration_data,64)
        # Calibrated squared dequantization residual envelope per KV head.
        calibration=calreplay.metadata[:,:,0].square().mean(0).contiguous()
        del calreplay
        atomic_json(out/'calibration.json',{'trace':paths[0].name,'head_weights':calibration.cpu().tolist(),
            'objective':'query squared norm times calibrated squared K2 residual envelope',
            'budget':'exactly 2/8 heads K4, remaining K2; V fixed2',
            'scope':'heuristic head-level allocation, no formal output-error guarantee'})
        path=out/'budget_reader.py'
        path.write_text(source_with_plan((a.operator_run/'variants/fixed_k2v2.py').read_text()))
        candidate=load_file(path,'budget_candidate')
        native=load_module(a.operator_run/'runtime_native','budget_native')
        low=load_file(a.operator_run/'variants/fixed_k2v2.py','budget_fixed2')
        # Independent selector and attention arithmetic checks.
        from kvbench_residual.fixtures import Case,build_case
        fixture=build_case(Case('budget_contract',(385,),hq=32,hk=8))
        replay=prepare(fixture,64);plan=torch.empty((1,8),device='cuda',dtype=torch.int32)
        checks=[]
        for factor_head in (0,3,7):
            replay.gpu.t['query'].copy_(torch.from_numpy(fixture['query']).cuda())
            replay.gpu.t['query'][:,factor_head*4:(factor_head+1)*4].mul_(10)
            selector(replay.gpu.t['query'],calibration,plan)
            score=replay.gpu.t['query'].float().reshape(1,8,512).square().sum(-1)*calibration
            expected=torch.full_like(plan,2);expected.scatter_(1,torch.argsort(score,dim=1,descending=True,stable=True)[:,:2],4)
            torch.testing.assert_close(plan,expected,rtol=0,atol=0)
            fixture_now=dict(fixture,query=replay.gpu.t['query'].cpu().numpy())
            lo=fixed_oracle(fixture_now,2,2);hi=fixed_oracle(fixture_now,4,2)
            expected_output=np.where((plan.cpu().numpy().repeat(4,axis=1)==4)[...,None],hi,lo)
            actual=replay.launch(candidate,'split',extra={'PG_PLAN_PTR':plan}).cpu().numpy().reshape(1,32,128)
            np.testing.assert_allclose(actual,expected_output,rtol=.02,atol=.002)
            checks.append({'amplified_head':factor_head,'plan':plan.cpu().tolist()})
        atomic_json(out/'correctness.json',checks)
        rows=[]
        for trace in paths[1:]:
            data,meta=load_trace(trace);replay=prepare(data,64);g=replay.gpu
            g.splits=32;g.mid_o=torch.zeros((g.hq,32,g.d),device='cuda')
            g.mid_lse=torch.full((g.hq,32),-float('inf'),device='cuda')
            plan=torch.empty((1,8),device='cuda',dtype=torch.int32)
            selector(g.t['query'],calibration,plan)
            dynamic_plan=plan.clone()
            static_plan=torch.full_like(plan,2)
            static_plan[:,torch.argsort(calibration,descending=True,stable=True)[:2]]=4
            def dynamic():
                selector(g.t['query'],calibration,plan)
                return replay.launch(candidate,'split',extra={'PG_PLAN_PTR':plan})
            def fixed():return replay.launch(candidate,'split',extra={'PG_PLAN_PTR':static_plan})
            operations={'native':lambda:replay.launch(native,'split'),
                        'fixed_k2v2':lambda:replay.launch(low,'split'),
                        'static_same_budget':fixed,'query_adaptive_including_selector':dynamic}
            reference=replay.launch(native,'split').clone();graphs={};outputs={}
            for name,fn in operations.items():
                fn();torch.cuda.synchronize();graph=torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):fn()
                graph.replay();torch.cuda.synchronize();outputs[name]=g.out.clone();graphs[name]=graph
            timings={name:[] for name in operations};names=list(operations)
            for repeat in range(3):
                for name in names[repeat:]+names[:repeat]:timings[name].append(measure(graphs[name].replay,30,5)['median_us'])
            for name in names:
                diff=(outputs[name]-reference).float()
                rows.append({'trace':trace.name,'dataset':meta['request']['dataset'],'variant':name,
                    'batch':1,'splits':32,'block_n':64,'round_medians_us':timings[name],
                    'relative_l2_vs_native':float(diff.norm()/reference.float().norm().clamp_min(1e-12)),
                    'query_plan':dynamic_plan.cpu().tolist(),'static_plan':static_plan.cpu().tolist()})
            atomic_json(out/'timings.json',rows)
        atomic_json(out/'status.json',{'status':'completed',
            'limits':['Held-out traces exclude calibration trace; only two held-out snapshots',
                      'B1 operator study; requires heterogeneous C8 and task-quality validation',
                      'Includes selector in graph timings, no temporal reuse',
                      'Read budget counts payload only; no hardware DRAM counters']})
    except BaseException as exc:
        atomic_json(out/'status.json',{'status':'failed','error':repr(exc)});traceback.print_exc();raise


if __name__=='__main__':main()
