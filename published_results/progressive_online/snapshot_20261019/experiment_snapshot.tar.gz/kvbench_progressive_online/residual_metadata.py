"""Offline residual bounds for progressive K precision selection."""
from __future__ import annotations

from dataclasses import asdict
import hashlib
import json
from pathlib import Path

import numpy as np

from .precision import DEFAULT_K_LEVELS, PrecisionLevel, validate_levels


SCHEMA = "kvbench.progressive_k_residual.v1"


def _approximate_codes(codes: np.ndarray, bits: int, source_bits: int) -> np.ndarray:
    if bits >= source_bits:
        return codes.astype(np.float32)
    discarded = source_bits - bits
    retained = codes.astype(np.int32) >> discarded
    midpoint = (1 << discarded) / 2.0 - 0.5
    return (retained.astype(np.float32) * (1 << discarded) + midpoint)


def residual_bounds(
    codes: np.ndarray,
    levels: tuple[PrecisionLevel, ...] = DEFAULT_K_LEVELS,
    *,
    source_bits: int = 4,
    column_scale: np.ndarray | None = None,
    row_scale: np.ndarray | None = None,
) -> np.ndarray:
    """Return conservative max absolute dequantization error per tile/level.

    ``codes`` has shape ``(..., D, G)``.  The returned array has shape
    ``(..., len(levels))`` and is suitable for a sidecar indexed by KV tile.
    The highest level is exact when it is at least ``source_bits``.
    """
    validate_levels(levels)
    codes = np.asarray(codes)
    if codes.ndim < 2 or np.any(codes < 0) or np.any(codes >= (1 << source_bits)):
        raise ValueError("codes must be (..., D, G) within the source bit range")
    d, g = codes.shape[-2:]
    col = np.ones(d, dtype=np.float32) if column_scale is None else np.asarray(column_scale, dtype=np.float32)
    row = np.ones(g, dtype=np.float32) if row_scale is None else np.asarray(row_scale, dtype=np.float32)
    if col.shape != (d,) or row.shape != (g,):
        raise ValueError("scale shapes must match the final two code dimensions")
    exact = codes.astype(np.float32)
    scale = np.abs(col[..., :, None] * row[..., None, :])
    result = []
    for level in levels:
        error = np.abs(exact - _approximate_codes(codes, level.bits, source_bits)) * scale
        result.append(np.max(error, axis=(-2, -1)))
    return np.stack(result, axis=-1).astype(np.float32)


def write_residual_sidecar(
    path: Path,
    codes: np.ndarray,
    levels: tuple[PrecisionLevel, ...] = DEFAULT_K_LEVELS,
    *,
    source_bits: int = 4,
    column_scale: np.ndarray | None = None,
    row_scale: np.ndarray | None = None,
) -> dict:
    """Generate a compressed sidecar and its JSON manifest."""
    path = Path(path)
    bounds = residual_bounds(
        codes, levels, source_bits=source_bits,
        column_scale=column_scale, row_scale=row_scale,
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(path, bounds=bounds)
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    manifest = {
        "schema": SCHEMA,
        "data": path.name,
        "sha256": digest,
        "shape": list(bounds.shape),
        "dtype": str(bounds.dtype),
        "source_bits": source_bits,
        "levels": [asdict(level) for level in levels],
        "indexing": "leading dimensions match KVarN tile indices; final dimension is precision level",
    }
    path.with_suffix(".json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


def load_residual_sidecar(path: Path) -> tuple[np.ndarray, dict]:
    path = Path(path)
    manifest_path = path.with_suffix(".json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if manifest.get("schema") != SCHEMA:
        raise ValueError(f"Unsupported residual metadata schema: {manifest.get('schema')!r}")
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    if digest != manifest.get("sha256"):
        raise ValueError("Residual metadata checksum mismatch")
    with np.load(path) as archive:
        bounds = np.asarray(archive["bounds"])
    if list(bounds.shape) != manifest.get("shape") or str(bounds.dtype) != manifest.get("dtype"):
        raise ValueError("Residual metadata shape or dtype does not match its manifest")
    return bounds, manifest


def load_residual_tensor(path: Path, device: str | None = None):
    """Load validated sidecar bounds as a contiguous fp32 torch tensor.

    The tensor is laid out as ``[num_blocks, num_kv_heads, 3]`` for the
    current 2/3/4-bit runtime and can be assigned to
    ``impl._progressive_residual_metadata``.
    """
    import torch

    bounds, manifest = load_residual_sidecar(path)
    levels = tuple(item["bits"] for item in manifest["levels"])
    if levels != (2, 3, 4) or bounds.ndim != 3 or bounds.shape[-1] != 3:
        raise ValueError("Runtime metadata must have shape [blocks, kv_heads, 3] for K4")
    tensor = torch.from_numpy(np.ascontiguousarray(bounds, dtype=np.float32))
    return tensor if device is None else tensor.to(device=device)


def torch_residual_bounds_from_quantized(
    packed: "object",
    column_scale: "object",
    row_scale: "object",
    *,
    packing: str,
) -> "object":
    """Compute per-tile K residual bounds from the writer's quantized result.

    Inputs are batched K outputs from ``kvarn_store_tile_k_batch_from_sinkhorn``:
    packed ``[N, D, G/2]`` uint8, column scales ``[N, D]`` and row scales
    ``[N, G]``. ``packing`` is mandatory: ``planes_211`` for the transformed
    writer, or ``native_int4`` for native low/high nibble pairs. These formats
    have identical shapes; inferring the format from the tensor is unsafe.
    The result is ``[N, 3]`` fp32 for 2/3/4-bit selection.
    """
    import torch

    if packing not in ("planes_211", "native_int4"):
        raise ValueError("Specify packing='planes_211' or 'native_int4'")
    if packed.dtype != torch.uint8:
        raise ValueError("Packed K codes must be uint8")
    if packed.ndim != 3 or column_scale.ndim != 2 or row_scale.ndim != 2:
        raise ValueError("Expected batched K packed codes and two-dimensional scales")
    n, d, packed_cols = packed.shape
    if column_scale.shape != (n, d) or row_scale.shape[0] != n or packed_cols * 2 != row_scale.shape[1]:
        raise ValueError("Quantized K result shapes do not agree")
    if packed.device != column_scale.device or packed.device != row_scale.device:
        raise ValueError("Packed K and scales must be on the same device")
    if packing == "planes_211":
        from .codec import unpack_211_torch
        codes = unpack_211_torch(packed, packed_cols * 2)
    else:
        packed = packed.to(torch.int32)
        low_nibble = packed & 0xF
        high_nibble = packed >> 4
        codes = torch.stack((low_nibble, high_nibble), dim=-1).reshape(n, d, -1)
    codes = codes.to(torch.float32)
    scale = torch.abs(column_scale.to(torch.float32)[:, :, None] * row_scale.to(torch.float32)[:, None, :])
    err2 = torch.amax(torch.abs(codes - (codes // 4 * 4 + 1.5)) * scale, dim=(1, 2))
    err3 = torch.amax(torch.abs(codes - (codes // 4 * 4 + ((codes % 4) // 2) * 2 + 0.5)) * scale, dim=(1, 2))
    zero = torch.zeros_like(err2)
    return torch.stack((err2, err3, zero), dim=-1).contiguous()
