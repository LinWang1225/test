"""Mandatory real CUDA implementation checks, separate from online task scores."""
from __future__ import annotations

import argparse
import importlib.util
import json
from pathlib import Path
import sys

import numpy as np
import torch

from kvbench_longcontext.common import atomic_json
from kvbench_residual.fixtures import Case, GpuCase, build_case, unpack_block
from .codec import pack_numpy
from .residual_metadata import residual_bounds
from .runtime import build, verify
from .transform import DECODE


def load_module(root, name):
    spec = importlib.util.spec_from_file_location(name, root / 'vllm' / DECODE)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


class Replay:
    def __init__(self, data, block_n=32):
        self.gpu = GpuCase(data, splits=4, block_n=block_n)
        cfg = data['case'].layout
        planar = data['cache'].copy()
        meta = np.zeros((*planar.shape[:2], 3), np.float32)
        for bid in range(len(planar)):
            if data['block_to_slot'][bid] >= 0:
                continue
            for head in range(data['case'].hk):
                x = unpack_block(data, bid, head)
                for side, codes in [('K', x['kq']), ('V', x['vq'])]:
                    offset = cfg.offsets[side+'_PACKED_OFFSET']
                    packed = pack_numpy(codes.astype(np.uint8)).ravel()
                    planar[bid, head, offset:offset+len(packed)] = packed
                meta[bid, head] = residual_bounds(x['kq'], column_scale=x['sk'], row_scale=x['rk'])
        self.gpu.planar = torch.from_numpy(planar).cuda()
        self.metadata = torch.from_numpy(meta).cuda()
        self.state = torch.zeros((*planar.shape[:2], cfg.group//16, 5), dtype=torch.int32, device='cuda')

    def launch(self, module, mode='single', reuse=False, extra=None):
        g, t = self.gpu, self.gpu.t
        kv = t['cache'] if module.AR_POLICY_NAME == 'parent' else g.planar
        common = dict(MAX_BLOCKS_PER_REQ=t['block_table'].shape[1], D=g.d, GROUP=128,
                      Q_PER_KV=g.hq//g.hk, Q_PER_KV_PAD=g.hq//g.hk,
                      SLIDING_WINDOW=0, K_BITS=4, V_BITS=4,
                      NUM_BLOCKS_LOOKUP=kv.shape[0], VQ_INDIRECT=False,
                      **g.data['case'].layout.offsets)
        if hasattr(module, '_progressive_test_adaptive'):
            common.update(AR_RESIDUAL_PTR=self.metadata, AR_RESIDUAL_ENABLED=True,
                          AR_REUSE_PTR=self.state, AR_REUSE_ENABLED=reuse)
        if extra:
            common.update(extra)
        args = (t['query'], t['req_rows'], t['block_table'], t['seq_lens'], t['block_to_slot'],
                kv, t['pool_k'], t['pool_v'])
        strides = (g.hq*g.d, g.d, t['block_table'].stride(0), kv.stride(0), kv.stride(1),
                   t['pool_k'].stride(0), t['pool_k'].stride(1), t['pool_k'].stride(2))
        kw = dict(BLOCK_N=g.block_n, num_warps=g.num_warps, num_stages=g.num_stages)
        if mode == 'single':
            module._kvarn_fused_decode_kernel.fn[(g.b,g.hk)](
                *args, g.out, g.data['scale'], *strides, g.hq*g.d, g.d, **common, **kw)
        else:
            module._kvarn_fused_decode_stage1.fn[(g.b,g.hk,g.splits)](
                *args, g.mid_o, g.mid_lse, g.data['scale'], *strides,
                g.mid_o.stride(0), g.mid_o.stride(1), g.mid_lse.stride(0),
                NUM_KV_SPLITS=g.splits, HQ=g.hq, **common, **kw)
            module._kvarn_fused_decode_stage2[(g.b*g.hq,)](
                g.mid_o,g.mid_lse,g.out,g.mid_o.stride(0),g.mid_o.stride(1),
                g.mid_lse.stride(0),g.out.stride(0),D=g.d,NUM_KV_SPLITS=g.splits,num_warps=2)
        return g.out


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=False)
    atomic_json(out/'status.json', {'status':'running'})
    try:
        modules = {}
        for stride in (1,2,4,8,16):
            runtime = out/f'runtime_s{stride}'
            build(runtime,'p211_adaptive',reuse_stride=stride)
            verify(runtime,'p211_adaptive')
            modules[stride] = load_module(runtime, f'progressive_gate_s{stride}')
            modules[stride]._progressive_test_adaptive = True
        control_root = out/'runtime_control'
        build(control_root,'p211_adaptive',{k:-1.0 for k in ('k2','k3','v2','v3')})
        control = load_module(control_root,'progressive_gate_control')
        control._progressive_test_adaptive = True
        parent_root = out/'runtime_parent'
        build(parent_root,'parent')
        parent = load_module(parent_root,'progressive_gate_parent')
        fixture = build_case(Case('reuse_gate',(511,),hq=32,hk=8))
        replay = Replay(fixture)
        q = replay.gpu.t['query'].clone()
        rows = []
        for mode in ('single','split'):
            for stride, module in modules.items():
                replay.state.zero_()
                for step in range(20):
                    replay.gpu.t['seq_lens'].fill_(385+step)
                    factor = (0.0, .001, .01, .1, 1., 20.)[step%6]
                    replay.gpu.t['query'].copy_(q*factor)
                    reference = replay.launch(modules[1],mode).clone()
                    candidate = replay.launch(module,mode,reuse=True).clone()
                    torch.cuda.synchronize()
                    assert torch.isfinite(candidate).all(), 'Nonfinite adaptive result'
                    if stride == 1:
                        torch.testing.assert_close(candidate,reference,rtol=0,atol=0)
                    # Assert EVERY cached low-precision choice is admissible now.
                    state = replay.state
                    norm = replay.gpu.t['query'].reshape(1,8,4,128).abs().float().sum(-1).amax(-1)[0]
                    errors = replay.metadata * norm[None,:,None] * abs(fixture['scale'])
                    used = state[...,0] > 0
                    for depth, threshold, index in ((2,.08,0),(3,.04,1)):
                        selected = used & (state[...,1] == depth)
                        # Stale unused tail chunks are excluded by active physical page mask below.
                        active = torch.zeros_like(selected)
                        for logical,bid in enumerate(fixture['block_table'][0,:3]):
                            if fixture['block_to_slot'][bid] < 0:
                                active[bid,:,::replay.gpu.block_n//16] = True
                        assert not ((errors[:,:,index,None] > threshold+1e-6) & selected & active).any(), 'Unsafe reused depth'
                    rows.append({'mode':mode,'stride':stride,'step':step,'query_factor':factor,
                                 'max_abs_vs_stride1':float((candidate-reference).abs().max())})
                # Simulate flush invalidation, sequence reset, and hostile stale depth.
                replay.state.zero_()
                replay.gpu.t['seq_lens'].fill_(385)
                replay.gpu.t['query'].zero_()
                replay.launch(module,mode,reuse=True)
                replay.gpu.t['seq_lens'].fill_(386)
                replay.gpu.t['query'].copy_(q*20)
                replay.launch(module,mode,reuse=True)
                assert not (replay.state[...,1] == 2).any(), 'Query drift did not refresh'
                # Force each invalidation path while keeping query admissible.
                for event in ('first_block_changed','chunk_shape_changed','expired','sequence_reset','flush'):
                    replay.gpu.t['query'].zero_()
                    replay.gpu.t['seq_lens'].fill_(400)
                    replay.state.zero_()
                    replay.launch(module,mode,reuse=True)
                    if event == 'first_block_changed':
                        replay.state[...,3].fill_(-99)
                    elif event == 'chunk_shape_changed':
                        replay.state[...,2].fill_(64)
                    elif event == 'flush':
                        replay.state.zero_()
                    replay.gpu.t['seq_lens'].fill_(
                        400+stride if event == 'expired' else 399 if event == 'sequence_reset' else 401)
                    replay.launch(module,mode,reuse=True)
                    state=replay.state.cpu().numpy()
                    current=int(replay.gpu.t['seq_lens'].item())
                    occupied=state[...,1]>0
                    assert np.all(state[...,0][occupied] == current), event+' did not invalidate'
            replay.gpu.t['query'].copy_(q)
            replay.gpu.t['seq_lens'].fill_(511)
            original = replay.launch(parent,mode).clone()
            full = replay.launch(control,mode).clone()
            torch.testing.assert_close(full,original,atol=.02,rtol=.02)
        # CUDA graph must see new query/length values and preserve valid state updates.
        replay.state.zero_()
        replay.gpu.t['seq_lens'].fill_(385)
        replay.gpu.t['query'].zero_()
        replay.launch(modules[4],reuse=True)
        torch.cuda.synchronize()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            replay.launch(modules[4],reuse=True)
        replay.state.zero_()
        for factor in (0.,20.,.01):
            replay.gpu.t['seq_lens'].add_(1)
            replay.gpu.t['query'].copy_(q*factor)
            saved=replay.state.clone()
            graph.replay()
            torch.cuda.synchronize()
            assert torch.isfinite(replay.gpu.out).all()
            graph_output=replay.gpu.out.clone()
            replay.state.copy_(saved)
            eager_output=replay.launch(modules[4],reuse=True).clone()
            torch.testing.assert_close(graph_output,eager_output,rtol=0,atol=0)
        # Genuine saved parent inputs, never relabel sparse trace steps as contiguous.
        from kvbench_residual_diag.common import load_trace, trace_paths
        trace_dir=Path(__file__).resolve().parents[1]/'results/residual_diag/run_20261012_161428_3993496/traces'
        trace_rows=[]
        for trace in trace_paths(trace_dir,limit=3):
            data,meta=load_trace(trace)
            real=Replay(data,block_n=meta['block_n'])
            native=real.launch(parent,meta['mode']).clone()
            torch.testing.assert_close(native.view_as(torch.from_numpy(data['reference_gpu_rot']).cuda()),
                                       torch.from_numpy(data['reference_gpu_rot']).cuda(),atol=.02,rtol=.02)
            reference=real.launch(modules[1],meta['mode']).clone()
            for stride,module in modules.items():
                real.state.zero_()
                candidate=real.launch(module,meta['mode'],reuse=True).clone()
                torch.testing.assert_close(candidate,reference,atol=0,rtol=0)
            trace_rows.append({'trace':trace.name,'case_id':meta['request']['case_id'],
                               'decode_call_index':meta['decode_call_index'],
                               'scope':'cold-cache stride equivalence on real GPU trace; not cross-step task quality'})
        atomic_json(out/'real_trace_checks.json',trace_rows)
        atomic_json(out/'measurements.json',rows)
        atomic_json(out/'status.json',{'status':'completed','gpu':torch.cuda.get_device_name(),
                    'checks':['single/split stride1 exact equivalence','current-query low-depth bound',
                              'hostile query drift','full-read vs native parent','CUDA graph replay'],
                    'scope':'synthetic CUDA implementation gate; not online task quality or speed'})
    except BaseException as exc:
        atomic_json(out/'status.json',{'status':'failed','error':repr(exc)})
        raise


if __name__ == '__main__':
    main()
