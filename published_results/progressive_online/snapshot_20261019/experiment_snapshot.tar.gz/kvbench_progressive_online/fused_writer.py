"""Experimental CUDA pack/metadata fusion, independent of installed vLLM.

Input is already quantized: this does not fuse Sinkhorn or quantization.
"""
import torch
import triton
import triton.language as tl


@triton.jit
def _pack(Q, P, C, R, E, ROWS: tl.constexpr, COLS: tl.constexpr,
          META: tl.constexpr, B: tl.constexpr):
    tile = tl.program_id(0)
    i = tl.arange(0, B)
    n: tl.constexpr = ROWS * COLS
    # Every output byte has exactly one owner. No atomics or workspace.
    a = tl.load(Q + tile*n + i*4, i < n//4, 0).to(tl.int32) & 15
    b = tl.load(Q + tile*n + i*4+1, i < n//4, 0).to(tl.int32) & 15
    c = tl.load(Q + tile*n + i*4+2, i < n//4, 0).to(tl.int32) & 15
    d = tl.load(Q + tile*n + i*4+3, i < n//4, 0).to(tl.int32) & 15
    hi = (a >> 2) | ((b >> 2) << 2) | ((c >> 2) << 4) | ((d >> 2) << 6)
    tl.store(P + tile*n//2+i, hi, i < n//4)
    m = tl.full((B,), 0, tl.int32)
    l = tl.full((B,), 0, tl.int32)
    for j in tl.static_range(8):
        q = tl.load(Q + tile*n+i*8+j, i < n//8, 0).to(tl.int32) & 15
        m |= ((q >> 1) & 1) << j
        l |= (q & 1) << j
    tl.store(P + tile*n//2+n//4+i, m, i < n//8)
    tl.store(P + tile*n//2+3*n//8+i, l, i < n//8)
    if META:
        # Full tile reduction, FP32 multiplication matches the validated helper.
        q = tl.load(Q + tile*n+i, i < n, 0).to(tl.int32) & 15
        col = tl.load(C + tile*ROWS+i//COLS, i < n, 0).to(tl.float32)
        row = tl.load(R + tile*COLS+i%COLS, i < n, 0).to(tl.float32)
        scale = tl.abs(col*row)
        err2 = tl.max(tl.where(i < n, tl.abs((q%4).to(tl.float32)-1.5)*scale, 0), 0)
        err3 = tl.max(tl.where(i < n, 0.5*scale, 0), 0)
        tl.store(E + tile*3, err2)
        tl.store(E + tile*3+1, err3)
        tl.store(E + tile*3+2, 0.)


def pack(code, column_scale=None, row_scale=None):
    if not code.is_cuda or not code.is_contiguous() or code.ndim < 2 or code.shape[-1] % 8:
        raise ValueError('Expected contiguous CUDA tiles with width divisible by 8')
    rows, cols = code.shape[-2:]
    tiles = code.numel() // (rows*cols)
    meta = column_scale is not None
    if meta and (row_scale is None or column_scale.shape != (tiles, rows) or row_scale.shape != (tiles, cols)
                 or not column_scale.is_contiguous() or not row_scale.is_contiguous()
                 or column_scale.device != code.device or row_scale.device != code.device):
        raise ValueError('Expected contiguous matching CUDA scale arrays')
    packed = torch.empty((*code.shape[:-1], cols//2), device=code.device, dtype=torch.uint8)
    errors = torch.empty((tiles, 3), device=code.device, dtype=torch.float32) if meta else None
    block = triton.next_power_of_2(rows*cols if meta else rows*cols//4)
    _pack[(tiles,)](code, packed, column_scale, row_scale, errors,
                    rows, cols, meta, block, num_warps=8 if meta else 4, enable_fp_fusion=False)
    return (packed, errors) if meta else packed
