"""Global-plane writer/reader attribution and five-arm end-to-end experiment."""
import argparse,hashlib,json,os,statistics,sys,time,traceback
from pathlib import Path
from datetime import datetime
from types import SimpleNamespace
from kvbench_longcontext.common import atomic_json,checked_data,read_jsonl,write_jsonl,sha_file,describe
LABELS=('native','tile_full','split_full','tile_k2','split_k2')

def worker(root,label):
 import numpy as np
 import torch
 from .validate_reuse import Replay,load_module
 from .split_storage import write_tiles,read_tiles
 from .profile_components import measure
 from kvbench_residual.fixtures import Case,build_case
 from vllm.v1.attention.backends import kvarn_attn as backend
 from vllm.model_executor.layers.quantization.kvarn.config import KVarNConfig
 from .codec import unpack_numpy
 rt=root/'runtimes'/label;out=root/'components'/label;out.mkdir(parents=True)
 fixture=build_case(Case('split_gate',(385,511),hq=32,hk=8));replay=Replay(fixture,32)
 oldlabel='native' if label=='native' else 'tile_k2' if label.endswith('k2') else 'tile_full'
 old=load_module(root/'runtimes'/oldlabel,'split_reference_'+label)
 module=load_module(rt,'split_candidate_'+label)
 packed=replay.gpu.planar
 if label.startswith('split'):
  cache=torch.empty_like(packed);ids=torch.arange(packed.shape[0]*8,device='cuda',dtype=torch.int64)
  write_tiles(cache,ids,packed.view(-1,17920))
  torch.testing.assert_close(read_tiles(cache,ids),packed.view(-1,17920),rtol=0,atol=0)
 else:cache=packed
 checks=[]
 if label!='native':
  for mode in ('single','split'):
   replay.gpu.planar=packed;reference=replay.launch(old,mode).clone();replay.gpu.planar=cache
   torch.testing.assert_close(replay.launch(module,mode),reference,rtol=.002,atol=.002)
   graph=torch.cuda.CUDAGraph()
   with torch.cuda.graph(graph):replay.launch(module,mode)
   graph.replay();torch.cuda.synchronize();torch.testing.assert_close(replay.gpu.out,reference,rtol=.002,atol=.002)
   checks.append(mode+' eager/graph matches unchanged reconstruction')
 # Actual backend flush, same deterministic inputs in independent processes.
 cfg=KVarNConfig();heads=8;bids=[6,2];slots=[1,3];group=('split_probe',os.getpid())
 generator=torch.Generator(device='cuda').manual_seed(9107)
 pk=torch.randn((4,128,heads,128),device='cuda',generator=generator,dtype=torch.float16)
 # Make V independent of ambient RNG for cross-process byte comparison.
 pv=torch.randn((4,128,heads,128),device='cuda',generator=generator,dtype=torch.float16)
 store=torch.zeros((9,heads,17920),device='cuda',dtype=torch.uint8)
 impl=SimpleNamespace(kvarn_config=cfg,num_kv_heads=heads,_group_key=group,_tails={},_tail_K_pool=pk,_tail_V_pool=pv)
 backend.KVarNAttentionImpl._block_to_slot_dict[group]=dict(zip(bids,slots))
 def flush():
  impl._tails={bid:None for bid in bids};backend.KVarNAttentionImpl._batched_flush([(impl,bid,store) for bid in bids])
 os.environ['KVARN_FAST_FLUSH']='1'
 for _ in range(3):flush()
 torch.cuda.synchronize();timing=measure(flush,10,5)
 torch.cuda.synchronize();start=time.perf_counter()
 for _ in range(10):flush()
 torch.cuda.synchronize();wall=(time.perf_counter()-start)*1e6/10
 ids=(torch.tensor(bids,device='cuda')[:,None]*8+torch.arange(8,device='cuda')[None,:]).reshape(-1)
 saved=(read_tiles(store,ids).view(2,8,17920) if label.startswith('split') else store[bids]).cpu().numpy()
 if label!='native':
  for offset in (0,8960):
   codes=unpack_numpy(saved[:,:,offset:offset+8192].reshape(-1,128,64),128)
   saved[:,:,offset:offset+8192]=(codes[...,::2]|(codes[...,1::2]<<4)).reshape(2,heads,8192)
 np.save(out/'native_records.npy',saved)
 # Verify physical-page rewrites clear every low plane too.
 impl._tail_K_pool.zero_();impl._tail_V_pool.zero_();flush()
 zeros=(read_tiles(store,ids).view(2,8,17920) if label.startswith('split') else store[bids]).cpu().numpy()
 np.save(out/'zero_records.npy',zeros)
 atomic_json(out/'result.json',{'status':'completed','checks':checks+['actual backend flush, non-contiguous blocks','physical block rewrite including zero input'],'flush_cuda_event':timing,'flush_synchronized_wall_us':wall,'scope':'two pages x8 heads; isolated eager flush includes host launch gaps, not whole-model fraction'})

 # Real snapshots: identical inputs, matched geometry, counter-free CUDA graphs.
 from kvbench_residual_diag.common import load_trace,trace_paths
 traces=Path('results/progressive_online/autonomous_next_20261016_235221/capture/traces').resolve();rows=[]
 for path in trace_paths(traces,3):
  data,meta=load_trace(path);r=Replay(data,32);g=r.gpu;g.splits=32
  g.mid_o=torch.zeros((32,32,128),device='cuda');g.mid_lse=torch.full((32,32),-float('inf'),device='cuda')
  if label.startswith('split'):
   target=torch.empty_like(g.planar);ids2=torch.arange(g.planar.shape[0]*8,device='cuda',dtype=torch.int64);write_tiles(target,ids2,g.planar.view(-1,17920));g.planar=target
  for bn in (16,32,64):
   g.block_n=bn;g.num_warps=4;g.num_stages=1;r.launch(module,'split');torch.cuda.synchronize()
   graph=torch.cuda.CUDAGraph()
   with torch.cuda.graph(graph):r.launch(module,'split')
   rounds=[measure(graph.replay,30,5)['median_us'] for _ in range(3)]
   rows.append(dict(trace=path.name,dataset=meta['request']['dataset'],block_n=bn,median_us=statistics.median(rounds),round_medians_us=rounds))
   atomic_json(out/'reader.json',rows)


def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--worker',choices=LABELS);p.add_argument('--tokens',type=int,default=512);p.add_argument('--rounds',type=int,default=3);a=p.parse_args();root=a.out.resolve()
 if a.worker:worker(root,a.worker);return
 from . import runtime
 from .autonomous_next import fixed_online_source
 from .fused_runtime import install as fuse
 from .split_runtime import install as split
 from .run import DEFAULT_UPSTREAM,_gpu_idle,_start_server,_stop_server,_run_logged,_client_python
 from .online_reader_probe import freeze_probe,analyze_point
 from .decisive_probe import overlap
 root.mkdir(parents=True,exist_ok=False);state={'status':'running','phase':'preflight','pid':os.getpid(),'started':datetime.now().isoformat()};atomic_json(root/'status.json',state)
 try:
  _gpu_idle('0');cfg=json.loads(Path(DEFAULT_UPSTREAM).read_text())['settings'];freeze_probe(Path(cfg['data']),root/'data')
  manifest=json.loads((root/'data/manifest.json').read_text());manifest['settings']['max_new_tokens']=a.tokens
  for info in manifest['datasets'].values():
   rows=read_jsonl(root/'data'/info['file'])
   for r in rows:r.update(max_tokens=a.tokens,generation_budget_tokens=a.tokens)
   write_jsonl(root/'data'/info['file'],rows);info.update(sha256=sha_file(root/'data'/info['file']),max_tokens=a.tokens,generation_budget_tokens=describe([a.tokens]*len(rows)))
  atomic_json(root/'data/manifest.json',manifest);checked_data(root/'data')
  orders=[list(LABELS),['tile_k2','split_full','native','split_k2','tile_full'],['split_k2','tile_full','tile_k2','native','split_full']][:a.rounds]
  atomic_json(root/'plan.json',{'arms':LABELS,'orders':orders,'tokens':a.tokens,'tasks':['qasper','hotpotqa'],'requests_each':8,'concurrency':[1,8],'generation':'exact fixed length; greedy; ignore_eos=true; no task-quality claim','storage':'8 disjoint global regions within existing vLLM allocation, high K/V first; no shadow copy','controlled':'same codes, same precision within layout pairs, fused packer in all planar arms, default reader tuning; no adaptive metadata/controller','attribution':'tile vs split at same precision isolates layout+scatter; full vs low isolates read depth; backend flush and matched reader graph measured separately','limitations':['APC off; raw block relocation unsupported; any preemption invalidates point','No DRAM counters','C1 real TPOT; C8 common content interval only if chunks map one-to-one','Component times are not additive online percentages']})
  env=dict(os.environ,NO_PROXY='localhost,127.0.0.1,::1',no_proxy='localhost,127.0.0.1,::1',PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',KVARN_FAST_FLUSH='1')
  for k in ['PYTHONPATH','PYTHONHOME','KVBENCH_PROFILE_DIR']:env.pop(k,None)
  original=runtime.transform_dequant
  for label in LABELS:
   state.update(phase='build_'+label);atomic_json(root/'status.json',state);rt=root/'runtimes'/label;arm='parent' if label=='native' else 'p211_full'
   if label.endswith('k2'):runtime.transform_dequant=lambda s,arm,thresholds:fixed_online_source(original(s,'p211_adaptive',thresholds)).replace('    AR_RESIDUAL_PTR,\n','    AR_RESIDUAL_PTR=None,\n')
   try:runtime.build(rt,arm)
   finally:runtime.transform_dequant=original
   if label!='native':fuse(rt,arm)
   if label.startswith('split'):split(rt,arm)
   runtime.verify(rt,arm)
   state.update(phase='gate_'+label);atomic_json(root/'status.json',state)
   worker_env=dict(env,PYTHONPATH=str(rt)+os.pathsep+str(Path.cwd()))
   if _run_logged(sys.executable,['-m','kvbench_progressive_online.split_probe','--out',root,'--worker',label],root/'logs'/(label+'.components.log'),worker_env,Path.cwd()):raise RuntimeError('Component gate failed '+label)
  import numpy as np
  canonical=np.load(root/'components/native/native_records.npy')
  for label in LABELS:np.testing.assert_array_equal(canonical,np.load(root/'components'/label/'native_records.npy'))
  np.testing.assert_array_equal(np.load(root/'components/tile_full/zero_records.npy'),np.load(root/'components/split_full/zero_records.npy'))
  atomic_json(root/'byte_gate.json',{'status':'completed','checks':['all five actual backend records byte-equal after canonicalization','split physical rewrite exact','full and low GPU outputs match tile layout, eager and graph']})
  args=SimpleNamespace(model=Path(cfg['model']),max_model_len=cfg['max_model_len'],max_seqs=cfg['max_seqs'],batch_tokens=cfg['batch_tokens'],server_seed=cfg['server_seed'],port=18194,gpu='0',gpu_util=.85,startup_timeout=1800,eager=False,repo=Path(__file__).resolve().parents[1]);results=[]
  for rnd,order in enumerate(orders,1):
   for label in order:
    session=f'r{rnd}_{label}';state.update(phase=session);atomic_json(root/'status.json',state);proc=log=None
    try:
     arm='parent' if label=='native' else 'p211_full'
     proc,log,launch=_start_server(args,arm,root/'runtimes'/label,root/'servers'/session,root/'logs'/(session+'.server.log'),env)
     command=['-m','kvbench_progressive_online.decisive_probe','--client','--data-dir',root/'data','--out',root/'runs'/session,'--server-manifest',launch,'--concurrency','1','8','--repeats','1','--temperature','0','--top-p','1','--top-k','-1','--min-p','0','--seed',str(cfg['request_seed']),'--request-timeout','1800','--warmup','1','--warmup-per-point','8','--gpu','0','--sample-interval','1','--save-metrics-samples']
     if _run_logged(_client_python(cfg),command,root/'logs'/(session+'.client.log'),env,args.repo):raise RuntimeError('Client failure '+session)
     for path in sorted((root/'runs'/session).glob('r*/performance.summary.json')):
      r=analyze_point(path.parent)
      if not r['measurement_complete'] or r['valid_responses']!=8:raise ValueError('Incomplete online point')
      if r.get('preemptions_delta',0):raise ValueError('Raw page relocation unsupported: preemption invalidates split comparison')
      r['overlap']=overlap(path.parent,a.tokens) if r['concurrency']==8 else None
      results.append(dict(arm=label,round=rnd,**r));atomic_json(root/'measurements.json',results)
    finally:
     try:_stop_server(proc)
     finally:
      if log:log.close()
    summarize(root,results)
  state.update(status='completed',phase='finished',finished=datetime.now().isoformat());atomic_json(root/'status.json',state)
 except BaseException as e:
  state.update(status='failed',error=repr(e),traceback=traceback.format_exc());atomic_json(root/'status.json',state);raise

def summarize(root,results):
 rows=[]
 for dataset in ('qasper','hotpotqa'):
  for c in (1,8):
   for base,other in [('native','split_full'),('native','split_k2'),('tile_full','split_full'),('tile_k2','split_k2'),('split_full','split_k2')]:
    changes=[]
    for rnd in (1,2,3):
     b=next((r for r in results if r['arm']==base and r['round']==rnd and r['dataset']==dataset and r['concurrency']==c),None)
     o=next((r for r in results if r['arm']==other and r['round']==rnd and r['dataset']==dataset and r['concurrency']==c),None)
     if b and o:changes.append({'round':rnd,'tpot_change_pct':100*(o['tpot_s']['mean']/b['tpot_s']['mean']-1),'e2e_change_pct':100*(o['e2e_s']['mean']/b['e2e_s']['mean']-1),'throughput_change_pct':100*(o['output_tokens_per_s']/b['output_tokens_per_s']-1)})
    if changes:rows.append(dict(dataset=dataset,concurrency=c,baseline=base,candidate=other,rounds=changes,median_tpot_change_pct=statistics.median(x['tpot_change_pct'] for x in changes)))
 atomic_json(root/'comparison.json',{'comparisons':rows,'complete_points':len(results),'expected_points':60,'negative_change_means_faster':True})

if __name__=='__main__':main()
