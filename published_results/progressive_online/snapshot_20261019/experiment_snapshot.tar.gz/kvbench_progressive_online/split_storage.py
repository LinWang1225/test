"""Global high/low planes, disjoint views in vLLM's accounted allocation.

Eight regions replace per-tile interleaving; no duplicate KV side cache.
Only Qwen3-4B K4V4/G128/head_dim128 is supported initially.
"""
import torch
import triton
import triton.language as tl

# logical offset, bytes/tile; physical order favors both high planes first.
FIELDS=((0,4096),(8960,4096),(4096,2048),(13056,2048),
        (6144,2048),(15104,2048),(8192,768),(17152,768))
TILE=17920

@triton.jit
def _physical(x, tile, NT:tl.constexpr):
 out=tl.full(x.shape,0,tl.int64)
 # Explicit constants avoid Python tuple iteration in Triton.
 out=tl.where(x<4096,tile*4096+x,out)
 out=tl.where((x>=8960)&(x<13056),NT*4096+tile*4096+x-8960,out)
 out=tl.where((x>=4096)&(x<6144),NT*8192+tile*2048+x-4096,out)
 out=tl.where((x>=13056)&(x<15104),NT*10240+tile*2048+x-13056,out)
 out=tl.where((x>=6144)&(x<8192),NT*12288+tile*2048+x-6144,out)
 out=tl.where((x>=15104)&(x<17152),NT*14336+tile*2048+x-15104,out)
 out=tl.where((x>=8192)&(x<8960),NT*16384+tile*768+x-8192,out)
 out=tl.where(x>=17152,NT*17152+tile*768+x-17152,out)
 return out

@triton.jit
def _transfer(C,R,IDS,N:tl.constexpr,NT:tl.constexpr,WRITE:tl.constexpr,B:tl.constexpr,HEADS:tl.constexpr=1,BLOCK_IDS:tl.constexpr=False):
 row=tl.program_id(0);x=tl.program_id(1)*B+tl.arange(0,B)
 if BLOCK_IDS:
  tile=tl.load(IDS+row//HEADS).to(tl.int64)*HEADS+row%HEADS
 else:
  tile=tl.load(IDS+row).to(tl.int64)
 addr=_physical(x,tile,NT)
 if WRITE:
  v=tl.load(R+row*17920+x,x<17920,0);tl.store(C+addr,v,x<17920)
 else:
  v=tl.load(C+addr,x<17920,0);tl.store(R+row*17920+x,v,x<17920)

def views(cache):
 if cache.dtype!=torch.uint8 or cache.shape[-1]!=TILE or not cache.is_contiguous():raise ValueError('Expected contiguous accounted G128 cache')
 flat=cache.view(-1);n=cache.shape[0]*cache.shape[1];offset=0;out=[]
 for _,size in FIELDS:
  out.append(flat[offset:offset+n*size].view(n,size));offset+=n*size
 assert offset==flat.numel()
 return out

def write_tiles(cache,ids,records):
 ids=ids.contiguous();records=records.contiguous().view(-1,TILE)
 if records.shape[0]!=ids.numel():raise ValueError('Tile write mismatch')
 _transfer[(ids.numel(),triton.cdiv(TILE,512))](cache,records,ids,ids.numel(),cache.shape[0]*cache.shape[1],True,512)

def read_tiles(cache,ids):
 ids=ids.contiguous();out=torch.empty((ids.numel(),TILE),dtype=torch.uint8,device=cache.device)
 _transfer[(ids.numel(),triton.cdiv(TILE,512))](cache,out,ids,ids.numel(),cache.shape[0]*cache.shape[1],False,512)
 return out

def write_records(cache,bids,records):
 h=cache.shape[1];records=records.contiguous().view(-1,TILE)
 if records.shape[0]!=bids.numel()*h:raise ValueError('Block record mismatch')
 _transfer[(records.shape[0],triton.cdiv(TILE,512))](cache,records,bids,records.shape[0],cache.shape[0]*h,True,512,h,True)

def read_one(cache,bid,head):
 return read_tiles(cache,torch.tensor([bid*cache.shape[1]+head],device=cache.device,dtype=torch.int64))[0]

class SplitLaunch:
 """Inject only the compile-time allocation extent, no GPU synchronization."""
 def __init__(self,inner):self.inner=inner
 def __getattr__(self,name):
  value=getattr(self.inner,name)
  return SplitLaunch(value) if name=='fn' else value
 def __getitem__(self,grid):
  launch=self.inner[grid]
  def call(*args,**kwargs):
   # Decode, verify and materializer all name their cache argument in JIT arg_names.
   names=getattr(self.inner,'arg_names',None)
   if names is None:names=self.inner.fn.arg_names
   ix=names.index('KV_cache_ptr');cache=args[ix] if len(args)>ix else kwargs['KV_cache_ptr']
   kwargs['SOA_TILES']=cache.shape[0]*cache.shape[1]
   return launch(*args,**kwargs)
  return call

def install_kernels(namespace):
 for name,value in list(namespace.items()):
  if name.startswith('_kvarn_'):
   names=getattr(value,'arg_names',None)
   if names is None and hasattr(value,'fn'):names=getattr(value.fn,'arg_names',None)
   if names and 'KV_cache_ptr' in names:namespace[name]=SplitLaunch(value)
