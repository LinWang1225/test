"""Bounded real-trace operator ablation; separate counting and graph timing."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import traceback

import numpy as np
import torch
import torch.nn.functional as F

from kvbench_longcontext.common import atomic_json
from kvbench_residual.fixtures import Case, build_case, unpack_block
from kvbench_residual_diag.common import load_trace, trace_paths, write_csv
from .ablation import VARIANTS, generate
from .profile_components import measure
from .residual_metadata import torch_residual_bounds_from_quantized
from .runtime import build, verify
from .transform import DECODE
from .validate_reuse import Replay, load_module


def load_file(path,name):
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec);sys.modules[name]=module
    spec.loader.exec_module(module)
    module._progressive_test_adaptive=True
    return module


def prepare(data,block_n):
    replay=Replay(data,block_n)
    g=replay.gpu;cfg=data['case'].layout;o=cfg.offsets
    raw=g.planar[:,:,o['K_PACKED_OFFSET']:o['K_S_COL_OFFSET']].reshape(-1,128,64).contiguous()
    def scale(offset):return g.t['cache'][:,:,offset:offset+256].contiguous().view(torch.float16).reshape(-1,128)
    metadata=torch_residual_bounds_from_quantized(raw,scale(o['K_S_COL_OFFSET']),scale(o['K_S_ROW_OFFSET']),packing='planes_211').reshape(-1,8,3)
    metadata[g.t['block_to_slot']>=0]=0
    torch.testing.assert_close(metadata,replay.metadata,rtol=2e-6,atol=1e-7)
    replay.metadata=metadata
    # Common capacities avoid recompiling every source for different trace lengths.
    cap=256;pages=g.t['cache'].shape[0]
    if pages>cap or g.t['block_table'].shape[1]>cap:raise ValueError('Trace exceeds fixed 32K diagnostic capacity')
    g.t['cache']=F.pad(g.t['cache'],(0,0,0,0,0,cap-pages))
    g.planar=F.pad(g.planar,(0,0,0,0,0,cap-pages))
    g.t['block_to_slot']=F.pad(g.t['block_to_slot'],(0,cap-pages),value=-1)
    g.t['block_table']=F.pad(g.t['block_table'],(0,cap-g.t['block_table'].shape[1]),value=-1)
    replay.metadata=F.pad(replay.metadata,(0,0,0,0,0,cap-pages))
    replay.state=F.pad(replay.state,(0,0,0,0,0,0,0,cap-pages))
    return replay


def expected_counts(data,block_n):
    tokens=chunks=0;length=int(data['seq_lens'][0]);heads=data['case'].hk
    for logical in range((length+127)//128):
        bid=int(data['block_table'][0,logical])
        if data['block_to_slot'][bid]>=0:continue
        n=min(128,length-logical*128)
        tokens+=n*heads;chunks+=((n+block_n-1)//block_n)*heads
    return chunks,tokens


def fixed_oracle(data,key_bits,value_bits):
    """Independent float64 full-context attention, on a small fixture only."""
    results=[];length=int(data['seq_lens'][0]);ratio=4
    def prefix(code,bits):
        width=1<<(4-bits)
        return (code//width)*width+(width-1)/2
    for head in range(8):
        keys=[];values=[]
        for logical in range((length+127)//128):
            bid=int(data['block_table'][0,logical]);slot=int(data['block_to_slot'][bid]);n=min(128,length-logical*128)
            if slot>=0:
                keys.append(data['pool_k'][slot,:n,head].astype(np.float64).T)
                values.append(data['pool_v'][slot,:n,head].astype(np.float64))
            else:
                x=unpack_block(data,bid,head)
                keys.append((prefix(x['kq'][:,:n],key_bits)*x['sk'][:,None]+x['zk'][:,None])*x['rk'][None,:n])
                values.append((prefix(x['vq'][:n],value_bits)*x['rv'][:n,None]+x['zv'][:n,None])*x['sv'][None,:])
        q=data['query'][0,head*ratio:(head+1)*ratio].astype(np.float64)
        scores=q@np.concatenate(keys,axis=1)*data['scale'];weights=np.exp(scores-scores.max(axis=1,keepdims=True))
        results.append((weights@np.concatenate(values,axis=0))/weights.sum(axis=1,keepdims=True))
    return np.concatenate(results)[None]


def count_once(replay,module,mode):
    counters=torch.zeros(14,dtype=torch.int64,device='cuda')
    replay.launch(module,mode,extra={'PG_DIAG_PTR':counters,'PG_DIAG_ENABLED':True})
    torch.cuda.synchronize()
    instrumented=replay.gpu.out.clone()
    raw=counters.cpu().tolist()
    replay.launch(module,mode,extra={'PG_DIAG_PTR':counters,'PG_DIAG_ENABLED':False})
    torch.cuda.synchronize()
    torch.testing.assert_close(replay.gpu.out,instrumented,rtol=2e-3,atol=2e-3)
    chunks,tokens=expected_counts(replay.gpu.data,replay.gpu.block_n)
    assert sum(raw[:3])==chunks and sum(raw[3:6])==chunks,'Chunk counter mismatch'
    assert sum(raw[6:9])==tokens and sum(raw[9:12])==tokens,'Token counter mismatch'
    return dict(key_chunks=dict(zip(('2','3','4'),raw[:3])),value_chunks=dict(zip(('2','3','4'),raw[3:6])),
                key_tokens=dict(zip(('2','3','4'),raw[6:9])),value_tokens=dict(zip(('2','3','4'),raw[9:12])),
                logical_key_code_bytes=raw[12],logical_value_code_bytes=raw[13],
                native_code_bytes=tokens*128,
                logical_code_reduction_fraction=1-(raw[12]+raw[13])/(tokens*128) if tokens else 0,
                instrumented_output_max_diff=float((replay.gpu.out-instrumented).abs().max()))


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--metadata-gate',type=Path,required=True)
    p.add_argument('--traces',type=Path,required=True)
    p.add_argument('--trace-limit',type=int,default=3)
    a=p.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    atomic_json(out/'status.json',{'status':'running','phase':'building'})
    try:
        gate=json.loads((a.metadata_gate/'status.json').read_text())
        if gate['status']!='completed':raise ValueError('Actual writer/metadata prerequisite did not pass')
        for name in ('residual_metadata.py','kernel.py','transform.py'):
            current=(Path(__file__).parent/name).read_bytes()
            validated=(a.metadata_gate/'runtime/kvbench_progressive_online'/name).read_bytes()
            if current!=validated:raise ValueError('Metadata gate source drift: '+name)
        from .run import _gpu_idle
        _gpu_idle('0')
        runtime=out/'runtime_adaptive';build(runtime,'p211_adaptive');verify(runtime,'p211_adaptive')
        full_root=out/'runtime_full';build(full_root,'p211_full');verify(full_root,'p211_full')
        full=load_module(full_root,'ablation_verified_full')
        source=(runtime/'vllm'/DECODE).read_text()
        generated=out/'variants';generated.mkdir()
        modules={};receipts={}
        for name,setting in VARIANTS.items():
            text=generate(source,name);path=generated/(name+'.py');path.write_text(text)
            receipts[name]={'key':setting[0],'value':setting[1],'sha256':hashlib.sha256(text.encode()).hexdigest()}
            modules[name]=load_file(path,'ablation_'+name)
        atomic_json(out/'variants.json',receipts)
        atomic_json(out/'status.json',{'status':'running','phase':'synthetic_correctness'})
        fixture=build_case(Case('ablation_contract',(385,),hq=32,hk=8))
        test=prepare(fixture,16);checks=[]
        for name,(kb,vb) in VARIANTS.items():
            print('GATE '+name,flush=True)
            if isinstance(kb,int) and isinstance(vb,int):
                oracle=fixed_oracle(fixture,kb,vb)
            for mode in ('single','split'):
                counts=count_once(test,modules[name],mode)
                if isinstance(kb,int) and isinstance(vb,int):
                    actual=test.gpu.out.cpu().numpy().reshape(1,32,128)
                    np.testing.assert_allclose(actual,oracle,rtol=.02,atol=.002)
                    assert counts['key_chunks'][str(kb)]==sum(counts['key_chunks'].values())
                    assert counts['value_chunks'][str(vb)]==sum(counts['value_chunks'].values())
                if name=='fixed_k4v4' or name.startswith('control_') or name=='k4_control_v4':
                    reference=test.launch(full,mode).clone()
                    candidate=test.launch(modules[name],mode).clone()
                    torch.testing.assert_close(candidate,reference,rtol=.002,atol=.002)
                checks.append(dict(variant=name,mode=mode,counts=counts))
        atomic_json(out/'correctness.json',checks)
        atomic_json(out/'status.json',{'status':'running','phase':'real_trace_measurement'})
        rows=[];count_rows=[]
        for path in trace_paths(a.traces,a.trace_limit):
            data,meta=load_trace(path)
            if meta['window']!=0:raise ValueError('Windowed traces require a separate byte-count oracle')
            replay=prepare(data,16)
            counts_buffer=torch.zeros(14,dtype=torch.int64,device='cuda')
            for mode in ('single','split'):
                replay.launch(modules['fixed_k4v4'],mode)
                reference=replay.gpu.out.clone()
                for name,module in modules.items():
                    print('MEASURE '+meta['request']['dataset']+' '+mode+' '+name,flush=True)
                    counted=count_once(replay,module,mode)
                    output=replay.gpu.out.clone()
                    count_rows.append(dict(trace=path.name,dataset=meta['request']['dataset'],mode=mode,variant=name,**counted))
                    # Compile/warm outside graph; timed graph contains no counters.
                    def launch():return replay.launch(module,mode,extra={'PG_DIAG_PTR':counts_buffer,'PG_DIAG_ENABLED':False})
                    for _ in range(3):launch()
                    torch.cuda.synchronize();graph=torch.cuda.CUDAGraph()
                    with torch.cuda.graph(graph):launch()
                    timing=measure(graph.replay,repetitions=30,samples=7)
                    diff=(output-reference).float()
                    rows.append(dict(trace=path.name,dataset=meta['request']['dataset'],context=meta['context_tokens'],
                        mode=mode,variant=name,block_n=16,num_warps=4,splits=1 if mode=='single' else 4,
                        output_relative_l2=float(torch.linalg.vector_norm(diff)/torch.linalg.vector_norm(reference.float()).clamp_min(1e-12)),
                        output_max_abs=float(diff.abs().max()),**timing))
                    atomic_json(out/'timings.json',rows);atomic_json(out/'depth_counts.json',count_rows)
            # Kernel register/shared-memory metadata and time are separately profiled.
            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as prof:
                for name,module in modules.items():
                    with torch.profiler.record_function(name):replay.launch(module,'split')
                torch.cuda.synchronize()
            prof.export_chrome_trace(str(out/(path.stem+'.torch_trace.json')))
        write_csv(out/'timings.csv',rows)
        flat=[]
        for r in count_rows:
            flat.append({k:v for k,v in r.items() if not isinstance(v,dict)}|{
                side+'_bits'+bits:value for side in ('key_chunks','value_chunks','key_tokens','value_tokens') for bits,value in r[side].items()})
        write_csv(out/'depth_counts.csv',flat)
        atomic_json(out/'status.json',{'status':'completed','trace_count':a.trace_limit,'variants':len(VARIANTS),
            'gpu':torch.cuda.get_device_name(),'metadata_gate':str(a.metadata_gate.resolve()),
            'timing':'CUDA graph replay, counters constexpr-disabled; fixed geometry and capacity',
            'counting':'Separate instrumented launch, logical code addresses only; excludes scales, pools and DRAM transactions',
            'dram_bytes':None,'dram_status':'Previously probed ncu ERR_NVGPUCTRPERM; not re-probed',
            'scope':'Small C1 saved-input operator ablation; no online task quality or C8 speed claim'})
    except BaseException as exc:
        atomic_json(out/'status.json',{'status':'failed','error':repr(exc),'traceback':traceback.format_exc()});raise


if __name__=='__main__':main()
