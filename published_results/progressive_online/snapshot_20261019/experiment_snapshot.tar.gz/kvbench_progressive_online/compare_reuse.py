"""Dataset-matched descriptive online sweep report; no statistical quality claim."""
from __future__ import annotations
import argparse
import csv
import json
from pathlib import Path
from kvbench_longcontext.common import atomic_json, read_jsonl


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--batch',type=Path,required=True)
    a=p.parse_args()
    batch=a.batch.resolve()
    def read(path): return json.loads(path.read_text())
    base_plan=read(batch/'baseline/plan.json')
    base_rows=read(batch/'baseline/comparison.json')
    baseline={r['dataset']:r for r in base_rows if r['arm']=='p211_adaptive'}
    rows=[]; paired=[]
    for stride in (1,2,4,8,16):
        directory=batch/('baseline' if stride==1 else f'stride{stride}')
        if read(directory/'status.json')['status']!='completed':
            raise RuntimeError(f'Incomplete stride {stride}')
        plan=read(directory/'plan.json')
        for key in ('case_ids','source_suite_sha256','source_data_sha256','model_config_sha256',
                    'generation','concurrency','risk_thresholds','key_bound_version'):
            if plan[key]!=base_plan[key]: raise ValueError(f'Protocol mismatch: {key}')
        for r in read(directory/'comparison.json'):
            if r['arm']!='p211_adaptive': continue
            b=baseline[r['dataset']]
            rows.append(dict(stride=stride,dataset=r['dataset'],score=r['task_score_0_100'],
                score_delta_pp=r['task_score_0_100']-b['task_score_0_100'],
                tpot_ms=r['tpot_ms_mean'],tpot_change_pct=100*(r['tpot_ms_mean']/b['tpot_ms_mean']-1),
                output_tokens_per_s=r['output_tokens_per_s'],output_length_mean=r['output_length_mean'],
                ttft_ms=r['ttft_ms_mean'],length_capped=r['length_capped'],capacity=r['native_kv_capacity_tokens']))
            task=r['dataset']; point=f'runs/p211_adaptive/r01_{task}_C{plan["concurrency"]}/scores.jsonl'
            source={s['case_id']:s for s in read_jsonl(batch/'baseline'/point)}
            current={s['case_id']:s for s in read_jsonl(directory/point)}
            if set(source)!=set(current): raise ValueError('Paired score cohort mismatch')
            for case_id,s in source.items():
                c=current[case_id]
                if not s['scored'] or not c['scored']: raise ValueError('Unscored case')
                paired.append(dict(stride=stride,dataset=task,case_id=case_id,
                                   baseline_score=s['score'],candidate_score=c['score'],delta=c['score']-s['score']))
    screening=[]
    for stride in (1,2,4,8,16):
        selected=[r for r in rows if r['stride']==stride]
        macro=sum(r['score_delta_pp'] for r in selected)/len(selected)
        worst=min(r['score_delta_pp'] for r in selected)
        screening.append(dict(stride=stride,macro_score_delta_pp=macro,worst_task_delta_pp=worst,
                              exploratory_quality_screen=(macro>=-1 and worst>=-2)))
    atomic_json(batch/'reuse_comparison.json',{'rows':rows,'screening':screening,
        'limitations':'One sampled cohort, descriptive only; screen predeclared macro drop <=1pp and any task <=2pp. No confidence claim or automatic stride recommendation. TPOT includes scheduling/output-length/capacity effects. Live precision/reuse counters not collected.'})
    for name,values in [('reuse_comparison.csv',rows),('paired_reuse_quality.csv',paired)]:
        with (batch/name).open('x',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=list(values[0]));w.writeheader();w.writerows(values)


if __name__=='__main__':main()
