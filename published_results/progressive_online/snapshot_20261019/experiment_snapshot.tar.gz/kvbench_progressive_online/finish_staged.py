"""Background continuation and durable readout for a staged experiment batch."""
import argparse
from datetime import datetime
import json
from pathlib import Path
import statistics
import subprocess
import sys
import time

from kvbench_longcontext.common import atomic_json


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--root',type=Path,required=True)
    p.add_argument('--traces',type=Path,required=True)
    a=p.parse_args();root=a.root.resolve()
    path=root/'continuation.status.json'
    if path.exists():raise ValueError('Continuation already exists')
    atomic_json(path,{'status':'running','phase':'waiting_online'})
    deadline=time.monotonic()+3600
    while True:
        state=json.loads((root/'online/status.json').read_text())
        if state['status']=='completed':break
        if state['status']=='failed':
            atomic_json(path,{'status':'failed','phase':'online','reason':state.get('error')});return
        if time.monotonic()>deadline:
            atomic_json(path,{'status':'failed','reason':'Online experiment did not finish within one hour; no process killed'});return
        time.sleep(10)
    atomic_json(path,{'status':'running','phase':'query_budget_probe'})
    with (root/'budget.nohup.log').open('x') as log:
        result=subprocess.run([sys.executable,'-u','-m','kvbench_progressive_online.budget_probe',
            '--operator-run',str(root),'--traces',str(a.traces),'--out',str(root/'budget')],
            stdout=log,stderr=subprocess.STDOUT)
    if result.returncode:
        atomic_json(path,{'status':'failed','phase':'query_budget_probe','returncode':result.returncode});return
    writer=json.loads((root/'writer_timings.json').read_text())
    reader=json.loads((root/'reader_comparison.json').read_text())
    online=json.loads((root/'online/comparison.json').read_text())
    budget=json.loads((root/'budget/timings.json').read_text()) if (root/'budget/timings.json').exists() else []
    summary={'finished':datetime.now().isoformat(),'writer':[],'reader':reader,'online':[], 'budget':budget,
        'limits':['No physical DRAM measurement; GPU counter permission unavailable',
                  'Online full K4V4 writer comparison differs only in packing, not decoder configuration',
                  'Low-bit and query-budget measurements are operators, not validated online quality',
                  'B8 operator snapshots replicate one context; online requests are heterogeneous',
                  'Profiler data is separate from timing measurements']}
    for tiles in (1,8,64,256):
        selected={r['operation']:r for r in writer if r['tiles']==tiles and r['dtype']=='torch.int32'}
        summary['writer'].append({'tiles':tiles,
            'pack_graph_speedup':selected['torch_pack']['graph']['median_us']/selected['fused_pack']['graph']['median_us'],
            'pack_metadata_graph_speedup':selected['torch_pack_metadata']['graph']['median_us']/selected['fused_pack_metadata']['graph']['median_us']})
    for dataset in ('qasper','hotpotqa'):
        record={'dataset':dataset,'arms':{}}
        for arm in ('planar_original','planar_fused_writer'):
            selected=[r for r in online if r['dataset']==dataset and r['arm']==arm]
            record['arms'][arm]={'tpot_ms_by_repeat':[r['tpot_s']['mean']*1000 for r in selected],
                'ttft_s_by_repeat':[r['ttft_s']['mean'] for r in selected],
                'prefill_s_by_repeat':[r['server_histogram_deltas']['request_prefill_time_seconds']['mean_s'] for r in selected],
                'queue_s_by_repeat':[r['server_histogram_deltas']['request_queue_time_seconds']['mean_s'] for r in selected],
                'throughput_by_repeat':[r['output_tokens_per_s'] for r in selected]}
        summary['online'].append(record)
    atomic_json(root/'final_analysis.json',summary)
    lines=['实验各阶段已完成。所有数据保存在本目录，未覆盖旧结果。','',
        '完整 K4V4 在线对照只改变 writer；低精度及动态预算仍是算子诊断，不构成任务精度结论。','']
    for record in summary['online']:
        lines.append(record['dataset'])
        for arm,metrics in record['arms'].items():
            lines.append(f"- {arm}: TPOT 各轮 ms {metrics['tpot_ms_by_repeat']}; prefill 各轮 s {metrics['prefill_s_by_repeat']}")
    lines+=['','融合写入保留了 Sinkhorn、量化、记录拼接、scatter 等开销，只融合打包/元数据。',
            'DRAM 字节未实测；逐阶段 trace 中包含校验工作，实际 backend 写入范围标记为 actual_fast_flush。',
            '查看 final_analysis.json、online/comparison.json、budget/timings.json 获取完整结果。']
    (root/'readout.txt').write_text('\n'.join(lines)+'\n')
    atomic_json(path,{'status':'completed','finished':summary['finished'],'report':'final_analysis.json'})


if __name__=='__main__':main()
