"""Recover fixed-depth quality with verified dispatch and audit existing timelines."""
import argparse,collections,gzip,json,os,subprocess,sys,traceback
from pathlib import Path
from datetime import datetime
from kvbench_longcontext.common import atomic_json
PREVIOUS=Path('results/progressive_online/autonomous_next_20261016_235221').resolve()

def audit(out):
 import ijson
 rows=[]
 for p in sorted((PREVIOUS/'attribution/profiles').glob('*/rank*.gz')):
  kernels=collections.defaultdict(lambda:[0,0.]);cpu=collections.defaultdict(lambda:[0,0.]);events=0;start=None;end=None
  with gzip.open(p,'rb') as f:
   for e in ijson.items(f,'traceEvents.item'):
    events+=1
    if e.get('ph')!='X':continue
    t=float(e.get('ts',0));dur=float(e.get('dur',0));start=t if start is None else min(t,start);end=max(end or 0,t+dur)
    cat=str(e.get('cat',''));dest=kernels if cat=='kernel' else cpu if cat in ('cpu_op','cuda_runtime') else None
    if dest is not None:
     r=dest[str(e.get('name',''))];r[0]+=1;r[1]+=dur
  def top(d):return [{'name':n,'calls':v[0],'summed_us':v[1]} for n,v in sorted(d.items(),key=lambda x:-x[1][1])[:30]]
  rows.append({'arm':p.parent.name,'file':str(p),'gzip_and_json_valid':True,'events':events,'timeline_span_s':(end-start)/1e6 if end is not None else None,'gpu_kernel_count':sum(v[0] for v in kernels.values()),'gpu_summed_duration_s':sum(v[1] for v in kernels.values())/1e6,'attention_kernels':[dict(name=n,calls=v[0],summed_us=v[1]) for n,v in kernels.items() if 'kvarn_fused_decode' in n],'top_gpu':top(kernels),'top_cpu_inclusive':top(cpu)})
  atomic_json(out/'profile_audit.json',{'traces':rows,'limits':['stop_profile HTTP timed out; readable export does not prove complete capture','Profile requests are separate from formal performance timing','CPU ranges can nest; summed durations are not wall time','GPU sums are recorded activity durations, not DRAM measurements']})

def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
 state={'status':'running','phase':'quality_fixed','pid':os.getpid(),'started':datetime.now().isoformat(),'previous':str(PREVIOUS)};atomic_json(out/'status.json',state)
 atomic_json(out/'plan.json',{'arms':{'parent':'fresh native baseline','p211_adaptive':'fixed K2V2 with fused writer; production provenance footer restored'},'protocol':'six datasets x20, same frozen requests and original full generation budget','prior_full_control':str(PREVIOUS/'quality_fixed'),'no_overwrite':True,'dispatch_validation':'required source SHA and observed fused launch; no bypass'})
 env=dict(os.environ,NO_PROXY='localhost,127.0.0.1,::1',no_proxy='localhost,127.0.0.1,::1',PYTHONUNBUFFERED='1',PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
 with (out/'quality.log').open('x') as log:
  result=subprocess.run([sys.executable,'-u','-m','kvbench_progressive_online.autonomous_next','--worker','quality_fixed','--out',str(out/'quality')],env=env,stdout=log,stderr=subprocess.STDOUT)
 state.update(phase='profile_audit',quality_returncode=result.returncode);atomic_json(out/'status.json',state)
 try:audit(out);state['profile_audit']='completed'
 except Exception as e:state.update(profile_audit='failed',profile_error=repr(e));(out/'profile_error.log').write_text(traceback.format_exc())
 state.update(status='completed' if result.returncode==0 and state['profile_audit']=='completed' else 'completed_with_failures',phase='finished',finished=datetime.now().isoformat());atomic_json(out/'status.json',state)

if __name__=='__main__':main()
