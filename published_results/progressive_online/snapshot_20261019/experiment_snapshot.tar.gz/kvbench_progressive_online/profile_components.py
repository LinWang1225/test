"""Small matched-Q/KV CUDA diagnosis. No model server or task rerun.

CUDA events are collected without ncu. Hardware bytes are a separate run and
must remain unavailable when performance-counter access is denied.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import statistics
import torch

from kvbench_longcontext.common import atomic_json
from kvbench_residual_diag.common import load_trace,trace_paths
from .codec import pack_211_torch
from .residual_metadata import torch_residual_bounds_from_quantized
from .runtime import build,verify
from .validate_reuse import Replay,load_module


def measure(fn, repetitions=30, samples=7):
    for _ in range(3):fn()
    torch.cuda.synchronize()
    values=[]
    for _ in range(samples):
        start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
        start.record()
        for _ in range(repetitions):fn()
        end.record();end.synchronize()
        values.append(start.elapsed_time(end)*1000/repetitions)
    return dict(median_us=statistics.median(values),min_us=min(values),max_us=max(values),samples_us=values)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--traces',type=Path,required=True)
    p.add_argument('--gate',type=Path,required=True)
    p.add_argument('--trace-limit',type=int,default=3)
    p.add_argument('--ncu-case',choices=['parent','layout_full','control_full','adaptive_s1','adaptive_s4','metadata'],
                   help='Warm up, then expose only one selected workload to cudaProfilerStart/Stop')
    a=p.parse_args(); out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    atomic_json(out/'status.json',{'status':'running'})
    try:
        full_path=out/'runtime_full';build(full_path,'p211_full')
        paths={'parent':a.gate/'runtime_parent','layout_full':full_path,
               'control_full':a.gate/'runtime_control','adaptive_s1':a.gate/'runtime_s1',
               'adaptive_s4':a.gate/'runtime_s4'}
        modules={}
        for name,path in paths.items():
            arm='parent' if name=='parent' else 'p211_full' if name=='layout_full' else 'p211_adaptive'
            verify(path,arm)
            modules[name]=load_module(path,'component_'+name)
            if arm=='p211_adaptive':modules[name]._progressive_test_adaptive=True
        rows=[]
        for trace in trace_paths(a.traces,a.trace_limit):
            data,meta=load_trace(trace); replay=Replay(data,meta['block_n'])
            if a.ncu_case and a.ncu_case != 'metadata':
                module=modules[a.ncu_case]
                fn=lambda:replay.launch(module,'split',reuse=a.ncu_case=='adaptive_s4')
                for _ in range(3):fn()
                torch.cuda.synchronize()
                torch.cuda.cudart().cudaProfilerStart()
                fn()
                torch.cuda.synchronize()
                torch.cuda.cudart().cudaProfilerStop()
                atomic_json(out/'status.json',{'status':'completed','scope':'ncu single warmed split workload',
                                              'case':a.ncu_case,'trace':trace.name})
                return
            for mode in (() if a.ncu_case == 'metadata' else ('single','split')):
                # Match launch geometry and exact Q/KV bytes across all variants.
                # Reuse state is intentionally cold at the fixed sequence length;
                # do not advertise these repeated queries as cross-step hits.
                for name,module in modules.items():
                    replay.state.zero_()
                    fn=lambda m=module,n=name:replay.launch(m,mode,reuse=(n=='adaptive_s4'))
                    fn();torch.cuda.synchronize()
                    assert torch.isfinite(replay.gpu.out).all()
                    row=dict(trace=trace.name,dataset=meta['request']['dataset'],context=meta['context_tokens'],
                             mode=mode,block_n=meta['block_n'],splits=1 if mode=='single' else replay.gpu.splits,
                             component=name,**measure(fn))
                    rows.append(row);atomic_json(out/'timings.json',rows)
            g=replay.gpu;cfg=data['case'].layout; offsets=cfg.offsets
            native=g.t['cache'][g.t['block_to_slot']<0]
            def field(offset,count):return native[:,:,offset:offset+2*count].contiguous().view(torch.float16).reshape(-1,count)
            packed=native[:,:,offsets['K_PACKED_OFFSET']:offsets['K_S_COL_OFFSET']].reshape(-1,128,64).contiguous()
            planar=g.planar[g.t['block_to_slot']<0]
            packed_211=planar[:,:,offsets['K_PACKED_OFFSET']:offsets['K_S_COL_OFFSET']].reshape(-1,128,64).contiguous()
            col=field(offsets['K_S_COL_OFFSET'],128);row_scale=field(offsets['K_S_ROW_OFFSET'],128)
            codes=torch.stack((packed&15,packed>>4),dim=-1).reshape(-1,128,128)
            operations={
                'K_native_INT4_pack_only':lambda:(codes[...,::2] | (codes[...,1::2]<<4)),
                'K_211_pack_only':lambda:pack_211_torch(codes),
                'K_residual_metadata_compute_only':lambda:torch_residual_bounds_from_quantized(
                    packed_211,col,row_scale,packing='planes_211'),
            }
            if a.ncu_case == 'metadata':
                fn=operations['K_residual_metadata_compute_only']
                for _ in range(3):fn()
                torch.cuda.synchronize()
                torch.cuda.cudart().cudaProfilerStart()
                fn()
                torch.cuda.synchronize()
                torch.cuda.cudart().cudaProfilerStop()
                atomic_json(out/'status.json',{'status':'completed','scope':'ncu isolated metadata compute',
                                              'trace':trace.name})
                return
            for name,fn in operations.items():
                rows.append(dict(trace=trace.name,dataset=meta['request']['dataset'],context=meta['context_tokens'],
                                 component=name,quantized_tiles=int(packed.shape[0]),**measure(fn,repetitions=10)))
            # Timeline separates CPU launch/operator activity from CUDA kernels.
            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                                   torch.profiler.ProfilerActivity.CUDA]) as profiler:
                for name,fn in operations.items():
                    with torch.profiler.record_function(name):fn()
                for name,module in modules.items():
                    with torch.profiler.record_function(name):replay.launch(module,reuse=name=='adaptive_s4')
                torch.cuda.synchronize()
            profiler.export_chrome_trace(str(out/(trace.stem+'.torch_trace.json')))
        atomic_json(out/'timings.json',rows)
        atomic_json(out/'status.json',{'status':'completed','gpu':torch.cuda.get_device_name(),
            'scope':'Matched real trace GPU replay and isolated packing/metadata compute; not online TPOT',
            'dram_bytes':None,'dram_status':'separate ncu probe denied GPU counter permission',
            'limitations':['Fused control cost is a matched ablation, not additive instruction timing',
                           'Fixed-sequence reuse measurement exercises refresh; not a hit-rate or temporal-reuse benefit',
                           'CUDA event intervals can include launch gaps; timeline retained for attribution',
                           'Packing helpers omit quantizer/scatter/flush orchestration']})
    except BaseException as exc:
        atomic_json(out/'status.json',{'status':'failed','error':repr(exc)});raise


if __name__=='__main__':main()
