# Progressive-KV Online v1：LongBench 每数据集 × 20 条，真实 vLLM + GPU Attention

## 2026-10-16：修正误差单位与 K 跨步复用实验

### 读取配置在线性能诊断

`reader_tuning.py` 比较 BLOCK_N=16/32/64、warps=2/4、stages=1/2，分别为
single/split 选择配置。`online_reader_probe.py --batch <已有 tuning/selection.json 的新批次>`
依次运行默认位平面、调优位平面、同等调优原生三个独立服务。全部保持 K4V4 全读，
只改变布局及 kernel 配置。每组复用 Qasper/HotpotQA 各 8 个冻结 prompt，
C1/C8 各重复 2 次，greedy、thinking=true、最多生成 128 tokens。
这是明确限长的性能诊断，不与旧版无输出上限的 TPOT 直接混比，不据此报告 LongBench 质量。

每个在线点保留 `requests.jsonl`、SSE 压缩原始时间戳、`telemetry.jsonl`、
`metrics.before/after.txt` 和逐秒 `metrics.samples.jsonl.gz` 原始 Prometheus。
`online.analysis.json` 另给出排队/prefill/decode 的服务端 histogram 差值、
GPU 温度/频率/功率/利用率/显存统计，以及采样时段内估计能耗。
histogram 数量与请求数不一致时显式标记，SSE chunk 间隔不冒充逐 token 延迟。
`utilization.memory` 是活动率，不是 DRAM 字节。硬件字节计数仍需 Nsight counter 权限。
`online_status.json` 和 `online_exit_code.txt` 分别记录阶段状态和后台退出码。

writer→metadata 合约 v2 另外修复了打包格式：转换后的 writer 输出
`planes_211`，不能当成原生 INT4 nibble 对读取。
`torch_residual_bounds_from_quantized(..., packing=...)` 现在必须显式声明
`planes_211` 或 `native_int4`；backend fast flush 固定传入前者。
旧自适应结果保留，但不能作为修正后精度控制的正确性证据。

完整链路正确性检查使用实际私有 backend 的 Sinkhorn、量化、flush、metadata
写入和 GPU 精度选择，并与原生 writer 的独立 float64 误差计算对照：

```bash
python -m kvbench_progressive_online.validate_metadata --out /新的目录/metadata_contract
```

该检查覆盖物理 block 重写/清零、复用状态清空、2/3/4-bit 选择及 CUDA Graph。
它不启动模型服务，不重跑 parent 的在线任务，也不证明模型质量、性能或 DRAM 收益。

新实验将 writer 的最大 K 重建误差乘以当前 GQA query 的最大 L1 范数和
`abs(attn_scale)`，再与 score 阈值比较。旧 metadata 分支未乘 query 因子，
旧结果保留但不能用作修正后 stride=1 的质量基线。这里约束的是实数运算下
的 K score 误差代理；不保证 Triton 舍入误差或最终 attention/task error。

`--reuse-stride 1/2/4/8/16` 控制 K 深度缓存的最长有效期。每次仍计算当前
query 的误差界，缓存的低精度不再满足阈值时立即刷新；V 始终重新计算。
因此这是保守复用对照，不假定省去全部控制计算，也不保证加速。

缓存以物理 block / KV head / 子 chunk 为索引，记录选取时的序列长度、深度、
BLOCK_N、首 block 与有效 token 数。fast flush 重写 block 时清空该 block 的
缓存；过期、序列回退、首 block/子块形状变化也刷新。间接 verify 禁用复用。
当前在线协议要求 APC 关闭、页面不跨请求共享。即使标签失效未被命中，
每次使用前的当前 query + 当前 metadata 检查仍然不可省略。

复用缓存额外占用每层 `num_blocks * num_kv_heads * (GROUP/16) * 5 * 4`
字节；与 metadata 和启动时可用显存一起影响 KV capacity，报告必须保留
实际 capacity，不能将在线 TPOT 差异称为纯算子控制开销。

正式扫描前先运行 GPU 正确性门禁（输出路径必须不存在）：

```bash
python -m kvbench_progressive_online.validate_reuse --out /新的目录/gpu_gate
bash kvbench_progressive_online/run_qasper20.sh --arms p211_adaptive --reuse-stride 4 --out /新的目录/stride4
```

步长 1 检查逐值一致；门禁另外覆盖当前 query 变化、过期/换槽/flush、
single/split 和 CUDA Graph。合成门禁与已有真实 trace 冷缓存回放都不等于
跨步任务质量；最终质量必须看冻结的六个数据集各 20 条在线评分。
比较报告现按同一 dataset 匹配 parent，旧 CSV 不重写。

> **这是一次小规模真实在线主实验，不是已出结果的论文结论。** 代码尚未在目标 RTX 3090 上实际编译/运行；若未得到 `status.json: completed` 和三组 `scores.summary.json`，不能声称测得 TPOT 或模型质量。报告中绝不填假数字。

## 1. 一句话运行

```bash
cd /home/wanglin/kvbench-3090-cu126
bash kvbench_progressive_online/run_qasper20.sh \
  --upstream-suite "$PWD/results/longcontext_v3/full_longbench_C8_20261009_201156_2217646/suite.json" \
  --task qasper --count 20 --concurrency 8 --gpu 0
```

运行脚本复用原 `kvarn-serve`、`evalscope-client`、KIT/env.sh、Qwen3-4B 模型和已冻结 LongBench Qasper 数据。不安装依赖、不下载数据，不重新采集 Trace。`--plan` 可以检查选中的 20 个 case ID（无 GPU 工作，但不是强制阶段）。

输出位于新目录 `results/progressive_online/qasper20_<日期>_<PID>`；已有目录不会覆盖。依次运行三组独立 vLLM 服务，绝不与原服务并行；不会清除旧结果。

## 2. 本次只测一个数据集、三种方法

| 实验组 | KV 存储 | GPU Decode | 用途 |
|---|---|---|---|
| `parent` | 原生 KVarN K4V4，每个标量 INT4 | 原生 Attention | **真实性能和质量基线** |
| `p211_full` | 原始 INT4 无损拆成 High2/Bit1/Bit0 | GPU 对每块完整读取 4bit | 衡量拆分/拼回/额外访存的**表示成本** |
| `p211_adaptive` | 与 `p211_full` **同样的完整 4bit 存储** | 按 Query 和当前 Chunk 的 Attention 代理分数决定读 2/3/4bit | 衡量多级选择的**实际净收益** |

20 条 Qasper 来自**成功的 2026-10-09 V3 已冻结长上下文数据**，使用其已确定的随机次序前 20 条，无重分词、无隐式裁剪。Three arms 使用完全相同的 20 个 case ID、请求种子、thinking=true、temperature=0.6、top_p=0.95、top_k=20，原主实验协议的 `max_tokens:null` / 剩余上下文预算。默认 C8 并发、显存使用率 0.85、APC 关闭；vLLM 正式路径默认**启用 CUDA Graph（不加 `--enforce-eager`）**。

每组有独立 Runtime copy，基于原 `kvbench_residual.runtime` 的审核过的 KVarN 固定 Commit `7586257f...` 和源码 SHA pins；在独立副本里修改 KVarN 的 torch Writer、torch Unpacker、完整量化 materializer、Verify full-reader、Triton fused Decode single/split。GPU 真实 Attention Kernel 中加载的是独立位平面。不是 HF 输出伪装 GPU 结果，不把 CPU 反事实当 TPOT。

## 3. 2+1+1 的精确编码

原 KVarN K4V4 码为整数 `c`，范围 0..15：

```
完整 INT4: b3 b2 b1 b0

High2:       b3 b2     -> 每 tile 2bit × N，连续地址
Bit1:              b1  -> 每 tile 1bit × N，连续地址
Bit0:                 b0 -> 每 tile 1bit × N，连续地址
```

重建值：

\[
Q_2(c)=4(c\gg2)+1.5,\quad
Q_3(c)=4(c\gg2)+2[(c\gg1)\&1]+0.5,\quad
Q_4(c)=c.
\]

完整 Q4 **逐码字、逐字节数值完全等于原 INT4**，不需要重新校准，也不需要 Gaussian Lloyd Tree 的二次量化。原 KVarN 的 Scale、Zero Point、FP16 Sink/Tail Pool 保持不变。

**真实 3bit 读取不会暗中读取完整的 2bit Low Plane**：`High2` 与后两条 1bit plane 在内存中物理分开，各有不同 `tl.load`；K/V 的精度选择路径由 Triton 统一标量分支处理，读取 B1 后才决定是否进一步加载 B0。自变量 `D` 和 `GROUP` 必须同时能被 8 整除，当前明确限定 Qwen3-4B、GQA 32/8、head_dim 128、K4V4/G128。

## 4. 单次 K 精度选择与可配置 Precision Ladder

对于每个当前真实 Decode Query 与当前 KV Chunk，统一处理共享该物理 KV Head 的 4 个 GQA Query Heads。先读 K 高两位，并依靠已有的 K Scale、Q 计算查询敏感度：

\[
 r_K(q)=|\mathrm{attn\_scale}|\max_{j\in b}|r_{K,j}|
   \sum_c|q_cs_{K,c}|.
\]

K 选择不再依赖粗精度 Logit，也不再重复计算 2/3/4bit attention dot。运行时用 query、scale 和 K row scale 的 L1 敏感度估计省略低平面的 score error，若 2bit 或 3bit 满足阈值就只加载对应 prefix plane，否则加载 4bit。确定 depth 后，每个 KV chunk 只执行一次正式 K attention dot product。

精度梯度可以通过 `--k-precision-config` 配置，默认示例为 `config/k4_k_precision.json`：

```json
{"levels": [
  {"bits": 2, "threshold": 0.08},
  {"bits": 3, "threshold": 0.04},
  {"bits": 4, "threshold": 0.0}
]}
```

当前在线 kernel 的数据布局和 writer 仍限定为 K4V4，因此配置校验只允许 2/3/4-bit；precision ladder 的抽象已独立出来，后续接入 8-bit plane/layout 时不需要重写运行器参数解析。

离线 residual bound 可通过
`kvbench_progressive_online.residual_metadata.residual_bounds()` 生成。输入为
`(..., D, GROUP)` 的原始 INT4 code，输出的最后一维对应 precision ladder，
保存时使用 `write_residual_sidecar()` 生成 `.npz` 和带 SHA-256 校验的 `.json`
manifest。该 metadata 是按 KV tile 的反量化最大绝对误差界，不是在线重新执行
attention 的结果。当前 runtime 已将 metadata device pointer 接入 Triton
kernel；没有可用 metadata 的 block 仍回退到 query/scale sensitivity。

外部 sidecar 的手动接入接口为：

```python
from kvbench_progressive_online.residual_metadata import load_residual_tensor
impl._progressive_residual_metadata = load_residual_tensor(
    "k_residual.npz", device=kv_cache.device
)
```

设置该属性后，`p211_adaptive` 的 fused decode 会按
`block_id * num_kv_heads + kv_head` 读取对应 tile 的 2/3/4-bit residual
bound，并用它完成一次精度选择；属性不存在时自动回退到原来的 query/scale sensitivity。默认的 progressive
runtime 已进一步改写 KVarN backend：每次完整 block 在
`_batched_flush` 中完成 K4 写入时，直接从 writer 的 packed K 和 scale 计算
并写入 `[num_blocks, num_kv_heads, 3]` metadata，因此正常
`KVARN_FAST_FLUSH=1` 路径无需外部 sidecar。`KVARN_FAST_FLUSH=0` 的 legacy
flush 路径暂不生成 metadata，会明确走 sensitivity fallback。

得到已选 K 的 Score 后，在当前 Chunk 内立刻决定 V 精度（无需先扫完全局 K）：

\[
r_V=\frac{\max_{j\in b}|s_{V,j}|}{\max_{j\in b}\max(|z_{V,j}|,|z_{V,j}+15s_{V,j}|)}.
\]

当 `mass_proxy × 1.5 × rV <= risk-v2`，V 选 2bit；否则读 Bit1，当 `mass_proxy × 0.5 × rV <= risk-v3`，选择 3bit；否则读 Bit0 得到 4bit。全部 Query Heads 取 max risk，确保一个 GQA 物理 Chunk 统一读取深度。

默认阈值 `risk-k2=.08, risk-k3=.04, risk-v2=.12, risk-v3=.08` **属于未校准的探索性参数**，不是能够保证 Attention Error<epsilon 的置信界。每个 Decode step 读取多少 Residual 完全由实际 Query、Chunk 和阈值决定，既没有全局固定预算 B，也没有按总预算排序的 Controller。这种流式近似可能受历史访问顺序影响，不能直接声称 ReadKV 的分配最优性。K 的一次选择已移除重复的 proxy attention dot；V 仍使用已计算的 K scores 做在线选择。

**注意：** 这个 Controller 的 FP16/TF32 舍入效果、在 CUDA Graph 下的 Triton 分支及质量都需要目标 GPU 实测。它可能让推理变慢或产生明显任务质量下降，必须保留并报告负面结果。

## 5. 与 ReadKV 的区别（论文工作要明确）

| 维度 | ReadKV | 本 Progressive-KV Online v1 |
|---|---|---|
| 码本 | Gaussian Lloyd 嵌套量化树、校准均值方差 | **原 KVarN INT4 码字无损分级拆分**，无需新量化器 |
| 完整位数 | 主要使用 W=8 | **W=4（2+1+1）**，控制变量匹配已有 Qwen3-4B 基线 |
| 读取预算 | **固定 R**，按各元素边际失真贪心分配 | **无固定总预算**，在线根据当前 Chunk 的粗 Attention 风险阈值选择深度 |
| K/V 粒度 | Key 按通道，Value 按历史 Token | **K/V 都按 GPU Token Chunk**，一个物理 GQA 组统一深度 |
| 依赖 | K 精度决定后计算近似 Attention，再对 V 全局分配 | **流式处理当前 Chunk 的 K → V → Online Softmax 继续**；不建立完整 Attention 概率矩阵 |
| 精度理论 | 固定预算内校准失真代理最优 | **暂不保证误差阈值**，需要在线 Quality/TPOT 实证和后续严格风险研究 |
| 主要目标 | 读比特预算的理论失真质量 | 在现有 vLLM K4V4 GPU fused 路径上验证**实际 TPOT/吞吐与质量权衡** |

二者都基于 Progressive Precision 和 Query-aware Reading，**不应把这两个已有概念本身声称为原创**。这版的区分点是兼容已有量化缓存 + 块级融合实时判断 + 非固定每 Query 读取量。但是否具有足够新的论文贡献，仍取决于质量/延迟实验的真实性能提升和后续系统/理论完善。

## 6. TPOT 与输出文件

每组重用 `kvbench_longcontext.run`（服务端 OpenAI SSE 真正解码）以及 `kvbench_longcontext.scoring`（原 LongBench QA F1），不重新定义评分。正式结果直接输出：

```
results/progressive_online/qasper20_.../
  plan.json                   # 20个固定case ID、源套件/模型 SHA
  status.json                 # 完成/失败状态，真实完成前绝不报告成功
  settings.json
  data/qasper.jsonl           # 选中请求、Prompt、答案及原生预算
  data/manifest.json          # 新数据集Hash + 来源
  runtimes/{parent,p211_full,p211_adaptive}/runtime.json
  servers/<arm>/progressive.launch.json
  servers/<arm>/server.log
  servers/<arm>/dispatch_summary.json
  runs/<arm>/r01_qasper_C8/requests.jsonl
  runs/<arm>/r01_qasper_C8/performance.summary.json
  runs/<arm>/r01_qasper_C8/scores.jsonl
  runs/<arm>/r01_qasper_C8/scores.summary.json
  runs/<arm>/r01_qasper_C8/telemetry.jsonl
  logs/*.log
  comparison.csv
  comparison.json
  paired_quality.csv
  readout.md                  # 最终中文三组对照表
```

### 指标定义

- **TPOT**：每请求 `(E2E - 首个内容/思考片段时间)/(native completion_tokens-1)`，按请求等权平均；报告 P95。这是包含 HTTP/调度的在线 TPOT，不是一个纯 Triton Kernel 时间。
- **TTFT**：首个内容或 reasoning 片段的延迟；不是“最终验证完成的第一个回答 token”专用指标。
- **Output Tokens/s**：并发请求总完成 Token / 真实测量窗口。
- **LongBench Score**：Qasper 官方 QA F1，转换为 0~100 分；20 个 case 逐一配对，不丢弃截断响应。
- **GPU 使用量**：nvidia-smi 周期采样的显存使用峰值，是 GPU-wide 采样值，不等于算子的 Peak Allocated 或 HBM 物理读取计数。
- **输出长度/E2E/Preemptions**：报告辅助解读 TPOT，避免把生成更短误当作 Kernel 加速。

本补丁**不**提供真实 `dram__bytes_read`、逐 Chunk 的动态精度占比或逐 token CUDA events；如以后要核实逻辑节省是否变成物理 DRAM 节省，可再单独启用 ncu。但这不是运行此次 20 条在线主实验的前置条件。

## 7. 补丁使用步骤

方案 A（Git Apply）：

```bash
cd /home/wanglin/kvbench-3090-cu126
PATCH=/绝对路径/kvbench_progressive_online_qasper20_20261015.patch
git apply --check "$PATCH"
git apply "$PATCH"
# 可选的轻量正确性测试，CPU 9 项
source /home/wanglin/miniconda3/etc/profile.d/conda.sh
conda activate kvarn-serve
python -m unittest discover -s kvbench_progressive_online/tests -v
# 真正的三组 GPU 在线实验
bash kvbench_progressive_online/run_qasper20.sh \
 --upstream-suite "$PWD/results/longcontext_v3/full_longbench_C8_20261009_201156_2217646/suite.json" \
 --task qasper --count 20 --concurrency 8 --gpu 0
```

方案 B：源码 ZIP 直接解压到项目根目录，跳过 `git apply`，后续执行完全相同。不要既解压又重复应用补丁。

如需要先看选择了哪 20 条（非必须）：

```bash
bash kvbench_progressive_online/run_qasper20.sh --plan
```

若 CUDA 编译失败，先读 `status.json`、`logs/p211_*.server_launcher.log`、`servers/p211_*/server.log`，保留实际 Triton traceback；不要用其他生成结果代替失败实验。源码固定 SHA 不匹配时明确停止，不强行修改旧版 vLLM。

### 运行环境与验证边界

2026-10-16 19:26 新启动三版本同期短对照：
`results/progressive_online/alternating_writer_20261016_192606_193596/`。
入口 `alternating_online.py`，以 nohup 运行；`status.json` 是本批次总状态。
顺序为 native/planar/fused、planar/fused/native、fused/native/planar，
共九次独立服务会话，Qasper/HotpotQA 各八条、C8，每点预热全部八条请求，
正式输出上限 64，共 144 条测量请求。保持各版本默认 reader 配置，
因此比较部署行为，不宣称搜索过所有最优 native 参数。
`measurements.json` 逐会话落盘；完成后生成 `comparison.json`、
`generation_agreement.json`、`readout.json`。生成文本一致性不等于任务精度验证。
`flush_breakdown.py` 在独立子进程中记录实际 backend 的 Sinkhorn、K/V 量化与打包、
位打包范围，并保留记录拼接/scatter/gather 的 CPU 操作及原始时间线。
三个版本先将实际写入记录统一转换为 native 位布局，比较完整字节后才开始在线测量。
写入剖析使用两个物理页的受控输入；不能将其占比直接外推到整个在线服务。
本批次不启动在线 profiler，避免上轮停止采集超时影响正式实验。

2026-10-16 分阶段优化的新批次：
`results/progressive_online/staged_optimization_20261016_174407_183860/`。
这是 RTX 3090 / `kvarn-serve` 上的实际实验，下面早期交付说明不代表本批次验证状态。

- `staged_probe.py`：真实 backend flush 原版/融合版正确性和 CPU/CUDA 时间线；
  uint8/int32、1/8/64/256 tile 打包及元数据的 eager/graph 计时；
  三条真实快照、split=32、B1/复制 B8、BLOCK_N=16/32/64 的固定 reader 对照。
- `fused_writer.py`：融合位平面打包，K 批量写入可同时生成残差元数据。
  没有融合 Sinkhorn、RTN 量化、记录组装和 scatter。`fused_runtime.py` 只修改新私有 runtime，
  更新全部哈希后验证；不修改已安装 vLLM 或旧实验 runtime。
- `staged_online.py`：完整 K4V4、相同 reader 配置的原版/融合 writer 对照；
  Qasper/HotpotQA 各 8 条，C8、2 轮，每个点先预热全部 8 条长请求。
  128-token 固定上限，仅诊断性能。测量结束后单独运行 HotpotQA C8、16-token profiler，
  profiler 请求不能纳入正式性能比较。保留 SSE、Prometheus、GPU/队列采样。
- `budget_probe.py`：固定 reader 在全部筛选形状超过最佳 native 10% 后才启动。
  一个快照用于校准、另两个用于验证；单个 GPU selector 按当前查询及校准敏感度选择
  2/8 KV head 使用 K4，其他 K2，V 固定 2bit；与相同预算的静态分配比较。
  这是参考 ReadKV 的粗粒度启发式，非论文复现、非误差保证，也未做在线任务精度验证。
- `finish_staged.py`：等待在线实验完成后串行运行预算试验，输出 `final_analysis.json`。
  `continuation.status.json` 是整条后台流水线的状态；失败保留日志并停止，不伪装完成。

算子初步结果：真实 flush 正确性通过；排除首轮 JIT 后，原版/融合版每次
196/44 个 GPU kernel。固定 K2V2 的最佳 tile 在全部六个筛选形状达到 10% 加速门槛，
K4V2 未达到。B8 快照复用同一上下文，存在缓存局部性偏差；不能据此宣称在线 C8 加速。
`flush_attribution.json` 通过 CUDA runtime/driver launch correlation 归因，包含 Triton kernel。
DRAM 硬件计数仍无权限，所有实际字节量均标记为缺失。

依赖仓库已有 `kvbench_residual/`、`kvbench_longcontext/` 和已运行的 Qwen3-4B/KVarN fork。没有使用之前的离线 `kvbench_progressive` 包，因此可直接在未应用上一版补丁时使用。

已经在交付环境验证：Python 编译、Shell 语法、NumPy/Torch CPU 编码无损往返、物理 bit-plane 地址、源码变换局部测试。**未在交付环境运行目标 RTX 3090、Triton Kernel 编译、在线生成、LongBench 打分或 TPOT**。实际结果应从本补丁的用户侧运行中产生。
