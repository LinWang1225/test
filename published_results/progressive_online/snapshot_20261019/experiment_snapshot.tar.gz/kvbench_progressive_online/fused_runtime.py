"""Install experimental writer fusion only in a fresh private runtime."""
import ast
from pathlib import Path
from kvbench_residual.runtime import sha_file, text_sha, atomic_json
from .runtime import verify
from .transform import STORE, BACKEND


def install(root, arm):
    root = Path(root)
    manifest = verify(root, arm)
    if manifest['progressive'].get('fused_writer'):
        raise ValueError('Writer fusion already installed')
    path = root/'vllm'/STORE
    source = path.read_text()
    old = 'from kvbench_progressive_online.codec import pack_211_torch'
    if source.count(old) != 2:
        raise ValueError('Unexpected pack imports')
    source = source.replace(old, 'from kvbench_progressive_online.fused_writer import pack as pack_211_torch')
    if arm == 'p211_adaptive':
        start = source.index('def kvarn_store_tile_k_batch_from_sinkhorn(')
        end = source.index('\ndef kvarn_store_tile_v_batch_from_sinkhorn(', start)
        body = source[start:end]
        old = '    q_packed = _pack_lowbit(q, bits)'
        if body.count(old) != 1:
            raise ValueError('Unexpected batched K pack')
        body = body.replace(old, '    from kvbench_progressive_online.fused_writer import pack\n'
            '    if bits != 4: raise ValueError("Fused writer requires K4")\n'
            '    q_packed, residual = pack(q, s_col_K.contiguous(), s_row_K.contiguous())')
        body = body.replace('"q_packed_uint8": q_packed,', '"q_packed_uint8": q_packed,\n        "_progressive_bounds": residual,')
        source = source[:start]+body+source[end:]
        backend = root/'vllm'/BACKEND
        text = backend.read_text()
        old = ("                residual_bounds = torch_residual_bounds_from_quantized(\n"
               "                    K_out['q_packed_uint8'], K_out['s_col_K'], K_out['s_row_K'],\n"
               "                    packing='planes_211')")
        if text.count(old) != 1:
            raise ValueError('Unexpected metadata site')
        text = text.replace(old, "                residual_bounds = K_out['_progressive_bounds']")
        ast.parse(text)
        backend.write_text(text)
        manifest['generated_sha256'][BACKEND] = text_sha(text)
        manifest['executed_files_sha256'][BACKEND] = sha_file(backend)
    ast.parse(source)
    path.write_text(source)
    manifest['generated_sha256'][STORE] = text_sha(source)
    manifest['executed_files_sha256'][STORE] = sha_file(path)
    manifest['progressive']['fused_writer'] = {
        'scope': 'Fused planar packing; adaptive batched K also produces residual bounds directly',
        'not_fused': 'Sinkhorn, RTN quantization, record assembly, scatter and host orchestration',
        'source_sha256': sha_file(root/'kvbench_progressive_online/fused_writer.py')}
    manifest['files_sha256'] = {str(p.relative_to(root)): sha_file(p) for p in sorted(root.rglob('*'))
        if p.is_file() and not p.is_symlink() and p.name != 'runtime.json' and '__pycache__' not in p.parts}
    atomic_json(root/'runtime.json', manifest)
    verify(root, arm)
