# SPDX-License-Identifier: Apache-2.0
"""Strict source-to-source transformation on the pinned KVarN AR full-reader.

NOT a monkeypatch to the live package. Independent private vLLM runtime only.
All five packed consumers of the original full 4-bit code must be adapted:
(1) full-read dequant helper, (2) packed materializer, (3) dedicated verify,
(4) fused decode single, (5) fused decode split.
The store (torch writer) and torch unpack are also adapted.
"""
from __future__ import annotations
import ast
import re

from .kernel import FULL, ADAPTIVE
from .precision import DEFAULT_K_LEVELS

DECODE='v1/attention/ops/triton_kvarn_decode.py'
BACKEND='v1/attention/backends/kvarn_attn.py'
STORE='v1/attention/ops/kvarn_store.py'
TORCH_DECODE='v1/attention/ops/kvarn_decode.py'
ARMS=('parent','p211_full','p211_adaptive')
DEFAULT_THRESHOLDS={'k2':DEFAULT_K_LEVELS[0].threshold,
                   'k3':DEFAULT_K_LEVELS[1].threshold,'v2':0.12,'v3':0.08}


def _fn_rewrite(source,updates):
    lines=source.splitlines(keepends=True)
    edits=[]
    for node in ast.parse(source).body:
        if isinstance(node,ast.FunctionDef) and node.name in updates:
            old=''.join(lines[node.lineno-1:node.end_lineno])
            edits.append((node.lineno-1,node.end_lineno,updates[node.name](old)))
    missing=set(updates)-{node.name for node in ast.parse(source).body if isinstance(node,ast.FunctionDef)}
    if missing:raise ValueError('Missing KVarN pinned functions: '+str(sorted(missing)))
    for begin,end,text in sorted(edits,reverse=True):lines[begin:end]=[text]
    result=''.join(lines)
    ast.parse(result)
    return result


def _full_consumer(body,side,cols):
    # Exactly the strings emitted by kvbench_residual.transform._consumer.
    high=side.upper()
    pattern=(rf'(?m)^(?P<ind> +)ar_{side}_high = tl.load\(KV_cache_ptr \+ {side}_addrs\).to\(tl.int32\)\n'
             rf'(?P=ind)ar_{side}_low = tl.load\(KV_cache_ptr \+ {side}_addrs \+ D \* GROUP // 4\).to\(tl.int32\)\n'
             rf'(?P=ind)q_{high} = .*?\.to\(tl.float32\)')
    found=list(re.finditer(pattern,body))
    if not found:
        return _current_full_consumer(body,side)
    if len(found)!=1:
        raise ValueError(f'Expected one exact {side} full-consumer span, got {len(found)}')
    m=found[0]; ind=m.group('ind')
    if side=='k':
        addr=f'tile_base + K_PACKED_OFFSET + D * GROUP // 4 + d_offs[:, None] * (GROUP // 8) + {cols}[None, :] // 8'
        shift=f'{cols}[None, :] % 8'
        highshift=f'2 * ({cols}[None, :] % 4)'
    else:
        addr=f'tile_base + V_PACKED_OFFSET + D * GROUP // 4 + {cols}[:, None] * (D // 8) + d_offs[None, :] // 8'
        shift='d_offs[None, :] % 8'
        highshift='2 * (d_offs[None, :] % 4)'
    repl=[f'ar_{side}_bit_addr = {addr}',
          f'ar_{side}_high = tl.load(KV_cache_ptr + {side}_addrs).to(tl.int32)',
          f'ar_{side}_bit1 = tl.load(KV_cache_ptr + ar_{side}_bit_addr).to(tl.int32)',
          f'ar_{side}_bit0 = tl.load(KV_cache_ptr + ar_{side}_bit_addr + D * GROUP // 8).to(tl.int32)',
          f'q_{high} = (4 * ((ar_{side}_high >> ({highshift})) & 3) + 2 * ((ar_{side}_bit1 >> ({shift})) & 1) + ((ar_{side}_bit0 >> ({shift})) & 1)).to(tl.float32)']
    return body[:m.start()]+('\n'.join(ind+x for x in repl))+body[m.end():]


def _current_full_consumer(body,side):
    """Rewrite the current PACK_K/MASK_K KVarN consumer form."""
    if side == 'k':
        pattern=(r'(?ms)^(?P<ind> +)k_addrs = \(.*?'
                 r'^(?P=ind)(?P<out>K_rot_out|K_dg) = .*?$')
        replacement='''{ind}k_hi_addrs = (
{ind}    tile_base + K_PACKED_OFFSET
{ind}    + d_offs[:, None] * (GROUP // 4)
{ind}    + cols[None, :] // 4
{ind})
{ind}k_bit_addrs = (
{ind}    tile_base + K_PACKED_OFFSET + D * GROUP // 4
{ind}    + d_offs[:, None] * (GROUP // 8)
{ind}    + cols[None, :] // 8
{ind})
{ind}k_hi_bytes = tl.load(KV_cache_ptr + k_hi_addrs).to(tl.int32)
{ind}k_bit1_bytes = tl.load(KV_cache_ptr + k_bit_addrs).to(tl.int32)
{ind}k_bit0_bytes = tl.load(KV_cache_ptr + k_bit_addrs + D * GROUP // 8).to(tl.int32)
{ind}q_K = (4 * ((k_hi_bytes >> (2 * (cols[None, :] % 4))) & 3)
{ind}        + 2 * ((k_bit1_bytes >> (cols[None, :] % 8)) & 1)
{ind}        + ((k_bit0_bytes >> (cols[None, :] % 8)) & 1)).to(tl.float32)
{ind}K_dg = (q_K * s_col_K[:, None] + zp_K[:, None]) * s_row_K[None, :]'''.format(ind='{ind}')
    else:
        pattern=(r'(?ms)^(?P<ind> +)v_addrs = \(.*?'
                 r'^(?P=ind)(?P<out>V_rot|Vc) = .*?$')
        replacement='''{ind}v_hi_addrs = (
{ind}    tile_base + V_PACKED_OFFSET
{ind}    + cols[:, None] * (D // 4)
{ind}    + d_offs[None, :] // 4
{ind})
{ind}v_bit_addrs = (
{ind}    tile_base + V_PACKED_OFFSET + D * GROUP // 4
{ind}    + cols[:, None] * (D // 8)
{ind}    + d_offs[None, :] // 8
{ind})
{ind}v_hi_bytes = tl.load(KV_cache_ptr + v_hi_addrs).to(tl.int32)
{ind}v_bit1_bytes = tl.load(KV_cache_ptr + v_bit_addrs).to(tl.int32)
{ind}v_bit0_bytes = tl.load(KV_cache_ptr + v_bit_addrs + D * GROUP // 8).to(tl.int32)
{ind}q_V = (4 * ((v_hi_bytes >> (2 * (d_offs[None, :] % 4))) & 3)
{ind}        + 2 * ((v_bit1_bytes >> (d_offs[None, :] % 8)) & 1)
{ind}        + ((v_bit0_bytes >> (d_offs[None, :] % 8)) & 1)).to(tl.float32)
{ind}Vc = (q_V * s_row_V[:, None] + zp_V[:, None]) * s_col_V[None, :]'''.format(ind='{ind}')
    match=re.search(pattern,body)
    if match is None:
        raise ValueError(f'Expected current {side} packed consumer span')
    indent=match.group('ind')
    rewritten = replacement.format(ind=indent)
    if side == 'k' and match.group('out') == 'K_rot_out':
        rewritten = rewritten.replace(
            f'{indent}K_dg = (q_K * s_col_K[:, None] + zp_K[:, None]) * s_row_K[None, :]',
            f'{indent}K_rot = (q_K * s_col_K[:, None] + zp_K[:, None]) * s_row_K[None, :]\n'
            f'{indent}K_rot_out = tl.trans(K_rot)',
        )
    if side == 'v' and match.group('out') == 'V_rot':
        rewritten = rewritten.replace(
            f'{indent}Vc = (q_V * s_row_V[:, None] + zp_V[:, None]) * s_col_V[None, :]',
            f'{indent}V_rot = (q_V * s_row_V[:, None] + zp_V[:, None]) * s_col_V[None, :]',
        )
    return body[:match.start()]+rewritten+body[match.end():]


def _fused(body,arm,thresholds):
    if arm == 'p211_adaptive':
        body=body.replace(
            '    AR_STATS_PTR=None,\n',
            '    AR_RESIDUAL_PTR,\n'
            '    AR_RESIDUAL_ENABLED: tl.constexpr = False,\n'
            '    AR_REUSE_PTR=None,\n'
            '    AR_REUSE_ENABLED: tl.constexpr = False,\n'
            '    AR_STATS_PTR=None,\n',
            1,
        )
    first='                # Separate 2-bit planes occupy disjoint halves of each code field.'
    last='                Vc = (q_V * s_row_V[:, None] + zp_V[:, None]) * s_col_V[None, :]'
    if body.count(first)!=1 or body.count(last)!=1:
        current_start='                # int4 dequant for this chunk of tokens (ONCE, shared by all q heads).'
        if body.count(current_start)==1:
            a=body.index(current_start)
        else:
            matches=list(re.finditer(r'(?m)^                k_addrs = ',body))
            if len(matches)!=1:
                raise ValueError('Expected exact original AR quantized-chunk landmarks')
            a=matches[0].start()
        b=body.index('                Vc = ',a)
        line_end=body.index('\n',b)
        body=body[:a]+((ADAPTIVE if arm=='p211_adaptive' else FULL).strip('\n'))+body[line_end:]
        return body
    a=body.index(first);b=body.index(last,a)+len(last)
    body=body[:a]+((ADAPTIVE if arm=='p211_adaptive' else FULL).strip('\n'))+body[b:]
    if arm=='p211_adaptive':
        # Pool chunks must update the same single-pass selected-K prefix LSE.
        marker='                if AR_POLICY >= 3:'
        if body.count(marker)!=1:
            raise ValueError(f'Expected exactly one pool-prefix marker, got {body.count(marker)}')
        body=body.replace(marker,'                if True:',1)
        local='    AR_POLICY: tl.constexpr = 1\n'
        if body.count(local)!=1:raise ValueError('Unable to pin compile-time adaptive constants')
        constants=''.join(f'    PROG_{k.upper()}: tl.constexpr = {thresholds[k]!r}\n' for k in ('k2','k3','v2','v3'))
        constants+=f'    PROG_REUSE_STRIDE: tl.constexpr = {thresholds.get("reuse_stride", 1)!r}\n'
        # Triton local compile-time parameters are inserted before the program IDs.
        constants=constants.replace('PROG_K2','PROG_K_2').replace('PROG_K3','PROG_K_3').replace('PROG_V2','PROG_V_2').replace('PROG_V3','PROG_V_3')
        body=body.replace(local,local+constants,1)
    return body


def transform_dequant(original,arm,thresholds=None):
    if arm not in ('p211_full','p211_adaptive'):raise ValueError('Unexpected arm')
    thresholds=DEFAULT_THRESHOLDS if thresholds is None else thresholds
    for k in DEFAULT_THRESHOLDS:
        control_full = all(thresholds.get(key) == -1.0 for key in ('k2','k3','v2','v3'))
        if k not in thresholds or not (control_full or 0<=float(thresholds[k])<10):raise ValueError('Invalid risk threshold '+k)
    marker='\n# AR-KV provenance hook:'
    if marker not in original:raise ValueError('AR source must include its provenance hook')
    source=original
    sources={
        '_kvarn_dequant_blocks_kernel':lambda s:_full_consumer(_full_consumer(s,'k','g_offs'),'v','g_offs'),
        '_kvarn_build_packed_kv_kernel':lambda s:_full_consumer(_full_consumer(s,'k','g_offs'),'v','g_offs'),
        '_kvarn_fused_verify_stage1':lambda s:_full_consumer(_full_consumer(s,'k','cols'),'v','cols'),
        '_kvarn_fused_decode_kernel':lambda s:_fused(s,arm,thresholds),
        '_kvarn_fused_decode_stage1':lambda s:_fused(s,arm,thresholds),
    }
    source=_fn_rewrite(source,sources)
    if arm == 'p211_adaptive':
        metadata_setup=(
            '    _progressive_residual_metadata = getattr(impl, "_progressive_residual_metadata", None)\n'
            '    _progressive_residual_enabled = _progressive_residual_metadata is not None\n'
            '    _progressive_reuse = getattr(impl, "_progressive_reuse", None)\n'
        )
        common_fields=(
            '        AR_RESIDUAL_PTR=(kv_cache if _progressive_residual_metadata is None else _progressive_residual_metadata),\n'
            '        AR_RESIDUAL_ENABLED=_progressive_residual_enabled,\n'
            '        AR_REUSE_PTR=(kv_cache if _progressive_reuse is None else _progressive_reuse),\n'
            '        AR_REUSE_ENABLED=(_progressive_reuse is not None),\n'
        )
        common_count=source.count('    common = dict(')
        if common_count < 2:
            raise ValueError('Expected decode and verify launch dictionaries')
        # Only the decode driver launches these adaptive kernels. The separate
        # full-reader verify kernel has no metadata/reuse arguments.
        source=source.replace('    common = dict(', metadata_setup+'    common = dict(', 1)
        common_end='        V_S_ROW_OFFSET=cfg.v_s_row_offset, V_ZP_OFFSET=cfg.v_zp_offset,\n'
        common_end_count=source.count(common_end)
        if common_end_count < 2:
            raise ValueError('Expected decode and verify launch dictionaries')
        source=source.replace(common_end, common_end+common_fields, 1)
    # AR policy and hash stay bound to this private runtime through the updated
    # runtime.json; do NOT omit the provenance hook appended by the AR builder.
    return source


def transform_writer(original):
    old='from kvbench_residual.representation import pack_planes_torch'
    if original.count(old)!=2:raise ValueError('Expected two KVarN store packer imports')
    result=original.replace(old,'from kvbench_progressive_online.codec import pack_211_torch')
    if result.count('return pack_planes_torch(q)')!=2:
        raise ValueError('Expected exactly two 4-bit store uses')
    result=result.replace('return pack_planes_torch(q)','return pack_211_torch(q)')
    ast.parse(result)
    return result


def transform_torch_decode(original):
    old='from kvbench_residual.representation import unpack_planes_torch'
    if original.count(old)!=1:raise ValueError('Expected KVarN unpack source')
    result=original.replace(old,'from kvbench_progressive_online.codec import unpack_211_torch')
    if result.count('return unpack_planes_torch(packed, original_last_dim)')!=1:
        raise ValueError('Expected KVarN torch unpack call')
    result=result.replace('return unpack_planes_torch(packed, original_last_dim)',
                          'return unpack_211_torch(packed, original_last_dim)')
    ast.parse(result)
    return result


def transform_backend(original, reuse_stride=1):
    """Attach per-block residual bounds to the real KVarN flush path."""
    import_line = "import torch\n"
    if original.count(import_line) != 1:
        raise ValueError("Expected one torch import in KVarN backend")
    result = original.replace(
        import_line,
        import_line + (
            "from kvbench_progressive_online.residual_metadata import "
            "torch_residual_bounds_from_quantized\n"
        ),
        1,
    )
    init_marker = "        self._kv_cache_ref: torch.Tensor | None = None\n"
    if result.count(init_marker) != 1:
        raise ValueError("Expected KVarN cache reference initialization")
    result = result.replace(
        init_marker,
        init_marker + (
            "        self._progressive_residual_metadata: torch.Tensor | None = None\n"
            "        self._progressive_reuse: torch.Tensor | None = None\n"
        ),
        1,
    )
    flush_marker = "            if kvc is None:\n                continue\n"
    if result.count(flush_marker) < 1:
        raise ValueError("Expected batched flush cache guard")
    result = result.replace(
        flush_marker,
        flush_marker + (
            "            if (impl._progressive_residual_metadata is None or\n"
            "                    impl._progressive_residual_metadata.shape[0] < kvc.shape[0]):\n"
            "                impl._progressive_residual_metadata = torch.zeros(\n"
            "                    kvc.shape[0], Hk, 3, dtype=torch.float32,\n"
            "                    device=kvc.device)\n"
        ),
        1,
    )
    pack_marker = "                K_out, V_out = _sinkhorn_pack_kv(K_tiles, V_tiles, cfg)\n"
    if result.count(pack_marker) != 1:
        raise ValueError("Expected vectorized KVarN flush pack")
    result = result.replace(
        pack_marker,
        pack_marker + (
            "                residual_bounds = torch_residual_bounds_from_quantized(\n"
            "                    K_out['q_packed_uint8'], K_out['s_col_K'], K_out['s_row_K'],\n"
            "                    packing='planes_211')\n"
        ),
        1,
    )
    write_marker = "                kvc[bid_t] = rec.view(nB, Hk, T)\n"
    if result.count(write_marker) != 1:
        raise ValueError("Expected vectorized KVarN flush write")
    result = result.replace(
        write_marker,
        write_marker + (
            "                impl._progressive_residual_metadata[bid_t] = (\n"
            "                    residual_bounds.view(nB, Hk, 3))\n"
            "                if impl._progressive_reuse is not None:\n"
            "                    impl._progressive_reuse[bid_t] = 0\n"
        ),
        1,
    )
    if reuse_stride > 1:
        allocation_marker = "        self._block_lookup_size = self._block_to_slot_t.shape[0]\n"
        if result.count(allocation_marker) != 1:
            raise ValueError('Expected lookup allocation marker for reuse state')
        result = result.replace(allocation_marker, allocation_marker + (
            "        if (self._progressive_reuse is None or\n"
            "                self._progressive_reuse.shape[0] != self._block_lookup_size):\n"
            "            self._progressive_reuse = torch.zeros(\n"
            "                self._block_lookup_size, self.num_kv_heads,\n"
            "                self.kvarn_config.group // 16, 5,\n"
            "                dtype=torch.int32, device=device)\n"
        ), 1)
    warmup_marker = "            V_S_ROW_OFFSET=cfg.v_s_row_offset, V_ZP_OFFSET=cfg.v_zp_offset,\n            VQ_INDIRECT=False,"
    if result.count(warmup_marker) != 1:
        raise ValueError("Expected KVarN decode warmup launch dictionary")
    result = result.replace(
        warmup_marker,
        "            V_S_ROW_OFFSET=cfg.v_s_row_offset, V_ZP_OFFSET=cfg.v_zp_offset,\n"
        "            AR_RESIDUAL_PTR=torch.zeros(B * n_blocks, Hk, 3,\n"
        "                                         dtype=torch.float32, device=device),\n"
        "            AR_RESIDUAL_ENABLED=False,\n"
        "            VQ_INDIRECT=False,",
        1,
    )
    ast.parse(result)
    return result
