"""Configurable progressive precision ladders for online selection."""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path


@dataclass(frozen=True)
class PrecisionLevel:
    bits: int
    threshold: float


DEFAULT_K_LEVELS = (
    PrecisionLevel(2, 0.08),
    PrecisionLevel(3, 0.04),
    PrecisionLevel(4, 0.0),
)


def load_levels(path: Path | None, defaults=DEFAULT_K_LEVELS):
    if path is None:
        return defaults
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    levels = tuple(PrecisionLevel(int(item["bits"]), float(item["threshold"]))
                   for item in value["levels"])
    validate_levels(levels)
    return levels


def validate_levels(levels):
    if not levels:
        raise ValueError("Precision ladder must not be empty")
    previous = 0
    for level in levels:
        if level.bits <= previous or level.bits < 1:
            raise ValueError("Precision levels must have increasing positive bit counts")
        if level.threshold < 0:
            raise ValueError("Precision thresholds must be non-negative")
        previous = level.bits
    if levels[-1].threshold != 0:
        raise ValueError("The highest precision level must have threshold 0")
    return levels


def level_thresholds(levels):
    validate_levels(levels)
    return {level.bits: level.threshold for level in levels}
