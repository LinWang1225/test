"""Attribute kernels via launch correlation, including Triton driver launches."""
import json
from pathlib import Path
from kvbench_longcontext.common import atomic_json


def analyze(root):
    root=Path(root);report={}
    for name in ('original','fused'):
        events=json.loads((root/('flush_'+name)/'actual_flush.trace.json').read_text())['traceEvents']
        spans=sorted([e for e in events if e.get('name')=='actual_fast_flush'
            and e.get('cat')=='user_annotation' and e.get('pid')!=0],key=lambda e:e['ts'])
        rows=[]
        for span in spans:
            children=[e for e in events if e.get('pid')==span['pid'] and e.get('tid')==span['tid']
                and e.get('ph')=='X' and e.get('ts',0)>=span['ts']
                and e.get('ts',0)+e.get('dur',0)<=span['ts']+span['dur']]
            correlations={e.get('args',{}).get('correlation') for e in children
                if e.get('cat') in ('cuda_runtime','cuda_driver')}
            correlations.discard(None)
            gpu=[e for e in events if e.get('cat')=='kernel'
                 and e.get('args',{}).get('correlation') in correlations]
            rows.append({'cpu_span_us':span['dur'],'cpu_op_count':sum(e.get('cat')=='cpu_op' for e in children),
                'gpu_kernels':len(gpu),'gpu_sum_us':sum(e.get('dur',0) for e in gpu),
                'fused_pack_kernels':sum(e.get('name')=='_pack' for e in gpu)})
        report[name]=rows
    report['limits']='Profiler overhead; first rewrite includes JIT. GPU sum is not wall time. Kernel attribution uses runtime AND driver launch correlation; oracle work outside actual_fast_flush excluded.'
    atomic_json(root/'flush_attribution.json',report)
    return report


if __name__=='__main__':
    import sys
    print(json.dumps(analyze(sys.argv[1]),indent=2))
