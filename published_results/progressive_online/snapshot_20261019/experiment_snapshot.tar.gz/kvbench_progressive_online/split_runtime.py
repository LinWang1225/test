"""Source transform mapping every packed-cache load to global disjoint planes."""
import ast,copy
from pathlib import Path
from .transform import DECODE,BACKEND
from .runtime import verify
from kvbench_residual.runtime import atomic_json,sha_file,text_sha,trace_footer

FIELDS=((0,4096),(8960,4096),(4096,2048),(13056,2048),(6144,2048),(15104,2048),(8192,768),(17152,768))
CONSTANTS={'D':128,'GROUP':128,'K_PACKED_OFFSET':0,'V_PACKED_OFFSET':8960,'K_S_COL_OFFSET':8192,'K_ZP_OFFSET':8448,'K_S_ROW_OFFSET':8704,'V_S_COL_OFFSET':17152,'V_S_ROW_OFFSET':17408,'V_ZP_OFFSET':17664}

def const(node):
 if isinstance(node,ast.Constant) and isinstance(node.value,int):return node.value
 if isinstance(node,ast.Name) and node.id in CONSTANTS:return CONSTANTS[node.id]
 if isinstance(node,ast.BinOp):
  a,b=const(node.left),const(node.right)
  if a is not None and b is not None:
   if isinstance(node.op,ast.Add):return a+b
   if isinstance(node.op,ast.Sub):return a-b
   if isinstance(node.op,ast.Mult):return a*b
   if isinstance(node.op,ast.FloorDiv):return a//b
 return None

def terms(node):
 if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Add):return terms(node.left)+terms(node.right)
 if isinstance(node,ast.BinOp) and isinstance(node.op,ast.Mult):
  # uint16 pointer arithmetic expanded into byte offsets.
  if const(node.right)==2 and isinstance(node.left,ast.BinOp) and isinstance(node.left.op,ast.Add):
   return terms(ast.BinOp(node.left.left,ast.Mult(),ast.Constant(2)))+terms(ast.BinOp(node.left.right,ast.Mult(),ast.Constant(2)))
  if const(node.left)==0 or const(node.right)==0:return []
 return [node]

class Loads(ast.NodeTransformer):
 def __init__(self,fn):
  self.aliases={};self.changed=0
 def visit_Assign(self,n):
  raw=copy.deepcopy(n.value)
  result=self.generic_visit(n)
  if len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
   name=n.targets[0].id
   if name=='ku16' or name.endswith(('_addr','_addrs')):self.aliases[name]=raw
  return result
 def expand(self,n):
  if isinstance(n,ast.Name) and n.id in self.aliases:return self.expand(copy.deepcopy(self.aliases[n.id]))
  if isinstance(n,ast.BinOp):return ast.BinOp(self.expand(n.left),n.op,self.expand(n.right))
  return n
 def pointer(self,n):
  n=self.expand(n)
  if isinstance(n,ast.Name) and n.id=='KV_cache_ptr':return ast.Constant(0),1,'tl.uint8'
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='to':
   p=self.pointer(n.func.value)
   if p is not None:
    dtype=ast.unparse(n.args[0])
    if dtype not in ('tl.pointer_type(tl.uint16)','tl.pointer_type(tl.float16)'):raise ValueError('Unexpected cache pointer cast '+dtype)
    return p[0],2,dtype[len('tl.pointer_type('):-1]
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Add):
   p=self.pointer(n.left)
   if p is not None:return ast.BinOp(p[0],ast.Add(),(n.right if p[1]==1 else ast.BinOp(n.right,ast.Mult(),ast.Constant(p[1])))),p[1],p[2]
  return None
 def visit_Call(self,n):
  if isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='tl' and n.func.attr=='load':
   p=self.pointer(n.args[0])
   if p is not None:
    xs=terms(p[0]);constant=0;dynamic=[];tile=False
    for x in xs:
     v=const(x)
     if v is not None:constant+=v
     elif ast.unparse(x) in ('tile_base','tile_base * 1'):tile=True
     else:
      # Strip multiplication by one introduced by byte pointers.
      if isinstance(x,ast.BinOp) and isinstance(x.op,ast.Mult) and const(x.right)==1:x=x.left
      if isinstance(x,ast.Name) and x.id=='tile_base':tile=True
      else:dynamic.append(ast.unparse(x))
    if not tile:raise ValueError('Cache access missing tile_base: '+ast.unparse(n.args[0]))
    prefix=0;field=None
    for start,size in FIELDS:
     if start<=constant<start+size:field=(start,size,prefix);break
     prefix+=size
    if field is None:raise ValueError('Unknown packed-cache field '+str(constant))
    start,size,prefix=field
    expr=f'KV_cache_ptr + SOA_TILES * {prefix} + (block_id.to(tl.int64) * (stride_kv_b // stride_kv_h) + hk) * {size} + {constant-start}'
    for x in dynamic:expr+=' + ('+x+')'
    if p[1]==2:expr='('+expr+').to(tl.pointer_type('+p[2]+'))'
    n.args[0]=ast.parse(expr,mode='eval').body;self.changed+=1
  return self.generic_visit(n)

def decode_source(source):
 tree=ast.parse(source);counts={}
 for i,n in enumerate(tree.body):
  if isinstance(n,ast.FunctionDef) and 'KV_cache_ptr' in [a.arg for a in n.args.args]:
   rewriter=Loads(n);tree.body[i]=rewriter.visit(n)
   n.args.args.append(ast.arg(arg='SOA_TILES',annotation=ast.Attribute(ast.Name('tl',ast.Load()),'constexpr',ast.Load())))
   n.args.defaults.append(ast.Constant(0));counts[n.name]=rewriter.changed
   if not rewriter.changed:raise ValueError('Unconverted cache consumer '+n.name)
 ast.fix_missing_locations(tree)
 result=ast.unparse(tree)+'\n'
 # Install wrappers before provenance hooks, so receipts still bind the actual source.
 old="_ar_install_trace(globals(), __file__, 'repacked_full')"
 if result.count(old)!=1:raise ValueError('Production provenance hook missing')
 result=result.replace(old,"from kvbench_progressive_online.split_storage import install_kernels\ninstall_kernels(globals())\n"+old)
 return result,counts

def install(root,arm='p211_full'):
 root=Path(root);m=verify(root,arm)
 if m['progressive'].get('global_split_storage'):raise ValueError('Already installed')
 path=root/'vllm'/DECODE;source,counts=decode_source(path.read_text());path.write_text(source)
 path=root/'vllm'/BACKEND;source=path.read_text()
 old='                kvc[bid_t] = rec.view(nB, Hk, T)'
 if source.count(old)!=1:raise ValueError('Flush scatter site changed')
 source=source.replace(old,'                write_records(kvc, bid_t, rec.view(nB, Hk, T))')
 old='        return kv_cache[block_id, head]'
 if source.count(old)!=1:raise ValueError('CPU gather site changed')
 source=source.replace(old,'        return read_one(kv_cache, block_id, head)')
 tree=ast.parse(source)
 for node in ast.walk(tree):
  if isinstance(node,ast.FunctionDef) and node.name=='_write_packed':
   node.body+=ast.parse('write_tiles(kv_cache, torch.tensor([block_id * kv_cache.shape[1] + head], device=kv_cache.device, dtype=torch.int64), flat.view(1, -1))').body
 ast.fix_missing_locations(tree);source=ast.unparse(tree)+'\n'
 source='from kvbench_progressive_online.split_storage import write_records, write_tiles, read_one\n'+source if not source.startswith('from __future__') else source
 # Future imports must stay first; inject after future statements instead.
 tree=ast.parse(source)
 if any(isinstance(n,ast.ImportFrom) and n.module=='__future__' for n in tree.body):
  imp=tree.body.pop(0);idx=max(i for i,n in enumerate(tree.body) if isinstance(n,ast.ImportFrom) and n.module=='__future__')+1;tree.body.insert(idx,imp);source=ast.unparse(tree)+'\n'
 path.write_text(source)
 for rel in (DECODE,BACKEND):
  file=root/'vllm'/rel;text=file.read_text();m['executed_files_sha256'][rel]=sha_file(file);m['generated_sha256'][rel]=text_sha(text)
 m['transformed_source_sha256']=m['generated_sha256'][DECODE];m['executed_source_sha256']=m['executed_files_sha256'][DECODE]
 m['progressive']['global_split_storage']={'regions':FIELDS,'allocation':'Disjoint global plane views within one accounted allocation; no duplicate cache','consumer_load_counts':counts,'scope':'K4V4/G128/D128; APC off; no raw page relocation/swap support'}
 m['files_sha256']={str(p.relative_to(root)):sha_file(p) for p in sorted(root.rglob('*')) if p.is_file() and not p.is_symlink() and p.name!='runtime.json' and '__pycache__' not in p.parts}
 atomic_json(root/'runtime.json',m);verify(root,arm);return counts
