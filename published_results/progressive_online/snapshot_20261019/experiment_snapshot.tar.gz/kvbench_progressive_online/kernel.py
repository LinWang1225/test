# SPDX-License-Identifier: Apache-2.0
"""Triton snippets for genuine fused progressive decode (no Python per-token loop).

K and V code layout is high2|bit1|bit0, each plane a contiguous tile region.
The adaptive branch is heuristic: approximate, prefix-relative chunk mass and
query/scale RMS are NOT a certified output-error bound. There is intentionally
no predeclared byte budget; read-depth is selected anew per decode chunk.
"""

FULL = r'''
                # ProgKV high2 + bit1 + bit0; all K/V source bits read.
                s_row_K = tl.load(ku16 + (K_S_ROW_OFFSET // 2) + cols,
                                  mask=cmask, other=0).to(tl.float16, bitcast=True).to(tl.float32)
                s_row_V = tl.load(ku16 + (V_S_ROW_OFFSET // 2) + cols,
                                  mask=cmask, other=0).to(tl.float16, bitcast=True).to(tl.float32)
                zp_V = tl.load(ku16 + (V_ZP_OFFSET // 2) + cols,
                               mask=cmask, other=0).to(tl.float16, bitcast=True).to(tl.float32)
                tl.static_assert(K_BITS == 4 and V_BITS == 4)
                tl.static_assert(D % 8 == 0 and GROUP % 8 == 0)
                ar_skip_k = False
                ar_skip_v = False
                ar_eps = tl.zeros([Q_PER_KV_PAD], tl.float32)
                ar_count = tl.sum(cmask.to(tl.int32), axis=0)
                ar_k_hi_addr = tile_base + K_PACKED_OFFSET + d_offs[:, None] * (GROUP // 4) + cols[None, :] // 4
                ar_k_bit_addr = tile_base + K_PACKED_OFFSET + D * GROUP // 4 + d_offs[:, None] * (GROUP // 8) + cols[None, :] // 8
                ar_kh_b = tl.load(KV_cache_ptr + ar_k_hi_addr, mask=cmask[None, :], other=0).to(tl.int32)
                ar_k1_b = tl.load(KV_cache_ptr + ar_k_bit_addr, mask=cmask[None, :], other=0).to(tl.int32)
                ar_k0_b = tl.load(KV_cache_ptr + ar_k_bit_addr + D * GROUP // 8, mask=cmask[None, :], other=0).to(tl.int32)
                ar_kh = ((ar_kh_b >> (2 * (cols[None, :] % 4))) & 3).to(tl.float32)
                ar_k1 = ((ar_k1_b >> (cols[None, :] % 8)) & 1).to(tl.float32)
                ar_k0 = ((ar_k0_b >> (cols[None, :] % 8)) & 1).to(tl.float32)
                q_K = 4.0 * ar_kh + 2.0 * ar_k1 + ar_k0
                K_dg = (q_K * s_col_K[:, None] + zp_K[:, None]) * s_row_K[None, :]
                scores = tl.where(cmask[None, :], tl.dot(q, K_dg) * scale, -float('inf'))
                ar_v_hi_addr = tile_base + V_PACKED_OFFSET + cols[:, None] * (D // 4) + d_offs[None, :] // 4
                ar_v_bit_addr = tile_base + V_PACKED_OFFSET + D * GROUP // 4 + cols[:, None] * (D // 8) + d_offs[None, :] // 8
                ar_vh_b = tl.load(KV_cache_ptr + ar_v_hi_addr, mask=cmask[:, None], other=0).to(tl.int32)
                ar_v1_b = tl.load(KV_cache_ptr + ar_v_bit_addr, mask=cmask[:, None], other=0).to(tl.int32)
                ar_v0_b = tl.load(KV_cache_ptr + ar_v_bit_addr + D * GROUP // 8, mask=cmask[:, None], other=0).to(tl.int32)
                ar_vh = ((ar_vh_b >> (2 * (d_offs[None, :] % 4))) & 3).to(tl.float32)
                ar_v1 = ((ar_v1_b >> (d_offs[None, :] % 8)) & 1).to(tl.float32)
                ar_v0 = ((ar_v0_b >> (d_offs[None, :] % 8)) & 1).to(tl.float32)
                q_V = 4.0 * ar_vh + 2.0 * ar_v1 + ar_v0
                Vc = (q_V * s_row_V[:, None] + zp_V[:, None]) * s_col_V[None, :]
'''

# PROG_K_2 / PROG_K_3 / PROG_V_2 / PROG_V_3 are compile-time constants
# placed at the top of each JIT kernel by transform.py. K selection is
# score-independent, so the selected precision is known before the only
# formal K dot product.
ADAPTIVE = r'''
                s_row_K = tl.load(ku16 + (K_S_ROW_OFFSET // 2) + cols,
                                  mask=cmask, other=0).to(tl.float16, bitcast=True).to(tl.float32)
                s_row_V = tl.load(ku16 + (V_S_ROW_OFFSET // 2) + cols,
                                  mask=cmask, other=0).to(tl.float16, bitcast=True).to(tl.float32)
                zp_V = tl.load(ku16 + (V_ZP_OFFSET // 2) + cols,
                               mask=cmask, other=0).to(tl.float16, bitcast=True).to(tl.float32)
                tl.static_assert(K_BITS == 4 and V_BITS == 4)
                tl.static_assert(D % 8 == 0 and GROUP % 8 == 0)
                ar_skip_k = False
                ar_skip_v = False
                ar_eps = tl.zeros([Q_PER_KV_PAD], tl.float32)
                ar_count = tl.sum(cmask.to(tl.int32), axis=0)
                ar_k_hi_addr = tile_base + K_PACKED_OFFSET + d_offs[:, None] * (GROUP // 4) + cols[None, :] // 4
                ar_k_bit_addr = tile_base + K_PACKED_OFFSET + D * GROUP // 4 + d_offs[:, None] * (GROUP // 8) + cols[None, :] // 8
                ar_kh_b = tl.load(KV_cache_ptr + ar_k_hi_addr, mask=cmask[None, :], other=0).to(tl.int32)
                ar_kh = ((ar_kh_b >> (2 * (cols[None, :] % 4))) & 3).to(tl.float32)
                # Select K precision without a proxy attention dot. The
                # omitted low planes contribute at most 1.5 or 0.5 code units;
                # multiplying that range by query/scale sensitivity gives a
                # conservative score-error proxy for this chunk.
                ar_qscale = tl.abs(q.to(tl.float32)) * tl.abs(s_col_K[None, :])
                ar_k_sensitivity = tl.max(tl.sum(ar_qscale, axis=1), axis=0)
                ar_k_sensitivity = ar_k_sensitivity * tl.max(tl.abs(s_row_K), axis=0) * tl.abs(scale)
                ar_k_error_2 = 1.5 * ar_k_sensitivity
                ar_k_error_3 = 0.5 * ar_k_sensitivity
                if AR_RESIDUAL_ENABLED:
                    ar_meta_base = ((safe_bid * tl.num_programs(1) + hk) * 3)
                    # Metadata bounds K reconstruction, not QK score error.
                    ar_query_l1 = tl.max(tl.sum(tl.abs(q.to(tl.float32)), axis=1), axis=0)
                    ar_query_factor = ar_query_l1 * tl.abs(scale)
                    ar_k_error_2 = tl.load(AR_RESIDUAL_PTR + ar_meta_base).to(tl.float32) * ar_query_factor
                    ar_k_error_3 = tl.load(AR_RESIDUAL_PTR + ar_meta_base + 1).to(tl.float32) * ar_query_factor
                ar_k_depth_2 = ar_k_error_2 <= PROG_K_2
                ar_k_depth_3 = (~ar_k_depth_2) & (ar_k_error_3 <= PROG_K_3)
                if AR_REUSE_ENABLED and not VQ_INDIRECT:
                    # Each physical tile/head/subchunk has one writer with APC off.
                    # Validate against CURRENT errors even if ownership changed.
                    ar_reuse_base = (((safe_bid * tl.num_programs(1) + hk) * (GROUP // 16) + c0 // 16) * 5)
                    ar_old_step = tl.load(AR_REUSE_PTR + ar_reuse_base)
                    ar_old_depth = tl.load(AR_REUSE_PTR + ar_reuse_base + 1)
                    ar_old_bn = tl.load(AR_REUSE_PTR + ar_reuse_base + 2)
                    ar_old_first = tl.load(AR_REUSE_PTR + ar_reuse_base + 3)
                    ar_old_tokens = tl.load(AR_REUSE_PTR + ar_reuse_base + 4)
                    ar_first = tl.load(Block_table_ptr + bt_row * stride_bt_b)
                    ar_safe_depth = ((ar_old_depth == 4) |
                                     ((ar_old_depth == 2) & (ar_k_error_2 <= PROG_K_2)) |
                                     ((ar_old_depth == 3) & (ar_k_error_3 <= PROG_K_3)))
                    ar_reuse_ok = ((ar_old_step > 0) & (seq_len > ar_old_step) &
                                   (seq_len - ar_old_step < PROG_REUSE_STRIDE) &
                                   (ar_old_bn == BLOCK_N) & (ar_old_first == ar_first) &
                                   (ar_old_tokens == n_tok) & ar_safe_depth)
                    if ar_reuse_ok:
                        ar_k_depth_2 = ar_old_depth == 2
                        ar_k_depth_3 = ar_old_depth == 3
                    else:
                        ar_new_depth = tl.where(ar_k_depth_2, 2, tl.where(ar_k_depth_3, 3, 4))
                        tl.store(AR_REUSE_PTR + ar_reuse_base, seq_len)
                        tl.store(AR_REUSE_PTR + ar_reuse_base + 1, ar_new_depth)
                        tl.store(AR_REUSE_PTR + ar_reuse_base + 2, BLOCK_N)
                        tl.store(AR_REUSE_PTR + ar_reuse_base + 3, ar_first)
                        tl.store(AR_REUSE_PTR + ar_reuse_base + 4, n_tok)
                if ar_k_depth_2:
                    q_K = 4.0 * ar_kh + 1.5
                    ar_skip_k = True
                elif ar_k_depth_3:
                    ar_k1_b = tl.load(KV_cache_ptr + ar_k_bit_addr,
                                     mask=cmask[None, :], other=0).to(tl.int32)
                    ar_k1 = ((ar_k1_b >> (cols[None, :] % 8)) & 1).to(tl.float32)
                    q_K = 4.0 * ar_kh + 2.0 * ar_k1 + 0.5
                else:
                    ar_k1_b = tl.load(KV_cache_ptr + ar_k_bit_addr,
                                     mask=cmask[None, :], other=0).to(tl.int32)
                    ar_k1 = ((ar_k1_b >> (cols[None, :] % 8)) & 1).to(tl.float32)
                    ar_k0_b = tl.load(KV_cache_ptr + ar_k_bit_addr + D * GROUP // 8,
                                     mask=cmask[None, :], other=0).to(tl.int32)
                    ar_k0 = ((ar_k0_b >> (cols[None, :] % 8)) & 1).to(tl.float32)
                    q_K = 4.0 * ar_kh + 2.0 * ar_k1 + ar_k0
                K_dg = (q_K * s_col_K[:, None] + zp_K[:, None]) * s_row_K[None, :]
                # Exactly one formal K attention dot per chunk.
                scores = tl.where(cmask[None, :], tl.dot(q, K_dg) * scale, -float('inf'))
                # Value depth uses already-computed selected K logits. This is
                # an online, streaming estimation, NOT normalized full attention.
                ar_mass_v, _ = _ar_chunk_mass(scores, ar_eps, ar_prefix_lower, ar_count)
                ar_mass_v = tl.max(tl.where(qmask, ar_mass_v, 0.0), axis=0)
                ar_v_range = tl.maximum(tl.abs(zp_V), tl.abs(zp_V + 15.0 * s_row_V))
                ar_v_range = tl.max(tl.where(cmask, ar_v_range, 0.0), axis=0)
                ar_v_s = tl.max(tl.abs(s_row_V), axis=0)
                ar_v_ratio = tl.where(ar_v_range > 0, ar_v_s / tl.maximum(ar_v_range, 1.0e-30), 0.0)
                ar_v_hi_addr = tile_base + V_PACKED_OFFSET + cols[:, None] * (D // 4) + d_offs[None, :] // 4
                ar_v_bit_addr = tile_base + V_PACKED_OFFSET + D * GROUP // 4 + cols[:, None] * (D // 8) + d_offs[None, :] // 8
                ar_vh_b = tl.load(KV_cache_ptr + ar_v_hi_addr, mask=cmask[:, None], other=0).to(tl.int32)
                ar_vh = ((ar_vh_b >> (2 * (d_offs[None, :] % 4))) & 3).to(tl.float32)
                if ar_mass_v * (1.5 * ar_v_ratio) <= PROG_V_2:
                    q_V = 4.0 * ar_vh + 1.5
                    ar_skip_v = True
                else:
                    ar_v1_b = tl.load(KV_cache_ptr + ar_v_bit_addr,
                                     mask=cmask[:, None], other=0).to(tl.int32)
                    ar_v1 = ((ar_v1_b >> (d_offs[None, :] % 8)) & 1).to(tl.float32)
                    if ar_mass_v * (0.5 * ar_v_ratio) <= PROG_V_3:
                        q_V = 4.0 * ar_vh + 2.0 * ar_v1 + 0.5
                    else:
                        ar_v0_b = tl.load(KV_cache_ptr + ar_v_bit_addr + D * GROUP // 8,
                                         mask=cmask[:, None], other=0).to(tl.int32)
                        ar_v0 = ((ar_v0_b >> (d_offs[None, :] % 8)) & 1).to(tl.float32)
                        q_V = 4.0 * ar_vh + 2.0 * ar_v1 + ar_v0
                # Advance the single-pass prefix estimate AFTER this chunk.
                ar_unused, ar_prefix_lower = _ar_chunk_mass(scores, ar_eps, ar_prefix_lower, ar_count)
                Vc = (q_V * s_row_V[:, None] + zp_V[:, None]) * s_col_V[None, :]
'''
