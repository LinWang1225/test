"""Match operator timings, depth counts and profiler resources by input."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from kvbench_longcontext.common import atomic_json
from kvbench_residual_diag.common import write_csv


def attribute(path):
    events=json.loads(path.read_text())['traceEvents']
    labels=[e for e in events if e.get('cat')=='user_annotation' and e.get('ph')=='X']
    owners={}
    for e in events:
        if e.get('cat')=='kernel':continue
        corr=e.get('args',{}).get('correlation')
        if corr is None:continue
        parents=[a for a in labels if a.get('tid')==e.get('tid') and a['ts']<=e.get('ts',0)<a['ts']+a['dur']]
        if parents:owners[corr]=min(parents,key=lambda a:a['dur'])['name']
    rows=[]
    for e in events:
        if e.get('cat')!='kernel':continue
        args=e.get('args',{});owner=owners.get(args.get('correlation'))
        rows.append(dict(variant=owner,kernel=e['name'],duration_us=e['dur'],
            registers_per_thread=args.get('registers per thread'),shared_memory_bytes=args.get('shared memory'),
            grid=args.get('grid'),block=args.get('block')))
    return rows


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--run',type=Path,required=True)
    a=p.parse_args();root=a.run.resolve()
    if (root/'analysis.json').exists():
        raise FileExistsError('Analysis already exists; preserve the previous report')
    state=json.loads((root/'status.json').read_text())
    if state['status']!='completed':raise ValueError('Ablation is incomplete')
    timings=json.loads((root/'timings.json').read_text())
    counts={(r['trace'],r['mode'],r['variant']):r for r in json.loads((root/'depth_counts.json').read_text())}
    by_key={(r['trace'],r['mode'],r['variant']):r for r in timings}
    rows=[]
    for r in timings:
        baseline=by_key[(r['trace'],r['mode'],'fixed_k4v4')]
        c=counts[(r['trace'],r['mode'],r['variant'])]
        tokens=sum(c['key_tokens'].values())
        rows.append(dict(dataset=r['dataset'],trace=r['trace'],mode=r['mode'],variant=r['variant'],
            median_us=r['median_us'],min_us=r['min_us'],max_us=r['max_us'],
            slowdown_pct_vs_fixed44=100*(r['median_us']/baseline['median_us']-1),
            key_bits_mean=sum(int(k)*v for k,v in c['key_tokens'].items())/tokens,
            value_bits_mean=sum(int(k)*v for k,v in c['value_tokens'].items())/tokens,
            key_2bit_fraction=c['key_tokens']['2']/tokens,key_3bit_fraction=c['key_tokens']['3']/tokens,
            key_4bit_fraction=c['key_tokens']['4']/tokens,
            value_2bit_fraction=c['value_tokens']['2']/tokens,value_3bit_fraction=c['value_tokens']['3']/tokens,
            value_4bit_fraction=c['value_tokens']['4']/tokens,
            logical_code_reduction_fraction=c['logical_code_reduction_fraction'],
            output_relative_l2=r['output_relative_l2'],output_max_abs=r['output_max_abs']))
    resources={path.name:attribute(path) for path in root.glob('*.torch_trace.json')}
    summaries=[]
    for variant in dict.fromkeys(r['variant'] for r in rows):
        chosen=[r for r in rows if r['variant']==variant and r['mode']=='split']
        summaries.append(dict(variant=variant,trace_count=len(chosen),
            slowdown_pct_range=[min(r['slowdown_pct_vs_fixed44'] for r in chosen),max(r['slowdown_pct_vs_fixed44'] for r in chosen)],
            key_bits_mean_range=[min(r['key_bits_mean'] for r in chosen),max(r['key_bits_mean'] for r in chosen)],
            value_bits_mean_range=[min(r['value_bits_mean'] for r in chosen),max(r['value_bits_mean'] for r in chosen)],
            logical_code_reduction_range=[min(r['logical_code_reduction_fraction'] for r in chosen),max(r['logical_code_reduction_fraction'] for r in chosen)],
            attention_relative_l2_range=[min(r['output_relative_l2'] for r in chosen),max(r['output_relative_l2'] for r in chosen)]))
    atomic_json(root/'analysis.json',{'rows':rows,'split_summary':summaries,
        'scope':'Saved-input C1 operator ablation; fixed geometry; counts measured separately from timing',
        'limits':['Logical code bytes exclude scales, FP16 pools and metadata; not DRAM bytes',
                  'Relative attention error is not LongBench task quality',
                  'Register counts do not prove spills/occupancy bottlenecks',
                  'No extrapolation to C8 online TPOT or general hardware performance']})
    atomic_json(root/'kernel_resources.json',resources)
    write_csv(root/'analysis.csv',rows)
    print(json.dumps(summaries,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
