"""Diagnostic-only fixed-depth and K/V controller source variants.

Variants are generated outside verified runtimes, with separate hashes. Counters
are constexpr-disabled during timing. Bytes count logical packed addresses only.
"""
from __future__ import annotations
import ast
from .transform import _fn_rewrite


VARIANTS = {
    'fixed_k2v2': (2,2), 'fixed_k3v3': (3,3), 'fixed_k4v4': (4,4),
    'fixed_k2v4': (2,4), 'fixed_k3v4': (3,4),
    'fixed_k4v2': (4,2), 'fixed_k4v3': (4,3),
    'adaptive_k_v4': ('adaptive',4), 'k4_adaptive_v': (4,'adaptive'),
    'adaptive_kv': ('adaptive','adaptive'),
    'control_k4_v4': ('control',4), 'k4_control_v4': (4,'control'),
    'control_kv4': ('control','control'),
}


def _once(text, old, new):
    if text.count(old)!=1:raise ValueError('Ablation landmark mismatch: '+old[:80])
    return text.replace(old,new,1)


def _kernel(body, key, value):
    # Defaults keep all existing launch dictionaries compatible.
    body=_once(body,'    AR_STATS_PTR=None,\n',
        '    PG_DIAG_PTR=None,\n    PG_DIAG_ENABLED: tl.constexpr = False,\n    AR_STATS_PTR=None,\n')
    start=body.index('                # Select K precision without a proxy attention dot.')
    end=body.index('                if ar_k_depth_2:',start)
    if isinstance(key,int):
        body=body[:start]+(
            f'                ar_k_depth_2: tl.constexpr = {key==2!r}\n'
            f'                ar_k_depth_3: tl.constexpr = {key==3!r}\n')+body[end:]
    else:
        # No temporal reuse in controller attribution; remove its source entirely.
        reuse=body.index('                if AR_REUSE_ENABLED and not VQ_INDIRECT:',start)
        body=body[:reuse]+body[end:]
        if key=='control':
            for name in ('K_2','K_3'):
                import re
                body,n=re.subn(rf'(    PROG_{name}: tl.constexpr = )[^\n]+',r'\g<1>-1.0',body)
                if n!=1:raise ValueError('Missing K threshold')
    if isinstance(value,int):
        start=body.index('                # Value depth uses already-computed selected K logits.')
        end=body.index('                ar_v_hi_addr =',start)
        body=body[:start]+body[end:]
        body=_once(body,'if ar_mass_v * (1.5 * ar_v_ratio) <= PROG_V_2:',f'if {value==2!r}:')
        body=_once(body,'if ar_mass_v * (0.5 * ar_v_ratio) <= PROG_V_3:',f'if {value==3!r}:')
        body=_once(body,"                ar_unused, ar_prefix_lower = _ar_chunk_mass(scores, ar_eps, ar_prefix_lower, ar_count)", '')
        # Pool chunks need a prefix only for the online V mass proxy.
        body=_once(body,'\n                if True:\n                    ar_count =',
                   '\n                if False:\n                    ar_count =')
    elif value=='control':
        for name in ('V_2','V_3'):
            import re
            body,n=re.subn(rf'(    PROG_{name}: tl.constexpr = )[^\n]+',r'\g<1>-1.0',body)
            if n!=1:raise ValueError('Missing V threshold')
    for line,depth in [('                    q_V = 4.0 * ar_vh + 1.5',2),
                       ('                        q_V = 4.0 * ar_vh + 2.0 * ar_v1 + 0.5',3),
                       ('                        q_V = 4.0 * ar_vh + 2.0 * ar_v1 + ar_v0',4)]:
        indent=line[:len(line)-len(line.lstrip())]
        body=_once(body,line,line+f'\n{indent}pg_v_depth = {depth}')
    last='                Vc = (q_V * s_row_V[:, None] + zp_V[:, None]) * s_col_V[None, :]'
    counters='''
                if PG_DIAG_ENABLED:
                    pg_n = tl.sum(cmask.to(tl.int32), axis=0)
                    pg_k_depth = tl.where(ar_k_depth_2, 2, tl.where(ar_k_depth_3, 3, 4))
                    tl.atomic_add(PG_DIAG_PTR + pg_k_depth - 2, (pg_n > 0).to(tl.int64))
                    tl.atomic_add(PG_DIAG_PTR + 3 + pg_v_depth - 2, (pg_n > 0).to(tl.int64))
                    tl.atomic_add(PG_DIAG_PTR + 6 + pg_k_depth - 2, pg_n.to(tl.int64))
                    tl.atomic_add(PG_DIAG_PTR + 9 + pg_v_depth - 2, pg_n.to(tl.int64))
                    pg_k_bytes = D * ((pg_n + 3) // 4 + tl.where(pg_k_depth >= 3, (pg_n + 7) // 8, 0) + tl.where(pg_k_depth == 4, (pg_n + 7) // 8, 0))
                    pg_v_bytes = pg_n * D * pg_v_depth // 8
                    tl.atomic_add(PG_DIAG_PTR + 12, pg_k_bytes.to(tl.int64))
                    tl.atomic_add(PG_DIAG_PTR + 13, pg_v_bytes.to(tl.int64))
'''
    body=_once(body,last,last+counters.rstrip())
    return body


def generate(source, name):
    if name not in VARIANTS:raise ValueError('Unknown diagnostic variant')
    # No production dispatch receipt is claimed for a separately transformed file.
    marker='\n# AR-KV provenance hook:'
    if marker not in source:raise ValueError('Expected verified runtime source')
    source=source[:source.index(marker)]
    k,v=VARIANTS[name]
    generated=_fn_rewrite(source,{name:lambda s:_kernel(s,k,v) for name in (
        '_kvarn_fused_decode_kernel','_kvarn_fused_decode_stage1')})
    ast.parse(generated)
    return generated
