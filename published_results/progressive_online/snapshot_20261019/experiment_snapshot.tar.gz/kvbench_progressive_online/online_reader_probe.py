"""Small fixed-cap online reader experiment with raw client/server/GPU data."""
from __future__ import annotations
import argparse
import gzip
import json
import os
from pathlib import Path
from types import SimpleNamespace
import traceback

from kvbench_longcontext.common import atomic_json,checked_data,describe,read_jsonl,sha_file,write_jsonl
from kvbench_longcontext.run import metric_values
from kvbench_residual_diag.common import write_csv
from .run import DEFAULT_UPSTREAM,freeze_cases,_client_python,_gpu_idle,_run_logged,_start_server,_stop_server
from .runtime import build,verify
from .reader_tuning import retune_new_runtime


def freeze_probe(source,out):
    freeze_cases(source,out,['qasper','hotpotqa'],8)
    manifest=json.loads((out/'manifest.json').read_text())
    manifest.update(generation_budget_policy='fixed',max_tokens_transport='explicit-positive-integer')
    manifest['settings'].update(generation_budget_policy='fixed',max_new_tokens=128)
    manifest['protocol']='Reader performance diagnostic, greedy, fixed cap 128; not natural-generation quality scoring'
    for name,info in manifest['datasets'].items():
        rows=read_jsonl(out/info['file'])
        for row in rows:
            row.update(max_tokens=128,generation_budget_policy='fixed',generation_budget_tokens=128)
        write_jsonl(out/info['file'],rows)
        info.update(sha256=sha_file(out/info['file']),max_tokens=128,generation_budget_policy='fixed',
            generation_budget_tokens=describe([128]*len(rows)),
            input_tokens=describe([r['input_tokens'] for r in rows]),
            remaining_context_tokens=describe([r['remaining_context_tokens'] for r in rows]))
    atomic_json(out/'manifest.json',manifest);checked_data(out)


def analyze_point(folder):
    perf=json.loads((folder/'performance.summary.json').read_text())
    before=(folder/'metrics.before.txt').read_text();after=(folder/'metrics.after.txt').read_text()
    result={k:perf.get(k) for k in ('dataset','repeat','concurrency','measurement_complete','valid_responses',
        'request_window_s','output_tokens_per_s','ttft_s','tpot_s','e2e_s','completion_tokens','length_capped',
        'preemptions_delta','native_kv_capacity_tokens','prompt_tokens')}
    server={}
    for name in ('request_queue_time_seconds','request_prefill_time_seconds','request_decode_time_seconds',
                 'request_inference_time_seconds','request_time_per_output_token_seconds'):
        bcount,acount=metric_values(before,name+'_count'),metric_values(after,name+'_count')
        bsum,asum=metric_values(before,name+'_sum'),metric_values(after,name+'_sum')
        count=sum(acount)-sum(bcount) if acount and bcount else None
        total=sum(asum)-sum(bsum) if asum and bsum else None
        server[name]={'count_delta':count,'sum_delta_s':total,
                      'mean_s':total/count if count and count>0 and total is not None and total>=0 else None,
                      'count_matches_requests':count==perf['expected_tasks']}
    gpu=[];queue=[]
    for sample in read_jsonl(folder/'telemetry.jsonl'):
        queue.append({'unix_time':sample['unix_time'],'running':sample.get('num_requests_running'),
                      'waiting':sample.get('num_requests_waiting'),'kv_usage':sample.get('kv_usage_fraction')})
        raw=sample.get('gpu',{})
        if raw.get('returncode')!=0:continue
        fields=raw['stdout'].split(',')
        try:values=list(map(lambda s:float(s.strip()),fields[:7]))
        except (ValueError,IndexError):continue
        if len(values)!=7:continue
        gpu.append(dict(unix_time=sample['unix_time'],memory_mib=values[0],utilization_pct=values[1],
            power_w=values[2],temperature_c=values[3],sm_clock_mhz=values[4],memory_clock_mhz=values[5],
            memory_utilization_pct=values[6],pstate=fields[7].strip() if len(fields)>7 else None))
    energy=sum((b['unix_time']-a['unix_time'])*(a['power_w']+b['power_w'])/2 for a,b in zip(gpu,gpu[1:])) if len(gpu)>1 else None
    result.update(server_histogram_deltas=server,gpu_samples=len(gpu),
        gpu_sampled_span_s=gpu[-1]['unix_time']-gpu[0]['unix_time'] if len(gpu)>1 else None,
        gpu_energy_j_est_over_sampled_span=energy,
        gpu_statistics={name:describe([r[name] for r in gpu]) for name in (
            'memory_mib','utilization_pct','power_w','temperature_c','sm_clock_mhz','memory_clock_mhz','memory_utilization_pct')},
        dram_bytes=None)
    gaps=[]
    for request in read_jsonl(folder/'requests.jsonl'):
        with gzip.open(folder/request['raw_chunks_file'],'rt') as f:chunks=json.load(f)
        times=[]
        for chunk in chunks:
            choices=chunk.get('data',{}).get('choices',[])
            if any(c.get('text') or any(c.get('delta',{}).get(k) for k in ('content','reasoning_content','reasoning')) for c in choices):
                times.append(chunk['elapsed_s'])
        delta=[b-a for a,b in zip(times,times[1:])]
        gaps.append(dict(case_id=request['case_id'],content_chunk_count=len(times),gap_s=describe(delta)))
    result['sse_chunk_gaps']=gaps
    result['metric_limits']='SSE chunks can bundle tokens. GPU energy covers sampled span only. Memory utilization is activity, not DRAM bytes. Histograms are per-request server observations; do not add them to client TPOT.'
    atomic_json(folder/'online.analysis.json',result)
    atomic_json(folder/'gpu.samples.json',gpu);atomic_json(folder/'queue.samples.json',queue)
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--batch',type=Path,required=True)
    p.add_argument('--upstream-suite',type=Path,default=Path(DEFAULT_UPSTREAM))
    a=p.parse_args();root=a.batch.resolve()
    if (root/'online_status.json').exists():raise ValueError('Online batch already exists; no resume/overwrite')
    state={'status':'running','phase':'preparing','arms':{name:'pending' for name in ('planar_default','planar_tuned','native_tuned')}}
    atomic_json(root/'online_status.json',state)
    try:
        _gpu_idle('0')
        selected=json.loads((root/'tuning/selection.json').read_text())['configs']
        if json.loads((root/'tuning/status.json').read_text())['status']!='completed':raise ValueError('Tuning incomplete')
        cfg=json.loads(a.upstream_suite.read_text())['settings']
        if Path(os.sys.prefix).name!=cfg['server_env']:raise ValueError('Use original kvarn-serve environment')
        freeze_probe(Path(cfg['data']),root/'data')
        client=_client_python(cfg)
        args=SimpleNamespace(model=Path(cfg['model']),max_model_len=cfg['max_model_len'],max_seqs=cfg['max_seqs'],
            batch_tokens=cfg['batch_tokens'],server_seed=cfg['server_seed'],port=18183,gpu='0',gpu_util=.85,
            startup_timeout=1800,eager=False,repo=Path(__file__).resolve().parents[1])
        plan={'schema':'kvbench.reader_online.v1','arms':list(state['arms']),'selected_configs':selected,
              'tasks':['qasper','hotpotqa'],'count_each':8,'concurrency':[1,8],'repeats':2,
              'max_tokens':128,'sampling':'greedy; thinking true; frozen original prompts',
              'measured_requests':192,'data_manifest_sha256':sha_file(root/'data/manifest.json'),
              'sample_interval_s':1,'raw_prometheus_samples':True,
              'quality_scope':'performance diagnostic; truncated outputs not used as LongBench quality scores',
              'dram_status':'GPU counters previously denied; no physical byte measurement',
              'online_precision':'All arms read full K4V4. Only layout and kernel configuration differ.'}
        atomic_json(root/'online_plan.json',plan)
        env=os.environ.copy();env.pop('PYTHONHOME',None);env.pop('PYTHONPATH',None)
        env.update(PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',KVARN_FAST_FLUSH='1')
        results=[]
        for label in state['arms']:
            arm='parent' if label=='native_tuned' else 'p211_full'
            state.update(phase=label);state['arms'][label]='building';atomic_json(root/'online_status.json',state)
            runtime=root/'online_runtimes'/label
            build(runtime,arm)
            if label!='planar_default':retune_new_runtime(runtime,arm,selected['native' if arm=='parent' else 'planar_full'])
            verify(runtime,arm)
            proc=log=None
            try:
                state['arms'][label]='starting_server';atomic_json(root/'online_status.json',state)
                proc,log,manifest=_start_server(args,arm,runtime,root/'servers'/label,root/'logs'/(label+'.server.log'),env)
                launch=json.loads(manifest.read_text());launch['config']['method']=label
                launch['reader_experiment']={'label':label,'kernel_configs':None if label=='planar_default' else selected['native' if arm=='parent' else 'planar_full']}
                current_manifest=root/'servers'/label/'reader.launch.json';atomic_json(current_manifest,launch)
                state['arms'][label]='measuring';atomic_json(root/'online_status.json',state)
                command=['-m','kvbench_longcontext.run','--data-dir',root/'data','--out',root/'online_runs'/label,
                    '--server-manifest',current_manifest,'--concurrency','1','8','--repeats','2',
                    '--temperature','0','--top-p','1','--top-k','-1','--min-p','0','--seed',str(cfg['request_seed']),
                    '--request-timeout','300','--warmup','1','--warmup-per-point','2','--gpu','0',
                    '--sample-interval','1','--save-metrics-samples']
                rc=_run_logged(client,command,root/'logs'/(label+'.client.log'),env,args.repo)
                if rc:raise RuntimeError(label+' measurement failed; see client log')
            finally:
                try:_stop_server(proc)
                finally:
                    if log is not None:log.close()
            for summary in sorted((root/'online_runs'/label).glob('r*/performance.summary.json')):
                r=analyze_point(summary.parent)
                if not r['measurement_complete']:raise RuntimeError('Incomplete online point: '+str(summary))
                results.append(dict(arm=label,point=summary.parent.name,**r))
            state['arms'][label]='completed';atomic_json(root/'online_status.json',state)
            atomic_json(root/'online_comparison.json',results)
        write_csv(root/'online_comparison.csv',[dict(arm=r['arm'],point=r['point'],dataset=r['dataset'],
            repeat=r['repeat'],concurrency=r['concurrency'],tpot_ms=r['tpot_s']['mean']*1000,
            tpot_p95_ms=r['tpot_s']['p95']*1000,ttft_ms=r['ttft_s']['mean']*1000,
            output_tokens_per_s=r['output_tokens_per_s'],completion_tokens_mean=r['completion_tokens']['mean'],
            energy_sampled_j=r['gpu_energy_j_est_over_sampled_span'],preemptions=r['preemptions_delta']) for r in results])
        state.update(status='completed',phase='completed');atomic_json(root/'online_status.json',state)
    except BaseException as exc:
        state.update(status='failed',error=repr(exc),traceback=traceback.format_exc());atomic_json(root/'online_status.json',state);raise


if __name__=='__main__':main()
