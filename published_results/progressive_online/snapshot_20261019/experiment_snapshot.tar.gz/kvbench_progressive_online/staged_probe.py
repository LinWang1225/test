"""Gated writer fusion and shape-matched reader experiments. Never resumes outputs."""
from __future__ import annotations
import argparse
import copy
from datetime import datetime
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time
import traceback

import torch
from kvbench_longcontext.common import atomic_json
from kvbench_residual_diag.common import load_trace, trace_paths, write_csv
from .codec import pack_211_torch
from .fused_writer import pack
from .fused_runtime import install
from .profile_components import measure
from .residual_metadata import torch_residual_bounds_from_quantized
from .runtime import build
from .run_ablation import prepare, load_file, fixed_oracle
from .validate_reuse import load_module
from .transform import DECODE
from .ablation import generate


def worker(out, runtime):
    from vllm.v1.attention.backends import kvarn_attn as backend
    from .validate_metadata import worker as validate
    original = backend.KVarNAttentionImpl._batched_flush
    calls = []
    def observed(items):
        with torch.profiler.record_function('actual_fast_flush'):
            original(items)
        calls.append(len(items))
    backend.KVarNAttentionImpl._batched_flush = staticmethod(observed)
    # Only labelled actual_fast_flush ranges represent the writer; independent
    # validation/oracle work elsewhere in this timeline must be excluded.
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                           torch.profiler.ProfilerActivity.CUDA]) as prof:
        validate(out, runtime)
    prof.export_chrome_trace(str(out/'actual_flush.trace.json'))
    atomic_json(out/'profile_scope.json', {'label': 'actual_fast_flush', 'calls_items': calls,
        'scope': 'Actual backend contract workload, 2 pages x 8 heads; profiler includes independent oracle outside labelled ranges',
        'not_online': True, 'dram_bytes': None})


def writer_probe(out):
    rows=[];checks=[]
    for tiles in (1, 8, 64, 256):
        for dtype in (torch.uint8, torch.int32):
            q=torch.randint(0,16,(tiles,128,128),device='cuda',dtype=dtype)
            c=torch.randn(tiles,128,device='cuda',dtype=torch.float16)
            r=torch.randn_like(c)
            for revision in range(3):
                if revision==1:q.zero_()
                if revision==2:q.fill_(15);c.zero_()
                p,e=pack(q,c,r)
                expected=pack_211_torch(q)
                torch.testing.assert_close(p,expected,rtol=0,atol=0)
                reference=torch_residual_bounds_from_quantized(expected,c,r,packing='planes_211')
                torch.testing.assert_close(e,reference,rtol=2e-6,atol=1e-7)
                checks.append(dict(tiles=tiles,dtype=str(dtype),revision=revision,max_error=float((e-reference).abs().max())))
            q.random_(0,16);c.normal_()
            def baseline():
                p=pack_211_torch(q)
                return p,torch_residual_bounds_from_quantized(p,c,r,packing='planes_211')
            operations={'torch_pack':lambda:pack_211_torch(q), 'fused_pack':lambda:pack(q),
                        'torch_pack_metadata':baseline,'fused_pack_metadata':lambda:pack(q,c,r)}
            for name,fn in operations.items():
                fn();torch.cuda.synchronize()
                graph=torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):result=fn()
                # Keep captured outputs alive through graph replay.
                graph.replay();torch.cuda.synchronize()
                start=time.perf_counter()
                for _ in range(20):fn()
                cpu_enqueue=(time.perf_counter()-start)*1e6/20
                torch.cuda.synchronize()
                rows.append(dict(tiles=tiles,dtype=str(dtype),operation=name,cpu_enqueue_us=cpu_enqueue,
                    eager=measure(fn,10,5),graph=measure(graph.replay,20,5)))
            with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,
                                                   torch.profiler.ProfilerActivity.CUDA]) as prof:
                for name,fn in operations.items():
                    with torch.profiler.record_function(name):fn()
                torch.cuda.synchronize()
            prof.export_chrome_trace(str(out/f'writer_{tiles}_{str(dtype).split(".")[-1]}.trace.json'))
            atomic_json(out/'writer_timings.json',rows)
    atomic_json(out/'writer_checks.json',checks)


def reader_probe(out,traces,adaptive,parent):
    source=(adaptive/'vllm'/DECODE).read_text()
    modules={'native':load_module(parent,'staged_native')}
    variants=out/'variants';variants.mkdir()
    for name in ('fixed_k4v4','fixed_k4v2','fixed_k2v2'):
        path=variants/(name+'.py');path.write_text(generate(source,name))
        modules[name]=load_file(path,'staged_'+name)
    # Verify approximate kernels against independent real-arithmetic attention.
    from kvbench_residual.fixtures import Case, build_case
    fixture=build_case(Case('staged_reader_contract',(385,),hq=32,hk=8))
    fixture_replay=prepare(fixture,32)
    for name,k,v in (('fixed_k4v4',4,4),('fixed_k4v2',4,2),('fixed_k2v2',2,2)):
        actual=fixture_replay.launch(modules[name],'split').cpu().numpy().reshape(1,32,128)
        import numpy as np
        np.testing.assert_allclose(actual,fixed_oracle(fixture,k,v),rtol=.02,atol=.002)
    rows=[]
    for path in trace_paths(traces,3):
        original,meta=load_trace(path)
        for batch in (1,8):
            data=copy.copy(original)
            # Replicated query/context isolates batch geometry, NOT a real C8
            # serving trace. KV cache is shared; report this cache locality bias.
            for key in ('query','seq_lens','block_table'):
                data[key]=original[key].repeat(batch,axis=0)
            import numpy as np
            data['req_rows']=np.arange(batch,dtype=np.int32)
            from dataclasses import replace
            data['case']=replace(original['case'],seq_lens=tuple(int(x) for x in data['seq_lens']))
            replay=prepare(data,32);g=replay.gpu
            g.splits=32
            g.mid_o=torch.zeros((batch*g.hq,32,g.d),device='cuda',dtype=torch.float32)
            g.mid_lse=torch.full((batch*g.hq,32),-float('inf'),device='cuda')
            for block_n in (16,32,64):
                g.block_n=block_n;g.num_warps=4;g.num_stages=1
                graphs={};outputs={}
                for name,module in modules.items():
                    replay.launch(module,'split');torch.cuda.synchronize()
                    graph=torch.cuda.CUDAGraph()
                    with torch.cuda.graph(graph):replay.launch(module,'split')
                    graph.replay();torch.cuda.synchronize()
                    outputs[name]=g.out.clone();graphs[name]=graph
                torch.testing.assert_close(outputs['fixed_k4v4'],outputs['native'],rtol=.002,atol=.002)
                values={name:[] for name in modules};names=list(modules)
                for round_index in range(3):
                    for name in names[round_index:]+names[:round_index]:
                        values[name].append(measure(graphs[name].replay,30,5)['median_us'])
                for name,values_us in values.items():
                    diff=(outputs[name]-outputs['native']).float()
                    rows.append(dict(trace=path.name,dataset=meta['request']['dataset'],batch=batch,splits=32,
                        block_n=block_n,warps=4,stages=1,variant=name,median_us=statistics.median(values_us),
                        round_medians_us=values_us,relative_l2=float(diff.norm()/outputs['native'].float().norm().clamp_min(1e-12))))
                atomic_json(out/'reader_timings.json',rows)
    write_csv(out/'reader_timings.csv',rows)
    # Compare best native and best candidate tile separately for each shape.
    comparisons=[]
    for path in trace_paths(traces,3):
        for batch in (1,8):
            subset=[r for r in rows if r['trace']==path.name and r['batch']==batch]
            native=min(r['median_us'] for r in subset if r['variant']=='native')
            for name in modules:
                best=min((r for r in subset if r['variant']==name),key=lambda r:r['median_us'])
                comparisons.append(dict(trace=path.name,batch=batch,variant=name,best_block_n=best['block_n'],
                    median_us=best['median_us'],speedup_vs_best_native=native/best['median_us']))
    atomic_json(out/'reader_comparison.json',comparisons)
    winners=[name for name in ('fixed_k4v2','fixed_k2v2')
             if all(r['speedup_vs_best_native']>=1.10 for r in comparisons if r['variant']==name)]
    decision={'minimum_speedup_gate':1.10,'qualifying_variants':winners,
        'dynamic_control':'eligible_for_next_validation' if winners else 'deferred_no_consistent_10pct_headroom',
        'limitations':['B8 is replicated real B1 input sharing KV, not heterogeneous online C8',
                      'Graph timing excludes counters; no DRAM measurement',
                      'Independent approximate correctness gate uses small fixture; no task-quality guarantee',
                      '10% is a prespecified engineering margin, not a statistical confidence bound']}
    atomic_json(out/'reader_decision.json',decision)
    return decision


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--worker-runtime',type=Path)
    p.add_argument('--traces',type=Path)
    a=p.parse_args();out=a.out.resolve();out.mkdir(parents=True,exist_ok=False)
    atomic_json(out/'status.json',{'status':'running','phase':'preflight','pid':os.getpid()})
    try:
        if a.worker_runtime:
            worker(out,a.worker_runtime.resolve());return
        from .run import _gpu_idle
        _gpu_idle('0')
        atomic_json(out/'plan.json',{'started':datetime.now().isoformat(),'python':sys.executable,
            'gpu':torch.cuda.get_device_name(),'torch':torch.__version__,
            'phases':['actual backend timeline and correctness','pack/metadata fusion','fixed readers S32 B1/B8',
                      'dynamic control gated by fixed-reader headroom'],
            'no_overwrite':True,'online_followup':'Only after writer and reader gates; not launched by this operator probe',
            'dram_bytes':None})
        runtimes={}
        for label in ('original','fused'):
            runtime=out/('runtime_'+label);build(runtime,'p211_adaptive')
            if label=='fused':install(runtime,'p211_adaptive')
            runtimes[label]=runtime
            env=os.environ.copy();env['PYTHONPATH']=str(runtime)+os.pathsep+str(Path.cwd())
            env['PYTHONNOUSERSITE']='1'
            command=[sys.executable,'-m',__package__+'.staged_probe','--out',str(out/('flush_'+label)),
                     '--worker-runtime',str(runtime)]
            with (out/(label+'.worker.log')).open('x') as log:
                subprocess.run(command,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
        atomic_json(out/'status.json',{'status':'running','phase':'writer_fusion_measurement','pid':os.getpid()})
        writer_probe(out)
        parent=out/'runtime_native';build(parent,'parent')
        atomic_json(out/'status.json',{'status':'running','phase':'reader_shapes','pid':os.getpid()})
        decision=reader_probe(out,a.traces,runtimes['original'],parent)
        atomic_json(out/'status.json',{'status':'completed','phase':'operator_gates_complete','decision':decision,
            'pending':['online fully warmed writer comparison and heterogeneous C8 timeline',
                       'dynamic controller only if performance gate passes'], 'finished':datetime.now().isoformat()})
    except BaseException as exc:
        atomic_json(out/'status.json',{'status':'failed','error':repr(exc)})
        traceback.print_exc();raise


if __name__=='__main__':main()
