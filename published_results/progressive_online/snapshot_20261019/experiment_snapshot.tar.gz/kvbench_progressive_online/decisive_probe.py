"""Fixed-length Latin-square deployment experiment with a prefill-free overlap window."""
import argparse,gzip,json,os,statistics,sys,traceback
from pathlib import Path
from datetime import datetime
from types import SimpleNamespace
from kvbench_longcontext.common import atomic_json,read_jsonl,write_jsonl,sha_file,describe,checked_data

def client():
 from kvbench_longcontext import run
 original=run.make_request
 def fixed(*args,**kwargs):
  request=original(*args,**kwargs)
  request.update(ignore_eos=True,min_tokens=request['max_tokens'])
  return request
 run.make_request=fixed
 sys.argv=[sys.argv[0],*sys.argv[sys.argv.index('--client')+1:]]
 run.main()

def overlap(folder,tokens):
 records=read_jsonl(folder/'requests.jsonl');series=[]
 for r in records:
  if r['completion_tokens']!=tokens:raise ValueError('Exact token budget not met')
  with gzip.open(folder/r['raw_chunks_file'],'rt') as f:chunks=json.load(f)
  times=[]
  for c in chunks:
   if any(x.get('text') or any(x.get('delta',{}).get(k) for k in ('content','reasoning_content','reasoning')) for x in c.get('data',{}).get('choices',[])):
    times.append(r['started_unix_time']+c['elapsed_s'])
  series.append(times)
 # Request start time field is checked against actual records by the caller.
 start=max(x[0] for x in series);end=min(x[-1] for x in series)
 gaps=[];counts=[]
 for times in series:
  local=[b-a for a,b in zip(times,times[1:]) if a>=start and b<=end]
  counts.append(len(local));gaps.extend(local)
 return {'all_requests_started_content_unix':start,'first_request_last_content_unix':end,'duration_s':max(0,end-start),'intervals_each_request':counts,'chunk_counts':[len(x) for x in series],'one_content_chunk_per_native_token':all(len(x)==tokens for x in series),'mean_chunk_gap_s':statistics.mean(gaps) if gaps else None,'p50_chunk_gap_s':statistics.median(gaps) if gaps else None,'valid_overlap':end>start and min(counts)>=128 and all(len(x)==tokens for x in series),'limits':'SSE chunk timing is not a GPU event timer. Native token equivalence only when one chunk per token. Last content time bounds overlap conservatively.'}

def gate(root):
 # Verify the exact metadata-free online source, not just the prior diagnostic module.
 import numpy as np
 import torch
 from .validate_reuse import Replay,load_module
 from .run_ablation import fixed_oracle
 from kvbench_residual.fixtures import Case,build_case
 fixture=build_case(Case('decisive_exact_source',(385,),hq=32,hk=8));replay=Replay(fixture,32)
 module=load_module((root/'runtimes/fused_k2v2'),'decisive_fixed_gate');oracle=fixed_oracle(fixture,2,2)
 for mode in ('single','split'):
  actual=replay.launch(module,mode).cpu().numpy().reshape(1,32,128)
  np.testing.assert_allclose(actual,oracle,rtol=.02,atol=.002)
  graph=torch.cuda.CUDAGraph()
  with torch.cuda.graph(graph):replay.launch(module,mode)
  graph.replay();torch.cuda.synchronize()
  np.testing.assert_allclose(replay.gpu.out.cpu().numpy().reshape(1,32,128),oracle,rtol=.02,atol=.002)
 atomic_json(root/'fixed_source_gate.json',{'status':'completed','checks':['Exact metadata-free online source vs independent float64 K2V2 oracle','single/split eager and CUDA Graph'],'source_sha256':sha_file((root/'runtimes/fused_k2v2')/'vllm/v1/attention/ops/triton_kvarn_decode.py')})
 del replay,module,graph;torch.cuda.empty_cache()

def main():
 if '--client' in sys.argv:client();return
 if '--gate' in sys.argv:gate(Path(sys.argv[sys.argv.index('--gate')+1]));return
 from . import runtime
 from .autonomous_next import fixed_online_source
 from .fused_runtime import install
 from .run import DEFAULT_UPSTREAM,_gpu_idle,_start_server,_stop_server,_run_logged,_client_python
 from .online_reader_probe import freeze_probe,analyze_point
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--tokens',type=int,default=1024);a=p.parse_args();root=a.out.resolve();root.mkdir(parents=True,exist_ok=False)
 state={'status':'running','phase':'preflight','pid':os.getpid(),'started':datetime.now().isoformat()};atomic_json(root/'status.json',state)
 try:
  _gpu_idle('0');cfg=json.loads(Path(DEFAULT_UPSTREAM).read_text())['settings'];freeze_probe(Path(cfg['data']),root/'data')
  manifest=json.loads((root/'data/manifest.json').read_text());manifest['settings']['max_new_tokens']=a.tokens
  for info in manifest['datasets'].values():
   rows=read_jsonl(root/'data'/info['file'])
   if any(r['remaining_context_tokens']<a.tokens for r in rows):raise ValueError('Insufficient context for fixed length')
   for r in rows:r.update(max_tokens=a.tokens,generation_budget_tokens=a.tokens)
   write_jsonl(root/'data'/info['file'],rows);info.update(sha256=sha_file(root/'data'/info['file']),max_tokens=a.tokens,generation_budget_tokens=describe([a.tokens]*len(rows)))
  atomic_json(root/'data/manifest.json',manifest);checked_data(root/'data')
  order=[['native','fused_full','fused_k2v2'],['fused_full','fused_k2v2','native'],['fused_k2v2','native','fused_full']]
  atomic_json(root/'plan.json',{'order':order,'concurrency':[1,8],'datasets':['qasper','hotpotqa'],'count_each':8,'tokens':a.tokens,'generation':'greedy, ignore_eos=true, min_tokens=max_tokens; diagnostic only','runtime':'native defaults; both planar arms use identical full writer without adaptive metadata; default autotune grids','steady_decode':'all first content received to earliest last content; at least128 content intervals per request; per-request prefill/decode histograms also retained','gate':'all four dataset/concurrency cells median overlap speedup>=1.10 and at least2/3 rounds improve; no median overall TPOT regression; otherwise no-go or inconclusive if overlap invalid','limits':['No quality claim under forced generation','No physical DRAM measurement','C1 and C8 measured separately','Common overlap excludes prompt prefill but includes decode writer, scheduling and HTTP','No profiler during measurements']})
  env=dict(os.environ,NO_PROXY='localhost,127.0.0.1,::1',no_proxy='localhost,127.0.0.1,::1',PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',KVARN_FAST_FLUSH='1')
  for k in ['PYTHONPATH','PYTHONHOME','KVBENCH_PROFILE_DIR']:env.pop(k,None)
  roots={};original=runtime.transform_dequant
  for label in order[0]:
   arm='parent' if label=='native' else 'p211_full';rt=root/'runtimes'/label
   if label=='fused_k2v2':runtime.transform_dequant=lambda s,arm,thresholds:fixed_online_source(original(s,'p211_adaptive',thresholds)).replace('    AR_RESIDUAL_PTR,\n','    AR_RESIDUAL_PTR=None,\n')
   try:runtime.build(rt,arm)
   finally:runtime.transform_dequant=original
   if arm!='parent':install(rt,arm)
   runtime.verify(rt,arm);roots[label]=rt
   atomic_json(root/(label+'.variant.json'),{'arm':arm,'variant':label,'metadata_control':False,'decode_source_sha256':sha_file(rt/'vllm/v1/attention/ops/triton_kvarn_decode.py')})
  if _run_logged(sys.executable,['-m','kvbench_progressive_online.decisive_probe','--gate',root],root/'logs/fixed_gate.log',env,Path.cwd()):raise RuntimeError('Exact online source correctness gate failed')
  args=SimpleNamespace(model=Path(cfg['model']),max_model_len=cfg['max_model_len'],max_seqs=cfg['max_seqs'],batch_tokens=cfg['batch_tokens'],server_seed=cfg['server_seed'],port=18192,gpu='0',gpu_util=.85,startup_timeout=1800,eager=False,repo=Path(__file__).resolve().parents[1])
  results=[]
  for rnd,labels in enumerate(order,1):
   for label in labels:
    session=f'r{rnd}_{label}';state.update(phase=session);atomic_json(root/'status.json',state);proc=log=None
    try:
     arm='parent' if label=='native' else 'p211_full'
     proc,log,launch=_start_server(args,arm,roots[label],root/'servers'/session,root/'logs'/(session+'.server.log'),env)
     command=['-m','kvbench_progressive_online.decisive_probe','--client','--data-dir',root/'data','--out',root/'runs'/session,'--server-manifest',launch,'--concurrency','1','8','--repeats','1','--temperature','0','--top-p','1','--top-k','-1','--min-p','0','--seed',str(cfg['request_seed']),'--request-timeout','1800','--warmup','1','--warmup-per-point','8','--gpu','0','--sample-interval','1','--save-metrics-samples']
     if _run_logged(_client_python(cfg),command,root/'logs'/(session+'.client.log'),env,args.repo):raise RuntimeError('Client failure '+session)
     for path in sorted((root/'runs'/session).glob('r*/performance.summary.json')):
      r=analyze_point(path.parent)
      if not r['measurement_complete'] or r['valid_responses']!=8:raise ValueError('Incomplete measurement')
      window=overlap(path.parent,a.tokens) if r['concurrency']==8 else None
      if r['concurrency']==1:
       # C1 requests execute sequentially: aggregate their own post-first-content decode.
       window={'valid_overlap':True,'mean_chunk_gap_s':r['tpot_s']['mean'],'limits':'C1 mean request TPOT; no concurrent prefill from other requests'}
      results.append(dict(arm=label,round=rnd,**r,decode_window=window));atomic_json(root/'measurements.json',results)
    finally:
     try:_stop_server(proc)
     finally:
      if log:log.close()
  comparisons=[]
  for dataset in ('qasper','hotpotqa'):
   for c in (1,8):
    for label in ('fused_full','fused_k2v2'):
     paired=[]
     for rnd in (1,2,3):
      base=next(r for r in results if r['arm']=='native' and r['round']==rnd and r['dataset']==dataset and r['concurrency']==c)
      other=next(r for r in results if r['arm']==label and r['round']==rnd and r['dataset']==dataset and r['concurrency']==c)
      valid=base['decode_window']['valid_overlap'] and other['decode_window']['valid_overlap']
      paired.append({'round':rnd,'valid':valid,'decode_speedup':base['decode_window']['mean_chunk_gap_s']/other['decode_window']['mean_chunk_gap_s'] if valid else None,'tpot_ratio':other['tpot_s']['mean']/base['tpot_s']['mean']})
     valid=all(r['valid'] for r in paired);speed=statistics.median(r['decode_speedup'] for r in paired) if valid else None
     comparisons.append(dict(dataset=dataset,concurrency=c,arm=label,rounds=paired,median_decode_speedup=speed,passes=bool(valid and speed>=1.10 and sum(r['decode_speedup']>1 for r in paired)>=2 and statistics.median(r['tpot_ratio'] for r in paired)<=1)))
  fixed=[r for r in comparisons if r['arm']=='fused_k2v2']
  decision='go' if all(r['passes'] for r in fixed) else 'inconclusive' if any(not all(x['valid'] for x in r['rounds']) for r in fixed) else 'no_go_current_implementation'
  atomic_json(root/'decision.json',{'decision':decision,'comparisons':comparisons,'note':'Four dataset/concurrency cells; engineering threshold, not statistical confidence guarantee'})
  state.update(status='completed',phase='finished',decision=decision,finished=datetime.now().isoformat());atomic_json(root/'status.json',state)
 except BaseException as e:
  state.update(status='failed',error=repr(e),traceback=traceback.format_exc());atomic_json(root/'status.json',state);raise

if __name__=='__main__':main()
