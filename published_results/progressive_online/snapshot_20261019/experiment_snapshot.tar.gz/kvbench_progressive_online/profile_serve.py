"""Private experiment launcher enabling explicit, separately timed profiling."""
import json
import os
from kvbench_residual import serve

_original = serve.command_for


def command_for(args, model_name):
    command = _original(args, model_name)
    directory = os.environ.get('KVBENCH_PROFILE_DIR')
    if directory:
        command += ['--profiler-config', json.dumps({'profiler':'torch',
            'torch_profiler_dir':directory,'torch_profiler_with_stack':False,
            'torch_profiler_record_shapes':False,'torch_profiler_with_memory':False})]
    return command


if __name__ == '__main__':
    serve.command_for = command_for
    serve.main()
