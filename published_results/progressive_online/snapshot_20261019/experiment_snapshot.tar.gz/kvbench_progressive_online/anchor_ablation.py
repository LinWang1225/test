"""Short matched native-kernel reference; no server or task generation."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import statistics
import torch

from kvbench_longcontext.common import atomic_json
from kvbench_residual_diag.common import load_trace,trace_paths,write_csv
from .profile_components import measure
from .runtime import verify
from .run_ablation import load_file,prepare
from .validate_reuse import load_module


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--run',type=Path,required=True)
    p.add_argument('--parent-runtime',type=Path,required=True)
    p.add_argument('--traces',type=Path,required=True)
    a=p.parse_args();out=a.run/'native_anchor';out.mkdir(exist_ok=False)
    atomic_json(out/'status.json',{'status':'running'})
    try:
        verify(a.parent_runtime,'parent')
        modules={'native_parent':load_module(a.parent_runtime,'anchor_native_parent')}
        for name in ('fixed_k4v4','fixed_k4v2','fixed_k2v2','adaptive_kv'):
            modules[name]=load_file(a.run/'variants'/(name+'.py'),'anchor_'+name)
        rows=[]
        for path in trace_paths(a.traces,3):
            data,meta=load_trace(path);replay=prepare(data,16)
            counters=torch.zeros(14,dtype=torch.int64,device='cuda')
            for mode in ('single','split'):
                graphs={}
                for name,module in modules.items():
                    extra={} if name=='native_parent' else {'PG_DIAG_PTR':counters,'PG_DIAG_ENABLED':False}
                    def launch():return replay.launch(module,mode,extra=extra)
                    for _ in range(3):launch()
                    torch.cuda.synchronize();graph=torch.cuda.CUDAGraph()
                    with torch.cuda.graph(graph):launch()
                    graphs[name]=graph
                values={name:[] for name in modules}
                names=list(modules)
                # Rotate ordering to check that comparisons persist across rounds.
                for round_index in range(3):
                    order=names[round_index:]+names[:round_index]
                    for name in order:
                        t=measure(graphs[name].replay,repetitions=30,samples=5)
                        values[name].append(t['median_us'])
                native=statistics.median(values['native_parent'])
                for name,v in values.items():
                    median=statistics.median(v)
                    rows.append(dict(trace=path.name,dataset=meta['request']['dataset'],mode=mode,variant=name,
                        median_us=median,round_medians_us=v,slowdown_pct_vs_native=100*(median/native-1)))
        atomic_json(out/'comparison.json',rows);write_csv(out/'comparison.csv',rows)
        atomic_json(out/'status.json',{'status':'completed','scope':'matched kernel reference only; no parent task rerun',
            'parent_runtime':str(a.parent_runtime.resolve()),
            'parent_manifest_sha256':hashlib.sha256((a.parent_runtime/'runtime.json').read_bytes()).hexdigest(),
            'timing':'3 rotated-order rounds; CUDA graph replay; counting disabled',
            'dram_bytes':None})
        print(json.dumps([r for r in rows if r['mode']=='split'],ensure_ascii=False,indent=2))
    except BaseException as e:
        atomic_json(out/'status.json',{'status':'failed','error':repr(e)});raise


if __name__=='__main__':main()
