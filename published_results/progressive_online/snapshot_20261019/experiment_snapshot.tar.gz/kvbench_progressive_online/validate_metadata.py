"""Actual private backend flush -> metadata -> GPU selection contract check.

This small validation starts no model server and produces no task-quality or
latency claim. The worker imports vLLM from a newly built, hash-checked runtime.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace


def worker(out, runtime):
    import numpy as np
    import torch
    import vllm
    from kvbench_longcontext.common import atomic_json
    from kvbench_residual.fixtures import Case
    from .codec import unpack_numpy
    from .runtime import verify
    from .validate_reuse import Replay
    from vllm.model_executor.layers.quantization.kvarn.config import KVarNConfig
    from vllm.v1.attention.backends import kvarn_attn as backend
    from vllm.v1.attention.ops import kvarn_store as writer
    from vllm.v1.attention.ops import triton_kvarn_decode as decode

    manifest=verify(runtime,'p211_adaptive')
    assert Path(vllm.__file__).resolve()==runtime/'vllm/__init__.py'
    assert Path(writer.__file__).resolve()==runtime/'vllm/v1/attention/ops/kvarn_store.py'
    native_path=Path(manifest['parent_package'])/'v1/attention/ops/kvarn_store.py'
    spec=importlib.util.spec_from_file_location('original_metadata_writer',native_path)
    native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)
    cfg=KVarNConfig()
    heads=8; bids=[6,2]; slots=[1,3]; pages=9
    generator=torch.Generator(device='cuda').manual_seed(9107)
    pool_k=torch.randn((4,128,heads,128),device='cuda',generator=generator,dtype=torch.float16)
    pool_v=torch.randn((4,128,heads,128),device='cuda',generator=generator,dtype=torch.float16)
    kv=torch.zeros((pages,heads,cfg.tile_bytes_aligned),device='cuda',dtype=torch.uint8)
    state=torch.full((pages,heads,8,5),7,device='cuda',dtype=torch.int32)
    group=('metadata_contract_validation',os.getpid())
    impl=SimpleNamespace(kvarn_config=cfg,num_kv_heads=heads,_group_key=group,
        _tails={},_tail_K_pool=pool_k,_tail_V_pool=pool_v,
        _progressive_residual_metadata=None,_progressive_reuse=state)
    backend.KVarNAttentionImpl._block_to_slot_dict[group]=dict(zip(bids,slots))
    records=[]
    native_cache=None
    # Rewrite the SAME physical blocks, including an all-zero rewrite.
    for revision in range(3):
        if revision==1:
            pool_k.mul_(3);pool_v.mul_(.5)
        if revision==2:
            pool_k.zero_();pool_v.zero_()
        state.fill_(7)
        impl._tails={bid:None for bid in bids}
        os.environ['KVARN_FAST_FLUSH']='1'
        backend.KVarNAttentionImpl._batched_flush([(impl,bid,kv) for bid in bids])
        torch.cuda.synchronize()
        assert not impl._tails
        assert bool((state[bids]==0).all()),'Flush did not clear selected blocks'
        assert bool((state[[0,1,3,4,5,7,8]]==7).all()),'Flush changed another block'

        # Independently run the native quantizer on the SAME Sinkhorn result.
        kt=pool_k[slots].float().permute(0,2,3,1).reshape(-1,128,128)
        vt=pool_v[slots].float().permute(0,2,1,3).reshape(-1,128,128)
        count=len(bids)*heads
        balanced,col,row=backend.kvarn_sinkhorn_triton(torch.cat((kt,vt)),iterations=cfg.sinkhorn_iters)
        nk=native.kvarn_store_tile_k_batch_from_sinkhorn(balanced[:count],col[:count],row[:count],4)
        nv=native.kvarn_store_tile_v_batch_from_sinkhorn(balanced[count:],col[count:],row[count:],4)
        raw=nk['q_packed_uint8'].cpu().numpy()
        codes=np.empty((count,128,128),np.uint8)
        codes[...,::2]=raw&15;codes[...,1::2]=raw>>4
        packed=kv[bids,:,:cfg.k_packed_bytes].reshape(count,128,64)
        np.testing.assert_array_equal(unpack_numpy(packed.cpu().numpy(),128),codes)
        # Use float64 scales stored in the native writer output, not helper results.
        scale=np.abs(nk['s_col_K'].cpu().numpy().astype(np.float64)[:,:,None]*
                     nk['s_row_K'].cpu().numpy().astype(np.float64)[:,None,:])
        expected=[]
        for bits in (2,3,4):
            width=1<<(4-bits)
            approximate=(codes.astype(np.int64)//width)*width+(width-1)/2
            expected.append(np.max(np.abs(codes-approximate)*scale,axis=(1,2)))
        expected=np.stack(expected,axis=-1).reshape(len(bids),heads,3)
        measured=impl._progressive_residual_metadata[bids].cpu().numpy()
        np.testing.assert_allclose(measured,expected,rtol=2e-6,atol=1e-7)
        assert np.all(measured[:,:,2]==0)
        if revision==2:assert np.all(measured==0),'Zero rewrite retained stale metadata'
        records.append({'revision':revision,'tiles':count,'max_metadata_error':float(np.abs(measured-expected).max()),
                        'reused_blocks_invalidated':True})
        if revision==0:
            initial_codes=codes.reshape(2,heads,128,128).copy()
            initial_col=nk['s_col_K'].cpu().numpy().reshape(2,heads,128).astype(np.float64)
            initial_row=nk['s_row_K'].cpu().numpy().reshape(2,heads,128).astype(np.float64)
            # Construct native reference records, preserving byte-identical scales.
            native_cache=kv.cpu().numpy().copy()
            for j,bid in enumerate(bids):
                native_cache[bid,:,:cfg.k_packed_bytes]=nk['q_packed_uint8'][j*heads:(j+1)*heads].cpu().numpy().reshape(heads,-1)
                native_cache[bid,:,cfg.v_packed_offset:cfg.v_packed_offset+cfg.v_packed_bytes]=nv['q_packed_uint8'][j*heads:(j+1)*heads].cpu().numpy().reshape(heads,-1)
            initial_kv=kv.clone(); initial_metadata=impl._progressive_residual_metadata.clone()

    # Consume the ACTUAL flush metadata and actual 211 cache in the fused kernel.
    data={'case':Case('actual_flush_metadata',(256,),hq=32,hk=8),
          'cache':native_cache,'query':np.ones((1,32,128),np.float16),
          'block_table':np.array([bids],np.int32),'seq_lens':np.array([256],np.int32),
          'block_to_slot':np.full(pages,-1,np.int32),'pool_k':np.zeros((1,128,heads,128),np.float16),
          'pool_v':np.zeros((1,128,heads,128),np.float16),'req_rows':np.array([0],np.int32),
          'scale':128**-.5}
    replay=Replay(data,32)
    replay.gpu.planar=initial_kv;replay.metadata=initial_metadata
    decode._progressive_test_adaptive=True
    # Vary individual GQA query norms across precision boundaries, in both directions.
    errors=initial_metadata[bids].amax(dim=0).cpu().numpy()
    tiny=.25*min(.08/max(float(errors[:,0].max()),1e-30),
                 .04/max(float(errors[:,1].max()),1e-30))/(128**.5)
    query_factors=(0.,tiny,tiny*2,tiny*5,tiny*8,1.,20.,tiny)
    decisions=[]
    for mode in ('single','split'):
        replay.state.zero_()
        for index,factor in enumerate(query_factors):
            # Full quantized tiles stay fixed; query steps cross validity guards.
            # The length remains 256 so these are fresh decisions, not fake hits.
            replay.gpu.t['query'].fill_(factor)
            replay.launch(decode,mode,reuse=True)
            torch.cuda.synchronize()
            assert torch.isfinite(replay.gpu.out).all()
            q=replay.gpu.t['query'].cpu().numpy()[0].astype(np.float64).reshape(8,4,128)
            selected=replay.state[bids,:,::2,1].cpu().numpy()
            max_selected_score_error=0.
            for block in range(2):
                for head in range(8):
                    # Metadata at revision zero independently matched the native oracle.
                    bounds=initial_metadata[bids[block],head].cpu().numpy()
                    bound_factor=np.max(np.abs(q[head]).sum(axis=1))*abs(data['scale'])
                    expected_depth=2 if bounds[0]*bound_factor<=.08 else 3 if bounds[1]*bound_factor<=.04 else 4
                    assert np.all(selected[block,head]==expected_depth),'GPU depth disagrees with independent selection'
                    c=initial_codes[block,head].astype(np.int64)
                    for chunk,depth in enumerate(selected[block,head]):
                        width=1<<(4-int(depth))
                        approximate=(c//width)*width+(width-1)/2
                        delta=(c-approximate)*initial_col[block,head,:,None]*initial_row[block,head,None,:]
                        score_error=np.max(np.abs(q[head]@delta[:,chunk*32:(chunk+1)*32]))*abs(data['scale'])
                        threshold={2:.08,3:.04,4:0}[int(depth)]
                        assert score_error<=threshold+1e-12,'Selected depth violates real-arithmetic score threshold'
                        max_selected_score_error=max(max_selected_score_error,float(score_error))
            decisions.append({'mode':mode,'query_factor':factor,
                              'max_actual_selected_score_error':max_selected_score_error,
                              'depth_counts':{str(bits):int(np.sum(selected==bits)) for bits in (2,3,4)}})
    assert all(any(r['depth_counts'][str(bits)]>0 for r in decisions) for bits in (2,3,4)), 'Missing precision branch coverage'
    replay.gpu.t['query'].zero_();replay.state.zero_()
    replay.launch(decode,reuse=True);torch.cuda.synchronize()
    decode_graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(decode_graph):
        replay.launch(decode,reuse=True)
    for factor in (tiny,tiny*5,20.):
        replay.gpu.t['query'].fill_(factor)
        saved=replay.state.clone()
        decode_graph.replay();torch.cuda.synchronize()
        captured_output=replay.gpu.out.clone()
        replay.state.copy_(saved)
        eager_output=replay.launch(decode,reuse=True).clone()
        torch.testing.assert_close(captured_output,eager_output,rtol=0,atol=0)
    # Capture/replay metadata calculation on real writer-format outputs.
    from .residual_metadata import torch_residual_bounds_from_quantized
    kw=dict(packing='planes_211')
    packed=initial_kv[bids,:,:cfg.k_packed_bytes].reshape(count,128,64).contiguous()
    # Scales are read from the actual stored record, exactly as decode sees them.
    def read_half(offset):
        return initial_kv[bids,:,offset:offset+256].contiguous().view(torch.float16).reshape(count,128)
    sc=read_half(cfg.k_s_col_offset);sr=read_half(cfg.k_s_row_offset)
    torch_residual_bounds_from_quantized(packed,sc,sr,**kw)
    torch.cuda.synchronize()
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        graph_bounds=torch_residual_bounds_from_quantized(packed,sc,sr,**kw)
    for multiplier in (1.,2.,.5):
        sc.mul_(multiplier);graph.replay();torch.cuda.synchronize()
        eager=torch_residual_bounds_from_quantized(packed,sc,sr,**kw)
        torch.testing.assert_close(graph_bounds,eager,rtol=0,atol=0)
    atomic_json(out/'flush_checks.json',records)
    atomic_json(out/'selection_checks.json',decisions)
    atomic_json(out/'status.json',{'status':'completed','gpu':torch.cuda.get_device_name(),
        'writer_origin':writer.__file__,'backend_origin':backend.__file__,
        'runtime_source_sha256':manifest['executed_source_sha256'],
        'checks':['actual fast flush vs native writer oracle','physical block rewrite/zero rewrite',
                  'actual metadata in single/split GPU precision selection',
                  'independent real-arithmetic selected-score error','metadata and decode CUDA Graph replay'],
        'scope':'small actual backend contract test; no online quality, throughput or DRAM claim'})


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--runtime',type=Path)
    p.add_argument('--worker',action='store_true')
    a=p.parse_args();out=a.out.resolve()
    from kvbench_longcontext.common import atomic_json
    if a.worker:
        out.mkdir(parents=True,exist_ok=False)
        atomic_json(out/'status.json',{'status':'running'})
        try:worker(out,a.runtime.resolve())
        except BaseException as exc:
            atomic_json(out/'status.json',{'status':'failed','error':repr(exc)});raise
        return
    out.mkdir(parents=True,exist_ok=False)
    atomic_json(out/'status.json',{'status':'running'})
    try:
        from .runtime import build,verify
        runtime=out/'runtime'
        build(runtime,'p211_adaptive',reuse_stride=4);verify(runtime,'p211_adaptive')
        env=os.environ.copy();env.pop('PYTHONHOME',None)
        # Private vLLM/progressive sources take precedence; common benchmark
        # utilities live in the repository and are not copied into a runtime.
        repo=Path(__file__).resolve().parents[1]
        env.update(PYTHONPATH=os.pathsep.join((str(runtime),str(repo))),
                   PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1')
        with (out/'worker.log').open('x') as log:
            rc=subprocess.run([sys.executable,'-m','kvbench_progressive_online.validate_metadata',
                '--worker','--runtime',str(runtime),'--out',str(out/'worker')],
                cwd=runtime,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
        if rc:raise RuntimeError(f'Worker failed ({rc}); see {out}/worker.log')
        result=json.loads((out/'worker/status.json').read_text())
        assert result['status']=='completed'
        atomic_json(out/'status.json',result)
    except BaseException as exc:
        atomic_json(out/'status.json',{'status':'failed','error':repr(exc)});raise


if __name__=='__main__':main()
