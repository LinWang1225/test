"""Fully warmed online writer comparison plus separate C8 CPU/CUDA traces."""
import argparse
from datetime import datetime
import json
import os
from pathlib import Path
import sys
from types import SimpleNamespace
import traceback
import urllib.request

from kvbench_longcontext.common import atomic_json, read_jsonl, write_jsonl, sha_file, describe, checked_data
from .online_reader_probe import freeze_probe, analyze_point
from .run import DEFAULT_UPSTREAM, _client_python, _run_logged, _start_server, _stop_server, _gpu_idle
from .runtime import build, verify
from .fused_runtime import install


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--operator-run',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--reuse-original',type=Path,help='Read completed original-arm measurements from a previous failed batch')
    a=p.parse_args();root=a.out.resolve();root.mkdir(parents=True,exist_ok=False)
    state={'status':'running','phase':'checking_operator_gate','pid':os.getpid()}
    atomic_json(root/'status.json',state)
    try:
        gate=json.loads((a.operator_run/'status.json').read_text())
        if gate['status']!='completed':raise ValueError('Operator experiment did not complete')
        for label in ('original','fused'):
            if json.loads((a.operator_run/('flush_'+label)/'status.json').read_text())['status']!='completed':
                raise ValueError('Actual writer correctness failed')
        _gpu_idle('0')
        cfg=json.loads(Path(DEFAULT_UPSTREAM).read_text())['settings']
        if Path(sys.prefix).name!=cfg['server_env']:raise ValueError('Wrong server environment')
        freeze_probe(Path(cfg['data']),root/'data')
        freeze_probe(Path(cfg['data']),root/'profile_data')
        manifest=json.loads((root/'profile_data/manifest.json').read_text())
        manifest['datasets'].pop('qasper')
        manifest['settings']['max_new_tokens']=16
        for info in manifest['datasets'].values():
            rows=read_jsonl(root/'profile_data'/info['file'])
            for row in rows:row.update(max_tokens=16,generation_budget_tokens=16)
            write_jsonl(root/'profile_data'/info['file'],rows)
            info.update(sha256=sha_file(root/'profile_data'/info['file']),max_tokens=16,generation_budget_tokens=describe([16]*len(rows)))
        atomic_json(root/'profile_data/manifest.json',manifest);checked_data(root/'profile_data')
        client=_client_python(cfg)
        args=SimpleNamespace(model=Path(cfg['model']),max_model_len=cfg['max_model_len'],max_seqs=cfg['max_seqs'],
            batch_tokens=cfg['batch_tokens'],server_seed=cfg['server_seed'],port=18185,gpu='0',gpu_util=.85,
            startup_timeout=1800,eager=False,repo=Path(__file__).resolve().parents[1],
            serve_module='kvbench_progressive_online.profile_serve')
        env=os.environ.copy();env.pop('PYTHONHOME',None);env.pop('PYTHONPATH',None)
        env.update(PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',KVARN_FAST_FLUSH='1')
        atomic_json(root/'plan.json',{'arms':['planar_original','planar_fused_writer'],
            'precision':'full K4V4, same reader defaults; only writer packing differs',
            'datasets':['qasper','hotpotqa'],'requests_each':8,'concurrency':[8],'repeats':2,
            'warmup':'All 8 actual prompts before EVERY measured point, capped 32 output tokens',
            'measure_cap':128,'quality_scope':'Performance diagnostic, no task-quality score',
            'profile':'Separate after timing: HotpotQA C8, 16-token cap; not mixed into performance comparison',
            'dram_bytes':None,'started':datetime.now().isoformat()})
        results=[]
        if a.reuse_original:
            previous=json.loads((a.reuse_original/'comparison.json').read_text())
            results=[r for r in previous if r['arm']=='planar_original']
            if len(results)!=4 or not all(r['measurement_complete'] and r['valid_responses']==8 for r in results):
                raise ValueError('Prior original-arm results are incomplete')
            if sha_file(a.reuse_original/'data/manifest.json')!=sha_file(root/'data/manifest.json'):
                raise ValueError('Frozen data changed')
            atomic_json(root/'reused_original.json',{'source':str(a.reuse_original.resolve()),
                'comparison_sha256':sha_file(a.reuse_original/'comparison.json'),
                'limitation':'Baseline and candidate are separate time windows; interpret drift cautiously'})
            atomic_json(root/'comparison.json',results)
        # Local development endpoints must bypass ambient HTTP proxies.
        local_http=urllib.request.build_opener(urllib.request.ProxyHandler({}))
        labels=('planar_fused_writer',) if a.reuse_original else ('planar_original','planar_fused_writer')
        for label in labels:
            state.update(phase=label);atomic_json(root/'status.json',state)
            runtime=root/'runtimes'/label;build(runtime,'p211_full')
            if label=='planar_fused_writer':install(runtime,'p211_full')
            verify(runtime,'p211_full')
            env['KVBENCH_PROFILE_DIR']=str(root/'profiles'/label)
            proc=log=None
            try:
                proc,log,launch=_start_server(args,'p211_full',runtime,root/'servers'/label,root/'logs'/(label+'.server.log'),env)
                record=json.loads(launch.read_text());record['config']['method']=label
                launch=root/'servers'/label/'comparison.launch.json';atomic_json(launch,record)
                def run(data,out,repeats,warm):
                    command=['-m','kvbench_longcontext.run','--data-dir',data,'--out',out,
                        '--server-manifest',launch,'--concurrency','8','--repeats',str(repeats),
                        '--temperature','0','--top-p','1','--top-k','-1','--min-p','0','--seed',str(cfg['request_seed']),
                        '--request-timeout','300','--warmup','1','--warmup-per-point',str(warm),'--gpu','0',
                        '--sample-interval','1','--save-metrics-samples']
                    rc=_run_logged(client,command,root/'logs'/(label+'.'+out.name+'.client.log'),env,args.repo)
                    if rc:raise RuntimeError('Client failed: '+label+' '+out.name)
                run(root/'data',root/'online_runs'/label,2,8)
                for summary in sorted((root/'online_runs'/label).glob('r*/performance.summary.json')):
                    result=analyze_point(summary.parent)
                    if not result['measurement_complete']:raise ValueError('Incomplete measured point')
                    results.append(dict(arm=label,point=summary.parent.name,**result))
                atomic_json(root/'comparison.json',results)
                # Explicit profiler capture follows all performance measurements.
                started=False
                try:
                    request=urllib.request.Request('http://127.0.0.1:18185/start_profile',data=b'',method='POST')
                    with local_http.open(request,timeout=120) as response:
                        if response.status!=200:raise RuntimeError('Profiler did not start')
                    started=True
                    run(root/'profile_data',root/'profile_runs'/label,1,0)
                except Exception as exc:
                    atomic_json(root/(label+'.profile_error.json'),{'error':repr(exc),
                        'performance_measurements_preserved':True})
                finally:
                    if started:
                        try:
                            request=urllib.request.Request('http://127.0.0.1:18185/stop_profile',data=b'',method='POST')
                            with local_http.open(request,timeout=240) as response:response.read()
                        except Exception as exc:
                            atomic_json(root/(label+'.profile_stop_error.json'),{'error':repr(exc)})
            finally:
                try:_stop_server(proc)
                finally:
                    if log is not None:log.close()
        state.update(status='completed',phase='completed',finished=datetime.now().isoformat())
        atomic_json(root/'status.json',state)
    except BaseException as exc:
        state.update(status='failed',error=repr(exc),traceback=traceback.format_exc())
        atomic_json(root/'status.json',state);raise


if __name__=='__main__':main()
