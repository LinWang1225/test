"""Tune decode launch geometry and apply it only to newly built runtimes."""
from __future__ import annotations
import ast
import json
from pathlib import Path
import statistics
import torch

from kvbench_longcontext.common import atomic_json
from kvbench_residual.runtime import sha_file,text_sha,trace_footer
from kvbench_residual_diag.common import load_trace,trace_paths,write_csv
from .profile_components import measure
from .run_ablation import prepare
from .runtime import verify
from .transform import DECODE
from .validate_reuse import load_module


def validate_config(config):
    if (set(config)!={'block_n','num_warps','num_stages'} or config['block_n'] not in (16,32,64)
        or config['num_warps'] not in (2,4) or config['num_stages'] not in (1,2)):
        raise ValueError('Unsupported reader configuration')


def apply_configs(source,configs):
    if set(configs)!={'single','split'}:raise ValueError('Need single and split configurations')
    offsets=[];position=0
    for line in source.splitlines(keepends=True):offsets.append(position);position+=len(line)
    changes=[]
    targets={'_kvarn_fused_decode_kernel':'single','_kvarn_fused_decode_stage1':'split'}
    for node in ast.parse(source).body:
        if not isinstance(node,ast.FunctionDef) or node.name not in targets:continue
        config=configs[targets[node.name]];validate_config(config)
        found=0
        for deco in node.decorator_list:
            if not isinstance(deco,ast.Call) or not isinstance(deco.func,ast.Attribute) or deco.func.attr!='autotune':continue
            for keyword in deco.keywords:
                if keyword.arg!='configs':continue
                value=keyword.value
                replacement=f"[triton.Config({{'BLOCK_N': {config['block_n']}}}, num_warps={config['num_warps']}, num_stages={config['num_stages']})]"
                changes.append((offsets[value.lineno-1]+value.col_offset,offsets[value.end_lineno-1]+value.end_col_offset,replacement));found+=1
        if found!=1:raise ValueError('Missing kernel autotune config: '+node.name)
    if len(changes)!=2:raise ValueError('Expected both fused kernel configurations')
    for start,end,text in sorted(changes,reverse=True):source=source[:start]+text+source[end:]
    ast.parse(source);return source


def retune_new_runtime(root,arm,configs):
    """Called once before this NEW runtime is served; preserve all old runtime dirs."""
    manifest=verify(root,arm)
    if 'reader_tuning' in manifest['progressive']:raise ValueError('Runtime already tuned')
    root=Path(root);path=root/'vllm'/DECODE
    original_hash=sha_file(path)
    source=apply_configs(path.read_text(),configs)
    policy='parent' if arm=='parent' else 'repacked_full'
    footer=trace_footer(policy)
    if not source.endswith(footer):raise ValueError('Provenance footer changed')
    path.write_text(source)
    manifest['generated_sha256'][DECODE]=text_sha(source[:-len(footer)])
    manifest['executed_files_sha256'][DECODE]=sha_file(path)
    manifest['files_sha256']['vllm/'+DECODE]=sha_file(path)
    manifest['transformed_source_sha256']=manifest['generated_sha256'][DECODE]
    manifest['executed_source_sha256']=sha_file(path)
    manifest['progressive']['reader_tuning']={'configs':configs,'original_source_sha256':original_hash,
        'scope':'Launch configuration only; writer, code arithmetic and stored precision unchanged'}
    atomic_json(root/'runtime.json',manifest)
    verify(root,arm)


def tune(out,traces,parent_runtime,full_runtime):
    out=Path(out);out.mkdir(exist_ok=False)
    verify(parent_runtime,'parent');verify(full_runtime,'p211_full')
    modules={'native':load_module(parent_runtime,'tuning_native'),
             'planar_full':load_module(full_runtime,'tuning_planar')}
    grid=[dict(block_n=bn,num_warps=nw,num_stages=ns) for bn in (16,32,64) for nw in (2,4) for ns in (1,2)]
    rows=[];failures=[]
    for path in trace_paths(traces,3):
        data,meta=load_trace(path);replay=prepare(data,16)
        for mode in ('single','split'):
            for name,module in modules.items():
                replay.gpu.block_n=16;replay.gpu.num_warps=4;replay.gpu.num_stages=1
                reference=replay.launch(module,mode).clone()
                for config in grid:
                    print('TUNE',meta['request']['dataset'],mode,name,config,flush=True)
                    replay.gpu.block_n=config['block_n'];replay.gpu.num_warps=config['num_warps'];replay.gpu.num_stages=config['num_stages']
                    try:
                        for _ in range(3):replay.launch(module,mode)
                        torch.cuda.synchronize()
                        torch.testing.assert_close(replay.gpu.out,reference,rtol=.002,atol=.002)
                        graph=torch.cuda.CUDAGraph()
                        with torch.cuda.graph(graph):replay.launch(module,mode)
                        timing=measure(graph.replay,repetitions=20,samples=5)
                        rows.append(dict(trace=path.name,dataset=meta['request']['dataset'],mode=mode,method=name,
                            **config,**timing,output_max_diff=float((replay.gpu.out-reference).abs().max())))
                    except Exception as exc:
                        failures.append(dict(trace=path.name,mode=mode,method=name,config=config,error=repr(exc)))
                    atomic_json(out/'timings.json',rows);atomic_json(out/'failures.json',failures)
    selected={};selection=[]
    for name in modules:
        selected[name]={}
        for mode in ('single','split'):
            candidates=[]
            for config in grid:
                chosen=[r for r in rows if r['method']==name and r['mode']==mode and all(r[k]==v for k,v in config.items())]
                if len(chosen)!=3:continue
                ratios=[]
                for r in chosen:
                    baseline=next(x for x in rows if x['trace']==r['trace'] and x['mode']==mode and x['method']==name and x['block_n']==16 and x['num_warps']==4 and x['num_stages']==1)
                    ratios.append(r['median_us']/baseline['median_us'])
                candidates.append((statistics.mean(ratios),config))
            if not candidates:raise RuntimeError('No valid tuning candidate')
            score,config=min(candidates,key=lambda x:x[0]);selected[name][mode]=config
            selection.append(dict(method=name,mode=mode,config=config,mean_ratio_vs_16w4s1=score))
    atomic_json(out/'selection.json',{'configs':selected,'selection':selection,
        'rule':'minimum mean per-trace latency ratio across 3 C1 traces; single/split chosen separately',
        'limit':'selection uses these traces; online C1/C8 is a separate validation'})
    write_csv(out/'timings.csv',rows)
    atomic_json(out/'status.json',{'status':'completed','measurements':len(rows),'failures':len(failures)})
    return selected
