from __future__ import annotations
import ast
from pathlib import Path
import unittest
from kvbench_progressive_online.kernel import ADAPTIVE,FULL
from kvbench_progressive_online.transform import (_full_consumer,_fused,DEFAULT_THRESHOLDS,
    transform_backend, transform_writer,transform_torch_decode)
from kvbench_progressive_online.precision import PrecisionLevel,load_levels,validate_levels
from kvbench_progressive_online.residual_metadata import (
    load_residual_tensor, residual_bounds, write_residual_sidecar,
)


class SourceGateTest(unittest.TestCase):
    def test_saved_current_runtime_source_transforms(self):
        source_path = (Path(__file__).parents[2] / 'results' / 'progressive_online'
                       / 'longbench20_each_20261015_145645_215162' / 'runtimes'
                       / 'parent' / 'vllm' / 'v1' / 'attention' / 'ops'
                       / 'triton_kvarn_decode.py')
        if not source_path.exists():
            self.skipTest('saved runtime source is not available in this checkout')
        from kvbench_progressive_online.transform import transform_dequant
        source = source_path.read_text()
        for arm in ('p211_full', 'p211_adaptive'):
            transformed = transform_dequant(source, arm, DEFAULT_THRESHOLDS)
            ast.parse(transformed)
            self.assertNotIn('ar_scores_2', transformed)
            self.assertNotIn('ar_scores_3', transformed)
            self.assertGreaterEqual(transformed.count('k_bit0_bytes'), 2)
            if arm == 'p211_adaptive':
                self.assertIn('AR_RESIDUAL_PTR', transformed)
                self.assertIn('AR_RESIDUAL_ENABLED', transformed)
                self.assertIn('ar_meta_base', transformed)

        backend_path = (Path(__file__).parents[2] / 'results' / 'progressive_online'
                        / 'longbench20_each_20261015_145645_215162' / 'runtimes'
                        / 'parent' / 'vllm' / 'v1' / 'attention' / 'backends'
                        / 'kvarn_attn.py')
        if backend_path.exists():
            backend = transform_backend(backend_path.read_text())
            self.assertIn('torch_residual_bounds_from_quantized', backend)
            self.assertIn('_progressive_residual_metadata[bid_t]', backend)

    def test_progressive_gpu_bit_loads_are_conditional(self):
        self.assertLess(ADAPTIVE.index('ar_kh_b = tl.load'),ADAPTIVE.index('if ar_k_depth_2:'))
        self.assertIn('ar_k1_b = tl.load',ADAPTIVE)
        self.assertIn('ar_k0_b = tl.load',ADAPTIVE)
        self.assertEqual(ADAPTIVE.count('tl.dot(q, K_dg)'), 1)
        self.assertNotIn('ar_scores_2', ADAPTIVE)
        self.assertNotIn('ar_scores_3', ADAPTIVE)
        self.assertIn('ar_v0_b = tl.load',FULL)
    def test_strict_full_consumer(self):
        old=('    ar_k_high = tl.load(KV_cache_ptr + k_addrs).to(tl.int32)\n'
             '    ar_k_low = tl.load(KV_cache_ptr + k_addrs + D * GROUP // 4).to(tl.int32)\n'
             '    q_K = (4 * ((ar_k_high >> ((g_offs[None, :] % 4) * 2)) & 3) + ((ar_k_low >> ((g_offs[None, :] % 4) * 2)) & 3)).to(tl.float32)\n')
        result=_full_consumer(old,'k','g_offs')
        self.assertIn('ar_k_bit_addr',result)
        self.assertIn('d_offs[:, None] * (GROUP // 8)',result)
        self.assertIn('ar_k_bit0',result)
        with self.assertRaises(ValueError):_full_consumer(old,'v','g_offs')
    def test_fused_strict_and_adaptive_thresholds(self):
        chunk_start='                # Separate 2-bit planes occupy disjoint halves of each code field.'
        chunk_end='                Vc = (q_V * s_row_V[:, None] + zp_V[:, None]) * s_col_V[None, :]'
        body='def f():\n    AR_POLICY: tl.constexpr = 1\n    b = tl.program_id(0)\n                if AR_POLICY >= 3:\n                    pass\n'+chunk_start+'\n'+chunk_end+'\n'
        prog=_fused(body,'p211_adaptive',DEFAULT_THRESHOLDS)
        self.assertIn('PROG_K_2: tl.constexpr = 0.08',prog)
        self.assertIn('if ar_k_depth_2:',prog)
        self.assertIn('if True:',prog)
        full=_fused(body,'p211_full',DEFAULT_THRESHOLDS)
        self.assertIn('ar_k0_b = tl.load',full)
        with self.assertRaises(ValueError):_fused('def f():\n  pass\n','p211_adaptive',DEFAULT_THRESHOLDS)
    def test_store_imports_exact(self):
        s=('from kvbench_residual.representation import pack_planes_torch\nreturn pack_planes_torch(q)\n')*2
        t=transform_writer(s)
        self.assertEqual(t.count('pack_211_torch(q)'),2)
        d='from kvbench_residual.representation import unpack_planes_torch\nreturn unpack_planes_torch(packed, original_last_dim)\n'
        t=transform_torch_decode(d)
        self.assertIn('return unpack_211_torch(packed, original_last_dim)',t)

    def test_precision_ladder_is_configurable_and_monotonic(self):
        levels=load_levels(None)
        self.assertEqual(tuple(level.bits for level in levels),(2,3,4))
        validate_levels((PrecisionLevel(2,.2),PrecisionLevel(4,0)))
        with self.assertRaises(ValueError):
            validate_levels((PrecisionLevel(4,.1),))

    def test_offline_residual_bounds_are_monotonic_and_exact_at_full_precision(self):
        import numpy as np
        codes = np.arange(32, dtype=np.uint8).reshape(2, 4, 4) % 16
        bounds = residual_bounds(
            codes,
            column_scale=np.array([1, 2, 3, 4], dtype=np.float32),
            row_scale=np.array([1, 2, 1, 2], dtype=np.float32),
        )
        self.assertEqual(bounds.shape, (2, 3))
        self.assertTrue(np.all(bounds[:, 0] >= bounds[:, 1]))
        self.assertTrue(np.all(bounds[:, 1] >= bounds[:, 2]))
        self.assertTrue(np.all(bounds[:, 2] == 0))

    def test_metadata_bound_accounts_for_signed_scales_and_query_drift(self):
        import numpy as np
        rng=np.random.default_rng(42)
        codes=rng.integers(0,16,(128,128),dtype=np.uint8)
        col=rng.normal(size=128)
        row=rng.normal(size=128)
        bound=residual_bounds(codes,column_scale=col,row_scale=row)
        for factor in (0.,.001,1.,100.):
            query=rng.normal(size=(4,128))*factor
            for index,bits in enumerate((2,3)):
                discarded=4-bits
                approx=(codes.astype(int)>>discarded)*(1<<discarded)+(1<<discarded)/2-.5
                residual=(codes-approx)*col[:,None]*row[None,:]
                actual=np.max(np.abs(query@residual))/128**.5
                upper=bound[index]*np.max(np.sum(np.abs(query),axis=1))/128**.5
                self.assertLessEqual(actual,upper+1e-5)
        self.assertGreater(bound[0],0)

    def test_reuse_has_current_query_guard_and_flush_invalidation(self):
        self.assertIn('ar_query_factor', ADAPTIVE)
        self.assertIn('(ar_k_error_2 <= PROG_K_2)', ADAPTIVE)
        self.assertIn('seq_len - ar_old_step < PROG_REUSE_STRIDE', ADAPTIVE)
        self.assertIn('AR_REUSE_ENABLED and not VQ_INDIRECT', ADAPTIVE)
        path=(Path(__file__).parents[2]/'results/progressive_online'
              /'longbench20_each_20261015_145645_215162/runtimes/parent/vllm'
              /'v1/attention/backends/kvarn_attn.py')
        if path.exists():
            backend=transform_backend(path.read_text(),4)
            ast.parse(backend)
            self.assertIn('impl._progressive_reuse[bid_t] = 0',backend)
            self.assertIn('self._progressive_reuse = torch.zeros',backend)

    def test_residual_sidecar_has_runtime_layout(self):
        import tempfile
        import numpy as np
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "residual.npz"
            write_residual_sidecar(path, np.zeros((2, 3, 4, 4), dtype=np.uint8))
            tensor = load_residual_tensor(path)
            self.assertEqual(tuple(tensor.shape), (2, 3, 3))
            self.assertEqual(str(tensor.dtype), "torch.float32")


if __name__=='__main__':unittest.main()
