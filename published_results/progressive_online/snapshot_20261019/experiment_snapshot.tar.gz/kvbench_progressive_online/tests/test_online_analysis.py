import gzip
import json
from pathlib import Path
import tempfile
import unittest

from kvbench_progressive_online.online_reader_probe import analyze_point


class OnlineAnalysisTest(unittest.TestCase):
    def test_energy_span_histogram_delta_and_sse_gaps(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp);(p/'raw').mkdir()
            perf={'expected_tasks':2,'measurement_complete':True,'request_window_s':10,
                  'dataset':'qasper','repeat':1,'concurrency':1}
            (p/'performance.summary.json').write_text(json.dumps(perf))
            (p/'metrics.before.txt').write_text('vllm:request_decode_time_seconds_count 3\nvllm:request_decode_time_seconds_sum 5\n')
            (p/'metrics.after.txt').write_text('vllm:request_decode_time_seconds_count 5\nvllm:request_decode_time_seconds_sum 7\n')
            samples=[{'unix_time':100,'gpu':{'returncode':0,'stdout':'1000, 80, 100, 40, 1600, 9000, 30, P2'}},
                     {'unix_time':102,'gpu':{'returncode':0,'stdout':'1000, 80, 200, 40, 1600, 9000, 30, P2'}}]
            (p/'telemetry.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in samples))
            chunks=[{'elapsed_s':t,'data':{'choices':[{'delta':{'content':'a'}}]}} for t in (.1,.2,.4)]
            chunks.append({'elapsed_s':1.,'data':{'choices':[],'usage':{'completion_tokens':3}}})
            with gzip.open(p/'raw/a.gz','wt') as f:json.dump(chunks,f)
            (p/'requests.jsonl').write_text(json.dumps({'case_id':'a','raw_chunks_file':'raw/a.gz'})+'\n')
            result=analyze_point(p)
            self.assertEqual(result['gpu_energy_j_est_over_sampled_span'],300)
            self.assertEqual(result['gpu_sampled_span_s'],2)
            self.assertEqual(result['server_histogram_deltas']['request_decode_time_seconds']['mean_s'],1)
            self.assertTrue(result['server_histogram_deltas']['request_decode_time_seconds']['count_matches_requests'])
            self.assertEqual(result['sse_chunk_gaps'][0]['content_chunk_count'],3)
            self.assertAlmostEqual(result['sse_chunk_gaps'][0]['gap_s']['mean'],.15)
            self.assertIsNone(result['dram_bytes'])


if __name__=='__main__':unittest.main()
