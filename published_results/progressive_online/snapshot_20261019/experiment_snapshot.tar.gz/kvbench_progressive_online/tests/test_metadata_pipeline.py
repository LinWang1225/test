"""Regress the actual native/211 writer-to-metadata format contract."""
from __future__ import annotations

import importlib.util
from pathlib import Path
import types
import unittest
from unittest.mock import patch

import numpy as np
import torch

from kvbench_progressive_online.codec import pack_211_torch, unpack_numpy
from kvbench_progressive_online.residual_metadata import torch_residual_bounds_from_quantized
from kvbench_progressive_online.transform import STORE, transform_writer
from kvbench_residual.runtime import reviewed_sources
from kvbench_residual.transform import transform_sources


def native_codes(packed):
    """Independent native nibble reader; never use the production 211 decoder."""
    raw = packed.detach().cpu().numpy()
    codes = np.empty((*raw.shape[:-1], raw.shape[-1]*2), np.uint8)
    codes[..., ::2] = raw & 15
    codes[..., 1::2] = raw >> 4
    return codes


def oracle_bounds(codes, column, row):
    """Float64 error of the mathematical prefix reconstruction."""
    c = codes.astype(np.int64)
    scale = np.abs(column.astype(np.float64)[..., :, None] * row.astype(np.float64)[..., None, :])
    output = []
    for bits in (2, 3, 4):
        width = 1 << (4-bits)
        approximate = (c // width)*width+(width-1)/2
        output.append(np.max(np.abs(c-approximate)*scale, axis=(-2, -1)))
    return np.stack(output, axis=-1)


def writer_modules():
    package = Path(importlib.util.find_spec('vllm').origin).parent
    _, source = reviewed_sources(package)
    planar = transform_writer(transform_sources(source, 'repacked_full', .02)[STORE])
    modules = []
    for label, text in [('native', source[STORE]), ('planes', planar)]:
        module = types.ModuleType('metadata_writer_'+label)
        exec(compile(text, str(package/STORE)+':'+label, 'exec'), module.__dict__)
        modules.append(module)
    return modules


class WriterMetadataContractTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.native, cls.planes = writer_modules()

    def assert_writer_metadata(self, device):
        generator = torch.Generator().manual_seed(867)
        balanced = torch.randn((3,128,128),generator=generator).to(device)
        balanced[1].fill_(0)
        balanced[2] *= 100
        col = torch.exp(torch.randn((3,128),generator=generator)*.5).to(device)
        row = torch.exp(torch.randn((3,128),generator=generator)*.5).to(device)
        with patch.dict('os.environ', {'KVARN_RTN_QUANTILE':'0'}):
            original = self.native.kvarn_store_tile_k_batch_from_sinkhorn(balanced,col,row,4)
            transformed = self.planes.kvarn_store_tile_k_batch_from_sinkhorn(balanced,col,row,4)
        codes = native_codes(original['q_packed_uint8'])
        decoded = unpack_numpy(transformed['q_packed_uint8'].cpu().numpy(),128)
        np.testing.assert_array_equal(decoded,codes)
        for key in ('s_col_K','s_row_K','zp_K'):
            torch.testing.assert_close(transformed[key],original[key],rtol=0,atol=0)
        expected = oracle_bounds(codes,original['s_col_K'].cpu().numpy(),original['s_row_K'].cpu().numpy())
        for value, packing in [(original,'native_int4'),(transformed,'planes_211')]:
            result = torch_residual_bounds_from_quantized(
                value['q_packed_uint8'],value['s_col_K'],value['s_row_K'],packing=packing)
            np.testing.assert_allclose(result.cpu().numpy(),expected,rtol=2e-6,atol=1e-7)
            self.assertTrue(bool((result[:,0] >= result[:,1]).all()))
            self.assertTrue(bool((result[:,2] == 0).all()))

    def test_actual_batched_writer_to_metadata_cpu(self):
        self.assert_writer_metadata('cpu')

    @unittest.skipUnless(torch.cuda.is_available(),'CUDA is required')
    def test_actual_batched_writer_to_metadata_cuda(self):
        self.assert_writer_metadata('cuda')

    def test_underestimated_bound_counterexample(self):
        q = torch.randint(0,16,(1,128,128),generator=torch.Generator().manual_seed(7),dtype=torch.uint8)
        packed = pack_211_torch(q)
        column = torch.full((1,128),1e-6)
        row = torch.full((1,128),1e-6)
        column[0,0]=1; row[0,1]=1
        expected = oracle_bounds(q.numpy(),column.numpy(),row.numpy())
        old = torch_residual_bounds_from_quantized(packed,column,row,packing='native_int4')
        fixed = torch_residual_bounds_from_quantized(packed,column,row,packing='planes_211')
        self.assertEqual(old[0,0].item(),.5)
        self.assertEqual(expected[0,0],1.5)
        self.assertEqual(fixed[0,0].item(),1.5)

    def test_explicit_packing_required_and_bad_inputs_rejected(self):
        packed=torch.zeros((1,8,8),dtype=torch.uint8)
        column=torch.ones((1,8)); row=torch.ones((1,16))
        with self.assertRaises(TypeError):
            torch_residual_bounds_from_quantized(packed,column,row)
        for packing in ('unknown','',None):
            with self.assertRaises(ValueError):
                torch_residual_bounds_from_quantized(packed,column,row,packing=packing)
        with self.assertRaises(ValueError):
            torch_residual_bounds_from_quantized(packed.float(),column,row,packing='planes_211')

    def test_all_codes_signed_scales_and_rectangular_tiles(self):
        q=(torch.arange(2*8*16).reshape(2,8,16)%16).to(torch.uint8)
        column=torch.linspace(-2,3,16).reshape(2,8)
        row=torch.linspace(-3,4,32).reshape(2,16)
        packed=pack_211_torch(q)
        actual=torch_residual_bounds_from_quantized(packed,column,row,packing='planes_211')
        expected=oracle_bounds(q.numpy(),column.numpy(),row.numpy())
        np.testing.assert_allclose(actual.numpy(),expected,rtol=2e-6,atol=1e-7)


if __name__ == '__main__':
    unittest.main()
