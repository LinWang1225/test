import gzip
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from kvbench_longcontext.run import Observer


class ObserverTest(unittest.TestCase):
    def test_raw_metrics_and_queue_sample_share_timestamp(self):
        text='vllm:num_requests_running{engine="0"} 3\nvllm:num_requests_waiting{engine="0"} 2\nvllm:request_decode_time_seconds_sum{engine="0"} 1.25\n'
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp)
            observer=Observer('http://127.0.0.1:1',root/'telemetry.jsonl',None,1,{},root/'metrics.jsonl.gz')
            def respond(*args,**kwargs):
                observer.stop_event.set()
                return text
            with patch('kvbench_longcontext.run.http_text',side_effect=respond):
                observer.loop()
            sample=json.loads((root/'telemetry.jsonl').read_text())
            with gzip.open(root/'metrics.jsonl.gz','rt') as f:raw=json.loads(f.read())
            self.assertEqual(sample['num_requests_running'],[3.])
            self.assertEqual(sample['num_requests_waiting'],[2.])
            self.assertEqual(raw['text'],text)
            self.assertEqual(raw['unix_time'],sample['unix_time'])


if __name__=='__main__':unittest.main()
